import java.util.ArrayList;

// contains one static method that returns a one-dimensional array (soon to be vector). This can be called in R using rjava, and thanks to the 
// interpretive nature of R, iterating through ranges of parameter values (in R for loop) and storing them in a data fram is easy and quickly modifiable, 
//although it would be very easy to create another class that calls R sim and throws these 1D arrays into 2D arrays. 
// I move to R, since equilibrium community -->  replicated equilibrium community -->  R sim is becoming more and more data oriented 
public class RSim
{
	// private static Community com;

	// how long should the donut be?
	private static int gridLength = 50;

	// construct species and put them in an array list. The format for species is given below:

	// Species(int speciesName, int initialAbundance, double cmax, double d, int dispersalRadius,
	// boolean makesAA1, boolean makesAA2, boolean makesAA3,
	// int AA1K, int AA2K, int AA3K)

	// how far can species dispersal in any direction
	private static int dispersalRadius = 1;

	// how many amino acids does each critter produce?
	private static double KAAProduced = 8;

	private static ArrayList<Species> speciesList = new ArrayList<Species>();
	static
	{
		speciesList.add(new Species(123, 20, .75, 0.10, 0, true, true, true, 0, 0, 0));
		speciesList.add(new Species(23, 20, .80, 0.10, 0, false, true, true, 1, 0, 0));
		speciesList.add(new Species(13, 20, .80, 0.10, 0, true, false, true, 0, 1, 0));
		speciesList.add(new Species(12, 20, .80, 0.10, 0, true, true, false, 0, 0, 1));
		speciesList.add(new Species(3, 20, .85, 0.10, 0, false, false, true, 1, 1, 0));
		speciesList.add(new Species(2, 20, .85, 0.10, 0, false, true, false, 1, 0, 1));
		speciesList.add(new Species(1, 20, .85, 0.10, 0, true, false, false, 0, 1, 1));
		speciesList.add(new Species(0, 20, .90, 0.10, 0, false, false, false, 1, 1, 1));
	}

	public static int add(int a, int b)
	{
		return a + b;
	}

	public static double[][] timeSeries(int numSteps, int measureHowOften, int gridLength, double propToStart, int dispersalRadius, double death, double KAAProduced, double cmaxCheater, double AA1Cost,
			double AA2Cost, double AA3Cost, boolean dontUse0, boolean dontUse1, boolean dontUse2, boolean dontUse3, boolean dontUse12, boolean dontUse13, boolean dontUse23, boolean dontUse123)
	{
		speciesList = new ArrayList<Species>();

		if (!dontUse0)
		{
			speciesList.add(new Species(0, 20, .90, 0.10, 0, false, false, false, 1, 1, 1));
		}
		if (!dontUse1)
		{
			speciesList.add(new Species(1, 20, .85, 0.10, 0, true, false, false, 0, 1, 1));
		}
		if (!dontUse2)
		{
			speciesList.add(new Species(2, 20, .85, 0.10, 0, false, true, false, 1, 0, 1));
		}
		if (!dontUse3)
		{
			speciesList.add(new Species(3, 20, .85, 0.10, 0, false, false, true, 1, 1, 0));
		}
		if (!dontUse12)
		{
			speciesList.add(new Species(12, 20, .80, 0.10, 0, true, true, false, 0, 0, 1));
		}
		if (!dontUse13)
		{
			speciesList.add(new Species(13, 20, .80, 0.10, 0, true, false, true, 0, 1, 0));
		}
		if (!dontUse23)
		{
			speciesList.add(new Species(23, 20, .80, 0.10, 0, false, true, true, 1, 0, 0));
		}
		if (!dontUse123)
		{
			speciesList.add(new Species(123, 20, .75, 0.10, 0, true, true, true, 0, 0, 0));
		}

		for (int i = 0; i < speciesList.size(); i++)
		{
			double totalCost = 0;
			Species currentSpecies = speciesList.get(i);
			if (currentSpecies.makesAA1())
			{
				totalCost += AA1Cost;
			}
			if (currentSpecies.makesAA2())
			{
				totalCost += AA2Cost;
			}
			if (currentSpecies.makesAA3())
			{
				totalCost += AA3Cost;
			}
			currentSpecies.setCmax(cmaxCheater * Math.exp(-totalCost));
		}

		int initAbund = (int) Math.round((propToStart / (double) speciesList.size()) * Math.pow(gridLength, 2));

		for (int i = 0; i < speciesList.size(); i++)
		{
			Species currentSpecies = speciesList.get(i);
			currentSpecies.setD(death);
			currentSpecies.setInitialAbundance(initAbund);

		}
		int AADispersalRadius = dispersalRadius;
		boolean useStep2 = false;
		Community com = new Community(gridLength, 1, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return com.timeSeries(numSteps, measureHowOften, false);
	}

	public static double[] finalAbundances(int numSteps, int numReps, int gridLength, int dispersalRadius, double KAAProduced, boolean useSharedInitProp, double initProp, boolean useSharedDeathProb,
			double deathProb, boolean use0, double initProp0, double cmax0, double death0, int inoculateWhen0, int AA1Kx0, int AA2Kx0, int AA3Kx0, boolean use1, double initProp1, double cmax1, double death1, int inoculateWhen1, int AA1Kx1,
			int AA2Kx1, int AA3Kx1, boolean use2, double initProp2, double cmax2, double death2, int inoculateWhen2, int AA1Kx2, int AA2Kx2, int AA3Kx2, boolean use3, double initProp3, double cmax3, double death3,  int inoculateWhen3,
			int AA1Kx3, int AA2Kx3, int AA3Kx3, boolean use12, double initProp12, double cmax12, double death12,  int inoculateWhen12, int AA1Kx12, int AA2Kx12, int AA3Kx12, boolean use23, double initProp23,
			double cmax23, double death23, int inoculateWhen23, int AA1Kx23, int AA2Kx23, int AA3Kx23, boolean use13, double initProp13, double cmax13, double death13,  int inoculateWhen13, int AA1Kx13, int AA2Kx13, int AA3Kx13,
			boolean use123, double initProp123, double cmax123, double death123,  int inoculateWhen123, int AA1Kx123, int AA2Kx123, int AA3Kx123)

	{
		speciesList = new ArrayList<Species>();

		if (use0)
		{
			speciesList.add(new Species(0, abundFromProp(initProp0), cmax0, death0, inoculateWhen0, false, false, false, AA1Kx0, AA2Kx0, AA3Kx0));
		}
		if (use1)
		{
			speciesList.add(new Species(1, abundFromProp(initProp1), cmax1, death1, inoculateWhen1, true, false, false, AA1Kx1, AA2Kx1, AA3Kx1));
		}
		if (use2)
		{
			speciesList.add(new Species(2, abundFromProp(initProp2), cmax2, death2, inoculateWhen2, false, true, false, AA1Kx2, AA2Kx2, AA3Kx2));
		}
		if (use3)
		{
			speciesList.add(new Species(3, abundFromProp(initProp3), cmax3, death3, inoculateWhen3, false, false, true, AA1Kx3, AA2Kx3, AA3Kx3));
		}
		if (use12)
		{
			speciesList.add(new Species(12, abundFromProp(initProp12), cmax12, death12, inoculateWhen12, true, true, false, AA1Kx12, AA2Kx12, AA3Kx12));
		}
		if (use23)
		{
			speciesList.add(new Species(23, abundFromProp(initProp23), cmax23, death23, inoculateWhen23, true, false, true, AA1Kx23, AA2Kx23, AA3Kx23));
		}
		if (use13)
		{
			speciesList.add(new Species(13, abundFromProp(initProp13), cmax13, death13, inoculateWhen13, false, true, true, AA1Kx13, AA2Kx13, AA3Kx13));
		}
		if (use123)
		{
			speciesList.add(new Species(123, abundFromProp(initProp123), cmax123, death123, inoculateWhen123, true, true, true, AA1Kx123, AA2Kx123, AA3Kx123));
		}

		if (useSharedInitProp)
		{
			int initAbund = (int) Math.round((initProp / (double) speciesList.size()) * Math.pow(gridLength, 2));

			for (int i = 0; i < speciesList.size(); i++)
			{
				Species currentSpecies = speciesList.get(i);
				currentSpecies.setInitialAbundance(initAbund);

			}
		}

		if (useSharedDeathProb)
		{

			for (int i = 0; i < speciesList.size(); i++)
			{
				Species currentSpecies = speciesList.get(i);
				currentSpecies.setD(deathProb);

			}
		}

		int AADispersalRadius = dispersalRadius;
		boolean useStep2 = false;
		double[][] finalAbundsOverTime = new double[speciesList.size()][numReps];
		for (int r = 0; r < numReps; r++)
		{
	
			Community com = new Community(gridLength, .1, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
			double[] temp = com.finalValue(numSteps, true);
			
			for(int t = 0; t < temp.length; t++)
			{
				finalAbundsOverTime[t][r] = temp[t];
			}
		}

		double[] toReturn = new double[finalAbundsOverTime.length*2];
		for(int i = 0; i < finalAbundsOverTime.length; i++)
		{
			toReturn[2 * i] = MeanAndSD.meanAcrossColumns(finalAbundsOverTime, i);
			toReturn[2 * i + 1] = MeanAndSD.SDAcrossColumns(finalAbundsOverTime, i, toReturn[2 * i]);

		}
		
		return toReturn;

	}
	
	
	
	/*
	 * numSteps, measureHowOften, gridLength, propToStart, dispersalRadius, KAAProduced, use0, initProp0, cmax0, death0, AA1Kx0, AA2Kx0, AA3Kx0, use1, initProp1, cmax1, death1, AA1Kx1, AA2Kx1, AA3Kx1, use2, initProp2, cmax2, death2, AA1Kx2, AA2Kx2, AA3Kx2, use3, initProp3, cmax3, death3, AA1Kx3, AA2Kx3, AA3Kx3, use12, initProp12, cmax12, death12, AA1Kx12, AA2Kx12, AA3Kx12, use23, initProp23, cmax23, death23, AA1Kx23, AA2Kx23, AA3Kx23, use13, initProp13, cmax13, death13, AA1Kx13, AA2Kx13, AA3Kx13, use123, initProp123, cmax123, death123, AA1Kx123, AA2Kx123, AA3Kx123
	 */
	public static double[][] timeSeries(int numSteps, int measureHowOften, int gridLength, int dispersalRadius, double KAAProduced, boolean useSharedInitProp, double initProp, boolean useSharedDeathProb,
			double deathProb, boolean use0, double initProp0, double cmax0, double death0, int inoculateWhen0, int AA1Kx0, int AA2Kx0, int AA3Kx0, boolean use1, double initProp1, double cmax1, double death1, int inoculateWhen1, int AA1Kx1,
			int AA2Kx1, int AA3Kx1, boolean use2, double initProp2, double cmax2, double death2, int inoculateWhen2, int AA1Kx2, int AA2Kx2, int AA3Kx2, boolean use3, double initProp3, double cmax3, double death3,  int inoculateWhen3,
			int AA1Kx3, int AA2Kx3, int AA3Kx3, boolean use12, double initProp12, double cmax12, double death12,  int inoculateWhen12, int AA1Kx12, int AA2Kx12, int AA3Kx12, boolean use23, double initProp23,
			double cmax23, double death23, int inoculateWhen23, int AA1Kx23, int AA2Kx23, int AA3Kx23, boolean use13, double initProp13, double cmax13, double death13,  int inoculateWhen13, int AA1Kx13, int AA2Kx13, int AA3Kx13,
			boolean use123, double initProp123, double cmax123, double death123,  int inoculateWhen123, int AA1Kx123, int AA2Kx123, int AA3Kx123)
	{
		speciesList = new ArrayList<Species>();

		if (use0)
		{
			speciesList.add(new Species(0, abundFromProp(initProp0), cmax0, death0, inoculateWhen0, false, false, false, AA1Kx0, AA2Kx0, AA3Kx0));
		}
		if (use1)
		{
			speciesList.add(new Species(1, abundFromProp(initProp1), cmax1, death1, inoculateWhen1,true, false, false, AA1Kx1, AA2Kx1, AA3Kx1));
		}
		if (use2)
		{
			speciesList.add(new Species(2, abundFromProp(initProp2), cmax2, death2, inoculateWhen2, false, true, false, AA1Kx2, AA2Kx2, AA3Kx2));
		}
		if (use3)
		{
			speciesList.add(new Species(3, abundFromProp(initProp3), cmax3, death3, inoculateWhen3, false, false, true, AA1Kx3, AA2Kx3, AA3Kx3));
		}
		if (use12)
		{
			speciesList.add(new Species(12, abundFromProp(initProp12), cmax12, death12, inoculateWhen12, true, true, false, AA1Kx12, AA2Kx12, AA3Kx12));
		}
		if (use23)
		{
			speciesList.add(new Species(23, abundFromProp(initProp23), cmax23, death23, inoculateWhen23, true, false, true, AA1Kx23, AA2Kx23, AA3Kx23));
		}
		if (use13)
		{
			speciesList.add(new Species(13, abundFromProp(initProp13), cmax13, death13, inoculateWhen13, false, true, true, AA1Kx13, AA2Kx13, AA3Kx13));
		}
		if (use123)
		{
			speciesList.add(new Species(123, abundFromProp(initProp123), cmax123, death123, inoculateWhen123, true, true, true, AA1Kx123, AA2Kx123, AA3Kx123));
		}

		if (useSharedInitProp)
		{
			int initAbund = (int) Math.round((initProp / (double) speciesList.size()) * Math.pow(gridLength, 2));

			for (int i = 0; i < speciesList.size(); i++)
			{
				Species currentSpecies = speciesList.get(i);
				currentSpecies.setInitialAbundance(initAbund);

			}
		}

		if (useSharedDeathProb)
		{

			for (int i = 0; i < speciesList.size(); i++)
			{
				Species currentSpecies = speciesList.get(i);
				currentSpecies.setD(deathProb);

			}
		}

		int AADispersalRadius = dispersalRadius;
		boolean useStep2 = false;
		Community com = new Community(gridLength, .1, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return com.timeSeries(numSteps, measureHowOften, false);
	}

	public static int abundFromProp(double prop)
	{
		return (int) Math.round(prop * (double) Math.pow(gridLength, 2));
	}

	public static double[][] quantCheatTimeSeries(int numSteps, int measureHowOften, int gridLength, double propToStart, int dispersalRadius, double death, double KAAProduced, double cmaxQuantCheat,
			double cmaxSyn1, double cmaxSyn2, boolean useQuantCheat, int stepsUntilQuantCheat, double quantCheatInitProp)

	{
		int quantCheatInitAbund = (int) Math.round(quantCheatInitProp * Math.pow(gridLength, 2));
		int synInitAbund = (int) Math.round((propToStart / (double) 2) * Math.pow(gridLength, 2));

		speciesList = new ArrayList<Species>();

		// Species(int speciesName1, int initialAbundance, double cmax, double d, boolean makesAA1, boolean makesAA2, boolean makesAA3, double AA1K, double AA2K, double AA3K)
		if (useQuantCheat)
		{
			speciesList.add(new Species(0, quantCheatInitAbund, cmaxQuantCheat, death, stepsUntilQuantCheat, false, false, false, 0, 1, 0));
		}

		speciesList.add(new Species(1, synInitAbund, cmaxSyn1, death, 0, true, false, false, 0, 1, 0));

		speciesList.add(new Species(2, synInitAbund, cmaxSyn2, death, 0, false, true, false, 1, 0, 0));

		/*
		 * for (int i = 0; i < speciesList.size(); i++) { double totalCost = 0; Species currentSpecies = speciesList.get(i); if (currentSpecies.makesAA1()) { totalCost += AA1Cost; } if (currentSpecies.makesAA2()) { totalCost += AA2Cost; } if (currentSpecies.makesAA3()) { totalCost += AA3Cost; } currentSpecies.setCmax(cmaxCheater * Math.exp(-totalCost)); }
		 */

		/*
		 * for (int i = 0; i < speciesList.size(); i++) { Species currentSpecies = speciesList.get(i); currentSpecies.setD(death);
		 * 
		 * }
		 */
		int AADispersalRadius = dispersalRadius;
		boolean useStep2 = false;
		Community com = new Community(gridLength, .1, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return com.timeSeries(numSteps, measureHowOften, false);
	}

	
	public static double[] quantCheatFinalAbundances(int numSteps, int numReps, int gridLength, double propToStart, int dispersalRadius, double death, double KAAProduced, double cmaxQuantCheat,
			double cmaxSyn1, double cmaxSyn2, boolean useQuantCheat, int stepsUntilQuantCheat, double quantCheatInitProp, boolean reportDensity)

	{
		int quantCheatInitAbund = (int) Math.round(quantCheatInitProp * Math.pow(gridLength, 2));
		int synInitAbund = (int) Math.round((propToStart / (double) 2) * Math.pow(gridLength, 2));

		speciesList = new ArrayList<Species>();

		// Species(int speciesName1, int initialAbundance, double cmax, double d, boolean makesAA1, boolean makesAA2, boolean makesAA3, double AA1K, double AA2K, double AA3K)
		if (useQuantCheat)
		{
			speciesList.add(new Species(0, quantCheatInitAbund, cmaxQuantCheat, death, stepsUntilQuantCheat, false, false, false, 0, 1, 0));
		}

		speciesList.add(new Species(1, synInitAbund, cmaxSyn1, death, 0, true, false, false, 0, 1, 0));

		speciesList.add(new Species(2, synInitAbund, cmaxSyn2, death, 0, false, true, false, 1, 0, 0));
		int AADispersalRadius = dispersalRadius;
		boolean useStep2 = false;
		double[][] cheatSynSynOverTime = new double[3][numReps];
		for (int r = 0; r < numReps; r++)
		{
			
			Community com = new Community(gridLength, .1, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
			double[] temp = com.finalValue(numSteps,reportDensity);
			cheatSynSynOverTime[0][r] = temp[0];
			cheatSynSynOverTime[1][r] = temp[1];
			cheatSynSynOverTime[2][r] = temp[2];
		}

		double syn1Mean = MeanAndSD.meanAcrossColumns(cheatSynSynOverTime, 1);
		double syn1SD = MeanAndSD.SDAcrossColumns(cheatSynSynOverTime, 1, syn1Mean);

		double syn2Mean = MeanAndSD.meanAcrossColumns(cheatSynSynOverTime, 2);
		double syn2SD = MeanAndSD.SDAcrossColumns(cheatSynSynOverTime, 2, syn2Mean);

		double quantCheatMean = MeanAndSD.meanAcrossColumns(cheatSynSynOverTime, 0);
		double quantCheatSD = MeanAndSD.SDAcrossColumns(cheatSynSynOverTime, 0, quantCheatMean);

		double[] results = new double[6];
		results[0] = quantCheatMean;
		results[1] = syn1Mean;
		results[2] = syn2Mean;
		results[3] = quantCheatSD;
		results[4] = syn1SD;
		results[5] = syn2SD;

		return results;

	}

	public static double[][] timeSeriesSimple(int numSteps, int measureHowOften)
	{

		int AADispersalRadius = dispersalRadius;
		boolean useStep2 = false;
		Community com = new Community(gridLength, .1, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return com.timeSeries(numSteps, measureHowOften, false);
	}

	public static String[] timeSeriesHeaderSimple()
	{
		int AADispersalRadius = dispersalRadius;
		boolean useStep2 = false;
		Community com = new Community(gridLength, .1, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return com.headerForTimeSeries();
	}

	public static String[] timeSeriesHeader(boolean dontUse0, boolean dontUse1, boolean dontUse2, boolean dontUse3, boolean dontUse12, boolean dontUse13, boolean dontUse23, boolean dontUse123)
	{
		speciesList = new ArrayList<Species>();

		if (!dontUse0)
		{
			speciesList.add(new Species(0, 20, .90, 0.10, 0, false, false, false, false, 1, 1, 1));
		}
		if (!dontUse1)
		{
			speciesList.add(new Species(1, 20, .85, 0.10, 0, false, true, false, false, 0, 1, 1));
		}
		if (!dontUse2)
		{
			speciesList.add(new Species(2, 20, .85, 0.10, 0, false, false, true, false, 1, 0, 1));
		}
		if (!dontUse3)
		{
			speciesList.add(new Species(3, 20, .85, 0.10, 0, false, false, false, true, 1, 1, 0));
		}
		if (!dontUse12)
		{
			speciesList.add(new Species(12, 20, .80, 0.10, 0, false, true, true, false, 0, 0, 1));
		}
		if (!dontUse13)
		{
			speciesList.add(new Species(13, 20, .80, 0.10, 0, false, true, false, true, 0, 1, 0));
		}
		if (!dontUse23)
		{
			speciesList.add(new Species(23, 20, .80, 0.10, 0, false, false, true, true, 1, 0, 0));
		}
		if (!dontUse123)
		{
			speciesList.add(new Species(123, 20, .75, 0.10, 0, false, true, true, true, 0, 0, 0));
		}
		
		int AADispersalRadius = dispersalRadius;
		boolean useStep2 = false;
		Community com = new Community(gridLength, .1, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return com.headerForTimeSeries();
	}

	public static int[][][] gridTimeSeries(int numSteps, int measureHowOften, int gridLength, double propToStart, int dispersalRadius, double death, double KAAProduced, double cmaxCheater,
			double AA1Cost, double AA2Cost, double AA3Cost, boolean dontUse0, boolean dontUse1, boolean dontUse2, boolean dontUse3, boolean dontUse12, boolean dontUse13, boolean dontUse23,
			boolean dontUse123)
	{
		speciesList = new ArrayList<Species>();

		if (!dontUse0)
		{
			speciesList.add(new Species(0, 20, .90, 0.10, 0,  false, false, false, 1, 1, 1));
		}
		if (!dontUse1)
		{
			speciesList.add(new Species(1, 20, .85, 0.10, 0,  true, false, false, 0, 1, 1));
		}
		if (!dontUse2)
		{
			speciesList.add(new Species(2, 20, .85, 0.10, 0,  false, true, false, 1, 0, 1));
		}
		if (!dontUse3)
		{
			speciesList.add(new Species(3, 20, .85, 0.10, 0,  false, false, true, 1, 1, 0));
		}
		if (!dontUse12)
		{
			speciesList.add(new Species(12, 20, .80, 0.10, 0,  true, true, false, 0, 0, 1));
		}
		if (!dontUse13)
		{
			speciesList.add(new Species(13, 20, .80, 0.10, 0,  true, false, true, 0, 1, 0));
		}
		if (!dontUse23)
		{
			speciesList.add(new Species(23, 20, .80, 0.10, 0,  false, true, true, 1, 0, 0));
		}
		if (!dontUse123)
		{
			speciesList.add(new Species(123, 20, .75, 0.10, 0,  true, true, true, 0, 0, 0));
		}

		for (int i = 0; i < speciesList.size(); i++)
		{
			double totalCost = 0;
			Species currentSpecies = speciesList.get(i);
			if (currentSpecies.makesAA1())
			{
				totalCost += AA1Cost;
			}
			if (currentSpecies.makesAA2())
			{
				totalCost += AA2Cost;
			}
			if (currentSpecies.makesAA3())
			{
				totalCost += AA3Cost;
			}
			currentSpecies.setCmax(cmaxCheater * Math.exp(-totalCost));
		}

		int initAbund = (int) Math.round((propToStart / (double) speciesList.size()) * Math.pow(gridLength, 2));

		for (int i = 0; i < speciesList.size(); i++)
		{
			Species currentSpecies = speciesList.get(i);
			currentSpecies.setD(death);
			currentSpecies.setInitialAbundance(initAbund);

		}

		int AADispersalRadius = dispersalRadius;
		boolean useStep2 = false;
		Community com = new Community(gridLength, .1, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return com.gridTimeSeries(numSteps, measureHowOften);
	}
	

	public static int[][][] mygridTimeSeries(int numSteps, int measureHowOften, int gridLength, double propToStart, int dispersalRadius, double death, double KAAProduced,
			double b1, double b2, double b0, boolean use0, int inocTime)
	{
		speciesList = new ArrayList<Species>();

		int initAbund = (int) Math.round((propToStart / (double) 2) * Math.pow(gridLength, 2));

		speciesList.add(new Species(1, initAbund, b1, death, 1,  false, true, false, false, 0, 1, 0));
		speciesList.add(new Species(2, initAbund, b2, death, 1,  false, false, true, false, 1, 0, 0));
		
		if (use0)
		{
			//Species(int speciesName1, int initialAbundance, double cmax, double d, int inoculateWhen, boolean inoculateOverwrite, /*int dispersalRadius,*/
			//		boolean makesAA1, boolean makesAA2, boolean makesAA3,
			//		double AA1K, double AA2K, double AA3K  -> these are the required amount)

			speciesList.add(new Species(0, 50, b0, death, inocTime,  false, false, false, false, 1, 1, 0));
			
		}
		
		int AADispersalRadius = dispersalRadius;
		boolean useStep2 = true;
		Community com = new Community(gridLength, 1, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return com.gridTimeSeries(numSteps, measureHowOften);
	}
	/*
	 * public static int[][] timeSeriesComplicated(int dispersalRadius, int gridLength, int numSteps, int measureHowOften, boolean useS123, int s123InitAbund, double s123Cmax, double s123D, boolean useS23, int s23InitAbund, double s23Cmax, double s23D, int s23AA1K, boolean useS13, int s13InitAbund, double s13Cmax, double s13D, int s13AA2K, boolean useS12, int s12InitAbund, double s12Cmax, double s12D, int s12AA3K, boolean useS3, int s3InitAbund, double s3Cmax, double s3D, int s3AA1K, int s3AA2K, boolean useS2, int s2InitAbund, double s2Cmax, double s2D, int s2AA1K, int s2AA3K, boolean useS1, int s1InitAbund, double s1Cmax, double s1D, int s1AA2K, int s1AA3K, boolean useS0, int s0InitAbund, double s0Cmax, double s0D, int s0AA1K, int s0AA2K, int s0AA3K) {
	 * 
	 * speciesList = new ArrayList<Species>(); if (useS123) { speciesList.add(new Species(123, s123InitAbund, s123Cmax, s123D, true, true, true, 0, 0, 0)); } if (useS23) { speciesList.add(new Species(23, s23InitAbund, s23Cmax, s23D, false, true, true, s23AA1K, 0, 0)); } if (useS13) { speciesList.add(new Species(13, s13InitAbund, s13Cmax, s13D, true, false, true, 0, s13AA2K, 0)); } if (useS12) { speciesList.add(new Species(12, s12InitAbund, s12Cmax, s12D, true, true, false, 0, 0, s12AA3K)); } if (useS3) { speciesList.add(new Species(3, s3InitAbund, s3Cmax, s3D, false, false, true, s3AA1K, s3AA2K, 0)); } if (useS2) { speciesList.add(new Species(1, s2InitAbund, s2Cmax, s2D, false, true, false, s2AA1K, 0, s2AA3K)); } if (useS1) { speciesList.add(new Species(2, s1InitAbund, s1Cmax, s1D, true, false, false, 0, s1AA2K, s1AA3K)); } if (useS0) { speciesList.add(new Species(0, s0InitAbund, s0Cmax, s0D, false, false, false, s0AA1K, s0AA2K, s0AA3K)); }
	 * 
	 * com = new Community(gridLength, speciesList); return com.timeSeries(dispersalRadius, numSteps, measureHowOften); }
	 */

	
	public static int[][][] gridTimeSeries(int start, int end, int measureHowOften, int gridLength, int dispersalRadius, double KAAProduced, boolean useSharedInitProp, double initProp, boolean useSharedDeathProb,
			double deathProb, boolean use0, double initProp0, double cmax0, double death0, int inoculateWhen0, int AA1Kx0, int AA2Kx0, int AA3Kx0, boolean use1, double initProp1, double cmax1, double death1, int inoculateWhen1, int AA1Kx1,
			int AA2Kx1, int AA3Kx1, boolean use2, double initProp2, double cmax2, double death2, int inoculateWhen2, int AA1Kx2, int AA2Kx2, int AA3Kx2, boolean use3, double initProp3, double cmax3, double death3,  int inoculateWhen3,
			int AA1Kx3, int AA2Kx3, int AA3Kx3, boolean use12, double initProp12, double cmax12, double death12,  int inoculateWhen12, int AA1Kx12, int AA2Kx12, int AA3Kx12, boolean use23, double initProp23,
			double cmax23, double death23, int inoculateWhen23, int AA1Kx23, int AA2Kx23, int AA3Kx23, boolean use13, double initProp13, double cmax13, double death13,  int inoculateWhen13, int AA1Kx13, int AA2Kx13, int AA3Kx13,
			boolean use123, double initProp123, double cmax123, double death123,  int inoculateWhen123, int AA1Kx123, int AA2Kx123, int AA3Kx123)
	{
		speciesList = new ArrayList<Species>();

		if (use0)
		{
			speciesList.add(new Species(0, abundFromProp(initProp0), cmax0, death0, inoculateWhen0, false, false, false, AA1Kx0, AA2Kx0, AA3Kx0));
		}
		if (use1)
		{
			speciesList.add(new Species(1, abundFromProp(initProp1), cmax1, death1, inoculateWhen1,true, false, false, AA1Kx1, AA2Kx1, AA3Kx1));
		}
		if (use2)
		{
			speciesList.add(new Species(2, abundFromProp(initProp2), cmax2, death2, inoculateWhen2, false, true, false, AA1Kx2, AA2Kx2, AA3Kx2));
		}
		if (use3)
		{
			speciesList.add(new Species(3, abundFromProp(initProp3), cmax3, death3, inoculateWhen3, false, false, true, AA1Kx3, AA2Kx3, AA3Kx3));
		}
		if (use12)
		{
			speciesList.add(new Species(12, abundFromProp(initProp12), cmax12, death12, inoculateWhen12, true, true, false, AA1Kx12, AA2Kx12, AA3Kx12));
		}
		if (use23)
		{
			speciesList.add(new Species(23, abundFromProp(initProp23), cmax23, death23, inoculateWhen23, true, false, true, AA1Kx23, AA2Kx23, AA3Kx23));
		}
		if (use13)
		{
			speciesList.add(new Species(13, abundFromProp(initProp13), cmax13, death13, inoculateWhen13, false, true, true, AA1Kx13, AA2Kx13, AA3Kx13));
		}
		if (use123)
		{
			speciesList.add(new Species(123, abundFromProp(initProp123), cmax123, death123, inoculateWhen123, true, true, true, AA1Kx123, AA2Kx123, AA3Kx123));
		}

		if (useSharedInitProp)
		{
			int initAbund = (int) Math.round((initProp / (double) speciesList.size()) * Math.pow(gridLength, 2));

			for (int i = 0; i < speciesList.size(); i++)
			{
				Species currentSpecies = speciesList.get(i);
				currentSpecies.setInitialAbundance(initAbund);

			}
		}

		if (useSharedDeathProb)
		{

			for (int i = 0; i < speciesList.size(); i++)
			{
				Species currentSpecies = speciesList.get(i);
				currentSpecies.setD(deathProb);

			}
		}
		int AADispersalRadius = dispersalRadius;
		
		boolean useStep2 = false;
		Community com = new Community(gridLength, .1, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		
		return com.gridTimeSeries(start, end, measureHowOften);
	}
	
	
	public static int[][][] simonGridSeries(int numSteps, int measureHowOften, int gridLength, double propToStart, 
			int dispersalRadius, int AADispersalRadius, double death, double KAAProduced,
			double b0, double b1, double b2, double b12, double dt)
	{
		speciesList = new ArrayList<Species>();

		int sp0start;
		int spSynstart;
		int sp12start;
		
		if(b0>0)
		{
			sp0start = 1;
		}
		else
		{
			sp0start = 0;
		}
		
		if(b1>0)
		{
			spSynstart = 1;
		}
		else
		{
			spSynstart = 0;
		}
		
		if(b12>0)
		{
			sp12start = 1;
		}
		else
		{
			sp12start = 0;
		}
			
		
		int initAbund = (int) Math.round((propToStart / (double) (sp0start+2*spSynstart+sp12start)) * Math.pow(gridLength, 2));


		speciesList.add(new Species(12, initAbund*sp12start, b12, death, 1,  false, true, true, false, 1, 1, 0));
		speciesList.add(new Species(2, initAbund*spSynstart, b2, death, 1,  false, false, true, false, 1, 0, 0));
		speciesList.add(new Species(1, initAbund*spSynstart, b1, death, 1,  false, true, false, false, 0, 1, 0));
		speciesList.add(new Species(0, initAbund*sp0start, b0, death, 1,  false, false, false, false, 1, 1, 0));
		
			//Species(int speciesName1, int initialAbundance, double cmax, double d, int inoculateWhen, boolean inoculateOverwrite, /*int dispersalRadius,*/
			//		boolean makesAA1, boolean makesAA2, boolean makesAA3,
			//		double AA1K, double AA2K, double AA3K  -> these are the required amount)
	
		
		boolean useStep2 = true;
		Community com = new Community(gridLength, dt, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return com.gridTimeSeries((int) Math.round(numSteps / dt), (int) Math.round(measureHowOften/ dt));
	}
	
	public static int[][][] simonScatterSeries(int numSteps, int measureHowOften, int gridLength, double propToStart, 
			int dispersalRadius, int AADispersalRadius, double death, double KAAProduced,
			double b0, double b1, double b2, double b12, double dt)
	{
		speciesList = new ArrayList<Species>();

		int sp0start;
		int spSynstart;
		int sp12start;
		
		if(b0>0)
		{
			sp0start = 1;
		}
		else
		{
			sp0start = 0;
		}
		
		if(b1>0)
		{
			spSynstart = 1;
		}
		else
		{
			spSynstart = 0;
		}
		
		if(b12>0)
		{
			sp12start = 1;
		}
		else
		{
			sp12start = 0;
		}
			
		
		int initAbund = (int) Math.round((propToStart / (double) (sp0start+2*spSynstart+sp12start)) * Math.pow(gridLength, 2));


		speciesList.add(new Species(12, initAbund*sp12start, b12, death, 1,  false, true, true, false, 1, 1, 0));
		speciesList.add(new Species(2, initAbund*spSynstart, b2, death, 1,  false, false, true, false, 1, 0, 0));
		speciesList.add(new Species(1, initAbund*spSynstart, b1, death, 1,  false, true, false, false, 0, 1, 0));
		speciesList.add(new Species(0, initAbund*sp0start, b0, death, 1,  false, false, false, false, 1, 1, 0));
		
			//Species(int speciesName1, int initialAbundance, double cmax, double d, int inoculateWhen, boolean inoculateOverwrite, /*int dispersalRadius,*/
			//		boolean makesAA1, boolean makesAA2, boolean makesAA3,
			//		double AA1K, double AA2K, double AA3K  -> these are the required amount)
	
		
		boolean useStep2 = true;
		Community com = new Community(gridLength, dt, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return com.gridTimeSeriesScatter((int) Math.round(numSteps / dt), (int) Math.round(measureHowOften/ dt));
	}
	
	public static int[][][] simonGridSeries2(int numSteps, int measureHowOften, int gridLength, double n0start, 
			double nsstart, double n12start,  
			int dispersalRadius, int AADispersalRadius, double death, double KAAProduced,
			double b0, double b1, double b2, double b12, double dt)
	{
		speciesList = new ArrayList<Species>();

		int sp0start;
		int spSynstart;
		int sp12start;
		
		if(b0>0)
		{
			sp0start = (int) Math.round(n0start * (double) Math.pow(gridLength, 2));
		}
		else
		{
			sp0start = 0;
		}
		
		if(b1>0)
		{
			spSynstart = (int) Math.round(nsstart * (double) Math.pow(gridLength, 2));;
		}
		else
		{
			spSynstart = 0;
		}
		
		if(b12>0)
		{
			sp12start = (int) Math.round(n12start * (double) Math.pow(gridLength, 2));;
		}
		else
		{
			sp12start = 0;
		}
			
		

		speciesList.add(new Species(12, sp12start, b12, death, 1,  false, true, true, false, 1, 1, 0));
		speciesList.add(new Species(2, spSynstart, b2, death, 1,  false, false, true, false, 1, 0, 0));
		speciesList.add(new Species(1, spSynstart, b1, death, 1,  false, true, false, false, 0, 1, 0));
		speciesList.add(new Species(0, sp0start, b0, death, 1,  false, false, false, false, 1, 1, 0));
		
			//Species(int speciesName1, int initialAbundance, double cmax, double d, int inoculateWhen, boolean inoculateOverwrite, /*int dispersalRadius,*/
			//		boolean makesAA1, boolean makesAA2, boolean makesAA3,
			//		double AA1K, double AA2K, double AA3K  -> these are the required amount)
	
		
		boolean useStep2 = true;
		Community com = new Community(gridLength, dt, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return com.gridTimeSeries((int) Math.round(numSteps / dt), (int) Math.round(measureHowOften/ dt));
	}
		
	public static int[][][] simonScatterSeries2(int numSteps, int measureHowOften, int gridLength, double n0start, 
			double nsstart, double n12start,  
			int dispersalRadius, int AADispersalRadius, double death, double KAAProduced,
			double b0, double b1, double b2, double b12, double dt)
	{
		speciesList = new ArrayList<Species>();

		int sp0start;
		int spSynstart;
		int sp12start;
		
		if(b0>0)
		{
			sp0start = (int) Math.round(n0start * (double) Math.pow(gridLength, 2));
		}
		else
		{
			sp0start = 0;
		}
		
		if(b1>0)
		{
			spSynstart = (int) Math.round(nsstart * (double) Math.pow(gridLength, 2));;
		}
		else
		{
			spSynstart = 0;
		}
		
		if(b12>0)
		{
			sp12start = (int) Math.round(n12start * (double) Math.pow(gridLength, 2));;
		}
		else
		{
			sp12start = 0;
		}
			
		

		speciesList.add(new Species(12, sp12start, b12, death, 1,  false, true, true, false, 1, 1, 0));
		speciesList.add(new Species(2, spSynstart, b2, death, 1,  false, false, true, false, 1, 0, 0));
		speciesList.add(new Species(1, spSynstart, b1, death, 1,  false, true, false, false, 0, 1, 0));
		speciesList.add(new Species(0, sp0start, b0, death, 1,  false, false, false, false, 1, 1, 0));
		
			//Species(int speciesName1, int initialAbundance, double cmax, double d, int inoculateWhen, boolean inoculateOverwrite, /*int dispersalRadius,*/
			//		boolean makesAA1, boolean makesAA2, boolean makesAA3,
			//		double AA1K, double AA2K, double AA3K  -> these are the required amount)
	
		
		boolean useStep2 = true;
		Community com = new Community(gridLength, dt, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return com.gridTimeSeriesScatter((int) Math.round(numSteps / dt), (int) Math.round(measureHowOften/ dt));
	}
	
}
