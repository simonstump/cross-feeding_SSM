import java.util.ArrayList;

public class MakeSpeciesList
{

	
	public static ArrayList<Species> makeSpeciesList(int gridLength, boolean useSharedInitProp, double initProp, boolean useSharedDeathProb, double deathProb, boolean use0, double initProp0,
			double cmax0, double death0, int inoculateWhen0, boolean inoculateOverwrite0, int AA1Kx0, int AA2Kx0, int AA3Kx0, boolean use1, double initProp1, double cmax1, double death1, int inoculateWhen1, boolean inoculateOverwrite1, int AA1Kx1,
			int AA2Kx1, int AA3Kx1, boolean use2, double initProp2, double cmax2, double death2, int inoculateWhen2, boolean inoculateOverwrite2, int AA1Kx2, int AA2Kx2, int AA3Kx2, boolean use3, double initProp3, double cmax3,
			double death3, int inoculateWhen3, boolean inoculateOverwrite3, int AA1Kx3, int AA2Kx3, int AA3Kx3, boolean use12, double initProp12, double cmax12, double death12, int inoculateWhen12, boolean inoculateOverwrite12, int AA1Kx12, int AA2Kx12,
			int AA3Kx12, boolean use23, double initProp23, double cmax23, double death23, int inoculateWhen23,  boolean inoculateOverwrite23, int AA1Kx23, int AA2Kx23, int AA3Kx23, boolean use13, double initProp13, double cmax13,
			double death13, int inoculateWhen13,  boolean inoculateOverwrite13, int AA1Kx13, int AA2Kx13, int AA3Kx13, boolean use123, double initProp123, double cmax123, double death123, int inoculateWhen123,  boolean inoculateOverwrite123, int AA1Kx123,
			int AA2Kx123, int AA3Kx123)
	{
		
		
		
		ArrayList<Species> speciesList = new ArrayList<Species>();

		if (use0)
		{
			speciesList.add(new Species(0, abundFromProp(initProp0, gridLength), cmax0, death0, inoculateWhen0, inoculateOverwrite0, false, false, false, AA1Kx0, AA2Kx0, AA3Kx0));
		}
		if (use1)
		{
			speciesList.add(new Species(1, abundFromProp(initProp1, gridLength), cmax1, death1, inoculateWhen1, inoculateOverwrite1, true, false, false, AA1Kx1, AA2Kx1, AA3Kx1));
		}
		if (use2)
		{
			speciesList.add(new Species(2, abundFromProp(initProp2, gridLength), cmax2, death2, inoculateWhen2, inoculateOverwrite2, false, true, false, AA1Kx2, AA2Kx2, AA3Kx2));
		}
		if (use3)
		{
			speciesList.add(new Species(3, abundFromProp(initProp3, gridLength), cmax3, death3, inoculateWhen3, inoculateOverwrite3, false, false, true, AA1Kx3, AA2Kx3, AA3Kx3));
		}
		if (use12)
		{
			speciesList.add(new Species(12, abundFromProp(initProp12, gridLength), cmax12, death12, inoculateWhen12, inoculateOverwrite12, true, true, false, AA1Kx12, AA2Kx12, AA3Kx12));
		}
		if (use23)
		{
			speciesList.add(new Species(23, abundFromProp(initProp23, gridLength), cmax23, death23, inoculateWhen23, inoculateOverwrite23, true, false, true, AA1Kx23, AA2Kx23, AA3Kx23));
		}
		if (use13)
		{
			speciesList.add(new Species(13, abundFromProp(initProp13, gridLength), cmax13, death13, inoculateWhen13, inoculateOverwrite13, false, true, true, AA1Kx13, AA2Kx13, AA3Kx13));
		}
		if (use123)
		{
			speciesList.add(new Species(123, abundFromProp(initProp123, gridLength), cmax123, death123, inoculateWhen123, inoculateOverwrite123, true, true, true, AA1Kx123, AA2Kx123, AA3Kx123));
		}

		if (useSharedInitProp)
		{
			int initAbund = (int) Math.round((initProp / (double) speciesList.size()) * Math.pow(gridLength, 2));

			for (int i = 0; i < speciesList.size(); i++)
			{
				Species currentSpecies = speciesList.get(i);
				currentSpecies.setInitialAbundance(initAbund);

			}
		}

		if (useSharedDeathProb)
		{

			for (int i = 0; i < speciesList.size(); i++)
			{
				Species currentSpecies = speciesList.get(i);
				currentSpecies.setD(deathProb);

			}
		}
		return speciesList;
	}

	public static int abundFromProp(double prop, int gridLength)
	{
		return (int) Math.round(prop * (double) Math.pow(gridLength, 2));
	}

}
