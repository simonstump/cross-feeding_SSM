import java.io.IOException;
import java.util.ArrayList;
//import java.util.LinkedList;
//import java.util.ListIterator;
//import java.util.List;
import java.util.Random;
//import java.lang.Math;
// puts it all together. Initializes a patchy environment (is-an envrionment) and species (hasa critter hasa location). These classes are interdependent 
////(i.e. critters don't just go on the grid - critters have locations which indicate their position, and the envrionment is aware of critter locations at each time step)

/**
 * @author Evan
 * This is where simulations are exacted and data is extracted. A Community has three main things: 1) An environment with information about what type of critters are where.
 * 2) a species list with species-specific parameters (e.g. maximum birth rate) 3) instance variables that are called in the time step function
 * 
 * @date 8/18/2016
 */
/**
 * @author Evan
 *
 */
/**
 * @author Evan
 *
 */
/**
 * @author Evan
 *
 */
public class Community
{
	// Species s123, Species s12, Species s13, Species s23, Species s1, Species s2, Species s3, Species s0
	protected ArrayList<Species> speciesList;
	protected Environment env;
	protected int numberOfSpecies;
	// protected double[][] compMatrix;
	protected int gridLength;
	private double dt;
	protected Random generator;
	protected int timeStep;
	protected int dispersalRadius;
	protected double KAAProduced;
	protected int AADispersalRadius;
	protected boolean neverInoculate;
	protected int possibleNeighbors;
	protected int inoculateCounter;
	protected boolean useStep2;
	protected int possibleAANeighbors;
	protected double[][][] AAGrid;
	protected int[][][] critterCountGrid;
	protected double KAAProducedOverPossibleNeighbors;
	protected double KAAProducedOverPossibleAANeighbors;
	protected boolean useMovingWindowForAACounts;
	protected boolean useMovingWindowForCumulativeGrowthRates;
	protected double[][][] posCGR;
	protected double[][][] posAA;
	protected int[][][] posCC;
	protected double[][][] compValuesMat;
	// protected double[][][] CGRGrid;

	/**
	 * boogahdahboo
	 */
	protected int totalSites;

	/**
	 *  takes a community object and constructs an identical communiy object, can be seen as a safe and easy alternative to clone()
	 * 
	 * @param community a Community to be copied
	 */
	public Community(Community community)
	{
		this.generator = community.generator;
		this.dt = community.dt;
		this.timeStep = community.timeStep;
		this.env = community.env;
		this.gridLength = community.gridLength;
		this.totalSites = community.totalSites;
		this.numberOfSpecies = community.numberOfSpecies;
		this.dispersalRadius = community.dispersalRadius;
		this.AADispersalRadius = community.AADispersalRadius;
		this.neverInoculate = community.neverInoculate;
		this.useStep2 = community.useStep2;
		this.KAAProduced = community.KAAProduced;
		this.possibleNeighbors = community.possibleNeighbors;
		this.possibleAANeighbors = community.possibleAANeighbors;
		this.AAGrid = community.AAGrid;
		this.critterCountGrid = community.critterCountGrid;

		this.speciesList = community.speciesList;
		this.KAAProducedOverPossibleNeighbors = community.KAAProducedOverPossibleNeighbors;
		this.KAAProducedOverPossibleAANeighbors = community.KAAProducedOverPossibleAANeighbors;
		this.useMovingWindowForCumulativeGrowthRates = community.useMovingWindowForCumulativeGrowthRates;
		this.posCGR = community.posCGR;
		this.posAA = community.posAA;
		this.posCC = community.posCC;
		this.compValuesMat = community.compValuesMat;
	}

	/**
	 * Sets up a community. Simulation and data grabbing methods will do work on the community
	 * 
	 * @param gridLength the length the square grid environment
	 * @param dt TODO
	 * @param dispersalRadius the "radius" of a square neighborhood within which propagules can be dispersed. Examples: A value of 1 denotes a 3x3 neighboorhood, A value of 2 denotes a 5x5 neighborhood.
	 * @param AADispersalRadius the "radius" of a square neighborhood within which amino acids can be utilized. This parameter is only used in the step2 function
	 * @param KAAProduced the quantity of amino acid that is produced (per type of amino acid) by a single individual. These are distributed evenly between all the neighbors within the dispersalRadius (for step1) or AADispersalRadius (for step2). 
	 * @param useStep2 if false, amino acid availibility affects recruitment. if true, amino acid availibity affects the birth rate of adults.
	 * @param speciesList a list of species objects. A species list can be created with the static [MakeSpeciesList.makeSpeciesList(...)], or with the alternative community constructor
	 */
	public Community(int gridLength, double dt, int dispersalRadius, int AADispersalRadius, double KAAProduced, boolean useStep2, ArrayList<Species> speciesList)
	{
		// assign instance variables
		this.dt = dt;
		this.generator = new Random();
		this.timeStep = 0;
		this.env = new Environment(gridLength);
		this.gridLength = gridLength;
		this.totalSites = this.gridLength * this.gridLength;
		this.speciesList = speciesList;
		this.numberOfSpecies = speciesList.size();
		this.dispersalRadius = dispersalRadius;
		this.AADispersalRadius = AADispersalRadius;
		this.neverInoculate = false;
		this.useStep2 = useStep2;
		this.KAAProduced = KAAProduced;
		int dispersalLength = 1 + this.dispersalRadius * 2;
		this.possibleNeighbors = dispersalLength * dispersalLength - 1;
		int AADispersalLength = 1 + this.AADispersalRadius * 2;
		this.possibleAANeighbors = AADispersalLength * AADispersalLength - 1;
		this.AAGrid = new double[this.gridLength][this.gridLength][3];
		this.critterCountGrid = new int[this.gridLength][this.gridLength][this.numberOfSpecies];
		this.KAAProducedOverPossibleNeighbors = this.KAAProduced / (double) this.possibleNeighbors;
		this.KAAProducedOverPossibleAANeighbors = this.KAAProduced / (double) this.possibleAANeighbors;
		this.posCGR = new double[this.numberOfSpecies][this.gridLength][3];
		this.posAA = new double[3][this.gridLength][3];
		this.posCC = new int[this.numberOfSpecies][this.gridLength][3];
		this.compValuesMat = new double[this.gridLength][this.gridLength][this.numberOfSpecies];

		if (this.AADispersalRadius > 9)
		{
			this.useMovingWindowForAACounts = true;
		}
		if (this.dispersalRadius > 1)
		{
			this.useMovingWindowForCumulativeGrowthRates = true;
		}

		// sets up the numbers that appear end up on the grid
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			this.speciesList.get(i).setGridProxy(i + 1);
		}

		// if none of the species in the species list makes AA3, make it so none of the species need any AA3
		for (int i = 0; i < numberOfSpecies; i++)
		{
			if (speciesList.get(i).makesAA3())
			{
				break;
			}
			if (i == numberOfSpecies - 1)
			{
				noAA3();
			}

		}
		// System.out.println("this.dt is " + dt);
		scaleByDt();

		// randomly adds the specified(in Species class) number of inidividuals to the grid
		/*
		 * for (int s = 0; s < this.numberOfSpecies; s++) { Species curSpecies = this.speciesList.get(s); int val = curSpecies.getGridProxy();
		 * 
		 * // if there's a quantitative cheater, don't inoculate // if (val == 1 && (curSpecies.getAA1K() == 0 || curSpecies.getAA2K() == 0)) // { // continue; // }
		 * 
		 * if (curSpecies.getInoculateWhen() == 0) { int init = curSpecies.getInitialAbundance(); int i = 0; while (i < init) {
		 * 
		 * int row = generator.nextInt(this.env.getGridLength()); int col = generator.nextInt(this.env.getGridLength()); if (this.env.isEmpty(row, col)) { this.env.add(row, col, val); i++; } } } }
		 */
	}

	/**
	 * Sets up a community. Simulation and data grabbing methods will do work on the community.
	 * 
	 * @param gridLength the length the square grid environment.
	 * @param dispersalRadius the "radius" of a square neighborhood within which propagules can be dispersed. Examples: A value of 1 denotes a 3x3 neighboorhood, A value of 2 denotes a 5x5 neighborhood.
	 * @param AADispersalRadius the "radius" of a square neighborhood within which amino acids can be utilized. This parameter is only used in the step2 function.
	 * @param KAAProduced the quantity of amino acid that is produced (per type of amino acid) by a single individuals. These are distributed evenly between all the neighbors within the dispersalRadius (for step1) or AADispersalRadius (for step2). 
	 * @param useStep2 if false, amino acid availibility affects recruitment. if true, amino acid availibity affects the birth rate of adults.
	 * @param speciesList a list of species objects. A species list can be created with the static [MakeSpeciesList.makeSpeciesList(...)], or with the alternative community constructor.
	 * @param useSharedInitProp if true, then all species are assigned the same initial abundance, and the parameters initProp0, initProp1, ... become irrelevant.
	 * @param initProp proportion of microsites occupied by all the species at their inoculation times. Basically, this quantity divided by the number of species gives the proportion of microsites that a species is to hold at inoculation time.
	 * @param useSharedDeathProb if true, then all species are assigned the same probability of death, and the parameters deathProb0, deathProb1, ... become irrelevant.
	 * @param deathProb if useSharedDeathProb is true, then this is the death probability that is assigned to each species.
	 * <p><p><p><p><p><p> note all the following parameters are ended by the number zero. This number denotes the types of amino acids that the species produces. Here, the suffix 0 denotes the cheater-specific parameter while the suffix 123 denotes a generalist-specific parameter.
	 * @param use0 if false, then the species is not used in the simulation. All species-specific parameters with the same identifying suffix are null and void.
	 * @param initProp0 the proportion of microsites that this species is to hold at inoculation time.
	 * @param cmax0 the maximum birth probability.
	 * @param death0 the death probability.
	 * @param inoculateWhen0 at what time step should the species be inoculated into the environment grid.
	 * @param inoculateOverwrite0 if true, then inoculated individuals can overwrite preexisting individuals. If false, then the inoculated individuals must find an empty microsite. If an individual cannot find a microsite after 500 tries, then it can overwrite heterospecifics. see method: inoculateSpecies. 
	 * @param AA1Kx0 the amino acid 1 requirement. If amino acid availability is less than this quantity, then an individual may be limited by this amino acid.
	 * @param AA2Kx0 the amino acid 2 requirement. If amino acid availability is less than this quantity, then an individual may be limited by this amino acid.
	 * @param AA3Kx0 the amino acid 3 requirement. If amino acid availability is less than this quantity, then an individual may be limited by this amino acid.
	 */
	public Community(int gridLength, double dt, int dispersalRadius, int AADispersalRadius, double KAAProduced, boolean useStep2, boolean useSharedInitProp, double initProp,
			boolean useSharedDeathProb, double deathProb, boolean use0, double initProp0, double cmax0, double death0, int inoculateWhen0, boolean inoculateOverwrite0, int AA1Kx0, int AA2Kx0,
			boolean use1, double initProp1, double cmax1, double death1, int inoculateWhen1, boolean inoculateOverwrite1, int AA1Kx1, int AA2Kx1, boolean use2, double initProp2, double cmax2,
			double death2, int inoculateWhen2, boolean inoculateOverwrite2, int AA1Kx2, int AA2Kx2)
	{
		// instantiate a list of species
		this.speciesList = new ArrayList<Species>();

		// add detail to the speciesList in accordance with constructor parameters
		if (use0)
		{
			this.speciesList.add(new Species(0, abundFromProp(initProp0), cmax0, death0, inoculateWhen0, inoculateOverwrite0, false, false, false, AA1Kx0, AA2Kx0, 0));
		}
		if (use1)
		{
			this.speciesList.add(new Species(1, abundFromProp(initProp1), cmax1, death1, inoculateWhen1, inoculateOverwrite1, true, false, false, AA1Kx1, AA2Kx1, 0));
		}
		if (use2)
		{
			this.speciesList.add(new Species(2, abundFromProp(initProp2), cmax2, death2, inoculateWhen2, inoculateOverwrite2, false, true, false, AA1Kx2, AA2Kx2, 0));
		}

		if (useSharedInitProp)
		{
			int initAbund = (int) Math.round((initProp / (double) this.speciesList.size()) * Math.pow(gridLength, 2));

			for (int i = 0; i < this.speciesList.size(); i++)
			{
				Species currentSpecies = this.speciesList.get(i);
				currentSpecies.setInitialAbundance(initAbund);

			}
		}

		if (useSharedDeathProb)
		{

			for (int i = 0; i < this.speciesList.size(); i++)
			{
				Species currentSpecies = this.speciesList.get(i);
				currentSpecies.setD(deathProb);

			}
		}
		// sets up instance variables
		this.generator = new Random();
		this.dt = dt;
		this.timeStep = 0;
		this.env = new Environment(gridLength);
		this.gridLength = gridLength;
		this.totalSites = this.gridLength * this.gridLength;
		this.numberOfSpecies = speciesList.size();
		this.dispersalRadius = dispersalRadius;
		this.AADispersalRadius = AADispersalRadius;
		this.neverInoculate = false;
		this.useStep2 = useStep2;
		this.KAAProduced = KAAProduced;
		int dispersalLength = 1 + this.dispersalRadius * 2;
		this.possibleNeighbors = dispersalLength * dispersalLength - 1;
		int AADispersalLength = 1 + this.AADispersalRadius * 2;
		this.possibleAANeighbors = AADispersalLength * AADispersalLength - 1;
		this.AAGrid = new double[this.gridLength][this.gridLength][3];
		this.critterCountGrid = new int[this.gridLength][this.gridLength][this.numberOfSpecies];
		this.KAAProducedOverPossibleNeighbors = this.KAAProduced / (double) this.possibleNeighbors;
		this.KAAProducedOverPossibleAANeighbors = this.KAAProduced / (double) this.possibleAANeighbors;
		this.posCGR = new double[this.numberOfSpecies][this.gridLength][3];
		this.posAA = new double[3][this.gridLength][3];
		this.posCC = new int[this.numberOfSpecies][this.gridLength][3];
		this.compValuesMat = new double[this.gridLength][this.gridLength][this.numberOfSpecies];

		if (this.AADispersalRadius > 9)
		{
			this.useMovingWindowForAACounts = true;
		}
		if (this.dispersalRadius > 1)
		{
			this.useMovingWindowForCumulativeGrowthRates = true;
		}

		// sets up the numbers that appear end up on the grid
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			this.speciesList.get(i).setGridProxy(i + 1);
		}

		// if none of the species in the species list makes AA3, make it so none of the species need any AA3
		for (int i = 0; i < numberOfSpecies; i++)
		{
			if (speciesList.get(i).makesAA3())
			{
				break;
			}
			if (i == numberOfSpecies - 1)
			{
				noAA3();
			}

		}

		scaleByDt();
	}

	/**
	 * Sets up a community. Simulation and data grabbing methods will do work on the community.
	 * 
	 * @param gridLength the length the square grid environment.
	 * @param dispersalRadius the "radius" of a square neighborhood within which propagules can be dispersed. Examples: A value of 1 denotes a 3x3 neighboorhood, A value of 2 denotes a 5x5 neighborhood.
	 * @param AADispersalRadius the "radius" of a square neighborhood within which amino acids can be utilized. This parameter is only used in the step2 function.
	 * @param KAAProduced the quantity of amino acid that is produced (per type of amino acid) by a single individuals. These are distributed evenly between all the neighbors within the dispersalRadius (for step1) or AADispersalRadius (for step2). 
	 * @param useStep2 if false, amino acid availibility affects recruitment. if true, amino acid availibity affects the birth rate of adults.
	 * @param speciesList a list of species objects. A species list can be created with the static [MakeSpeciesList.makeSpeciesList(...)], or with the alternative community constructor.
	 * @param useSharedInitProp if true, then all species are assigned the same initial abundance, and the parameters initProp0, initProp1, ... become irrelevant.
	 * @param initProp proportion of microsites occupied by all the species at their inoculation times. Basically, this quantity divided by the number of species gives the proportion of microsites that a species is to hold at inoculation time.
	 * @param useSharedDeathProb if true, then all species are assigned the same probability of death, and the parameters deathProb0, deathProb1, ... become irrelevant.
	 * @param deathProb if useSharedDeathProb is true, then this is the death probability that is assigned to each species.
	 * <p><p><p><p><p><p> note all the following parameters are ended by the number zero. This number denotes the types of amino acids that the species produces. Here, the suffix 0 denotes the cheater-specific parameter while the suffix 123 denotes a generalist-specific parameter.
	 * @param use0 if false, then the species is not used in the simulation. All species-specific parameters with the same identifying suffix are null and void.
	 * @param initProp0 the proportion of microsites that this species is to hold at inoculation time.
	 * @param cmax0 the maximum birth probability.
	 * @param death0 the death probability.
	 * @param inoculateWhen0 at what time step should the species be inoculated into the environment grid.
	 * @param inoculateOverwrite0 if true, then inoculated individuals can overwrite preexisting individuals. If false, then the inoculated individuals must find an empty microsite. If an individual cannot find a microsite after 500 tries, then it can overwrite heterospecifics. see method: inoculateSpecies. 
	 * @param AA1Kx0 the amino acid 1 requirement. If amino acid availability is less than this quantity, then an individual may be limited by this amino acid.
	 * @param AA2Kx0 the amino acid 2 requirement. If amino acid availability is less than this quantity, then an individual may be limited by this amino acid.
	 * @param AA3Kx0 the amino acid 3 requirement. If amino acid availability is less than this quantity, then an individual may be limited by this amino acid.
	 */
	public Community(int gridLength, double dt, int dispersalRadius, int AADispersalRadius, double KAAProduced, boolean useStep2, boolean useSharedInitProp, double initProp,
			boolean useSharedDeathProb, double deathProb, boolean use0, double initProp0, double cmax0, double death0, int inoculateWhen0, boolean inoculateOverwrite0, int AA1Kx0, int AA2Kx0,
			int AA3Kx0, boolean use1, double initProp1, double cmax1, double death1, int inoculateWhen1, boolean inoculateOverwrite1, int AA1Kx1, int AA2Kx1, int AA3Kx1, boolean use2,
			double initProp2, double cmax2, double death2, int inoculateWhen2, boolean inoculateOverwrite2, int AA1Kx2, int AA2Kx2, int AA3Kx2, boolean use3, double initProp3, double cmax3,
			double death3, int inoculateWhen3, boolean inoculateOverwrite3, int AA1Kx3, int AA2Kx3, int AA3Kx3, boolean use12, double initProp12, double cmax12, double death12, int inoculateWhen12,
			boolean inoculateOverwrite12, int AA1Kx12, int AA2Kx12, int AA3Kx12, boolean use23, double initProp23, double cmax23, double death23, int inoculateWhen23, boolean inoculateOverwrite23,
			int AA1Kx23, int AA2Kx23, int AA3Kx23, boolean use13, double initProp13, double cmax13, double death13, int inoculateWhen13, boolean inoculateOverwrite13, int AA1Kx13, int AA2Kx13,
			int AA3Kx13, boolean use123, double initProp123, double cmax123, double death123, int inoculateWhen123, boolean inoculateOverwrite123, int AA1Kx123, int AA2Kx123, int AA3Kx123)
	{
		// instantiate a list of species
		this.speciesList = new ArrayList<Species>();

		// add detail to the speciesList in accordance with constructor parameters
		if (use0)
		{
			this.speciesList.add(new Species(0, abundFromProp(initProp0), cmax0, death0, inoculateWhen0, inoculateOverwrite0, false, false, false, AA1Kx0, AA2Kx0, AA3Kx0));
		}
		if (use1)
		{
			this.speciesList.add(new Species(1, abundFromProp(initProp1), cmax1, death1, inoculateWhen1, inoculateOverwrite1, true, false, false, AA1Kx1, AA2Kx1, AA3Kx1));
		}
		if (use2)
		{
			this.speciesList.add(new Species(2, abundFromProp(initProp2), cmax2, death2, inoculateWhen2, inoculateOverwrite2, false, true, false, AA1Kx2, AA2Kx2, AA3Kx2));
		}
		if (use3)
		{
			this.speciesList.add(new Species(3, abundFromProp(initProp3), cmax3, death3, inoculateWhen3, inoculateOverwrite3, false, false, true, AA1Kx3, AA2Kx3, AA3Kx3));
		}
		if (use12)
		{
			this.speciesList.add(new Species(12, abundFromProp(initProp12), cmax12, death12, inoculateWhen12, inoculateOverwrite12, true, true, false, AA1Kx12, AA2Kx12, AA3Kx12));
		}
		if (use23)
		{
			this.speciesList.add(new Species(23, abundFromProp(initProp23), cmax23, death23, inoculateWhen23, inoculateOverwrite23, true, false, true, AA1Kx23, AA2Kx23, AA3Kx23));
		}
		if (use13)
		{
			this.speciesList.add(new Species(13, abundFromProp(initProp13), cmax13, death13, inoculateWhen13, inoculateOverwrite13, false, true, true, AA1Kx13, AA2Kx13, AA3Kx13));
		}
		if (use123)
		{
			this.speciesList.add(new Species(123, abundFromProp(initProp123), cmax123, death123, inoculateWhen123, inoculateOverwrite123, true, true, true, AA1Kx123, AA2Kx123, AA3Kx123));
		}

		if (useSharedInitProp)
		{
			int initAbund = (int) Math.round((initProp / (double) this.speciesList.size()) * Math.pow(gridLength, 2));

			for (int i = 0; i < this.speciesList.size(); i++)
			{
				Species currentSpecies = this.speciesList.get(i);
				currentSpecies.setInitialAbundance(initAbund);

			}
		}

		if (useSharedDeathProb)
		{

			for (int i = 0; i < this.speciesList.size(); i++)
			{
				Species currentSpecies = this.speciesList.get(i);
				currentSpecies.setD(deathProb);

			}
		}
		// sets up instance variables
		this.generator = new Random();
		this.dt = dt;
		this.timeStep = 0;
		this.env = new Environment(gridLength);
		this.gridLength = gridLength;
		this.totalSites = this.gridLength * this.gridLength;
		this.numberOfSpecies = speciesList.size();
		this.dispersalRadius = dispersalRadius;
		this.AADispersalRadius = AADispersalRadius;
		this.neverInoculate = false;
		this.useStep2 = useStep2;
		this.KAAProduced = KAAProduced;
		int dispersalLength = 1 + this.dispersalRadius * 2;
		this.possibleNeighbors = dispersalLength * dispersalLength - 1;
		int AADispersalLength = 1 + this.AADispersalRadius * 2;
		this.possibleAANeighbors = AADispersalLength * AADispersalLength - 1;
		this.AAGrid = new double[this.gridLength][this.gridLength][3];
		this.critterCountGrid = new int[this.gridLength][this.gridLength][this.numberOfSpecies];
		this.KAAProducedOverPossibleNeighbors = this.KAAProduced / (double) this.possibleNeighbors;
		this.KAAProducedOverPossibleAANeighbors = this.KAAProduced / (double) this.possibleAANeighbors;
		this.posCGR = new double[this.numberOfSpecies][this.gridLength][3];
		this.posAA = new double[3][this.gridLength][3];
		this.posCC = new int[this.numberOfSpecies][this.gridLength][3];
		this.compValuesMat = new double[this.gridLength][this.gridLength][this.numberOfSpecies];

		if (this.AADispersalRadius > 9)
		{
			this.useMovingWindowForAACounts = true;
		}
		if (this.dispersalRadius > 1)
		{
			this.useMovingWindowForCumulativeGrowthRates = true;
		}

		// sets up the numbers that appear end up on the grid
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			this.speciesList.get(i).setGridProxy(i + 1);
		}

		// if none of the species in the species list makes AA3, make it so none of the species need any AA3
		for (int i = 0; i < numberOfSpecies; i++)
		{
			if (speciesList.get(i).makesAA3())
			{
				break;
			}
			if (i == numberOfSpecies - 1)
			{
				noAA3();
			}

		}

		scaleByDt();
	}

	/*
	 * public Community(int numMeasurements, int timeBetweenMeasurements, double tooLow, double tooHigh, int inoculateWhen, int stepsAfterInoculation, double dt, int gridLength, int AADispersalRadius, int dispersalRadius, double KAAProduced, double death, double initCMaxCheat, double deltaB0, double cMaxSyn1, double cMaxSyn2, boolean useStep2, double initProp0, double AA1Kx0, double AA2Kx0, double AA1Kx1, double AA2Kx1, double AA1Kx2, double AA2Kx2) {
	 * 
	 * this.gridLength = gridLength; this.totalSites = this.gridLength * this.gridLength; double cmax0 = initCMaxCheat;
	 * 
	 * ArrayList<Species> speciesList = new ArrayList<Species>();
	 * 
	 * speciesList.add(new Species(0, abundFromProp(initProp0), cmax0, death, inoculateWhen, false, false, false, AA1Kx0, AA2Kx0, 0));
	 * 
	 * speciesList.add(new Species(1, abundFromProp(0.30), cMaxSyn1, death, 0, true, false, false, AA1Kx1, AA2Kx1, 0));
	 * 
	 * speciesList.add(new Species(2, abundFromProp(0.30), cMaxSyn2, death, 0, false, true, false, AA1Kx2, AA2Kx2, 0));
	 * 
	 * // assign instance variables this.dt = dt; this.generator = new Random(); this.timeStep = 0; this.env = new Environment(gridLength);
	 * 
	 * this.speciesList = speciesList; this.numberOfSpecies = speciesList.size(); this.dispersalRadius = dispersalRadius; this.AADispersalRadius = AADispersalRadius; this.neverInoculate = false; this.useStep2 = useStep2; this.KAAProduced = KAAProduced; int dispersalLength = 1 + this.dispersalRadius * 2; this.possibleNeighbors = dispersalLength * dispersalLength - 1; int AADispersalLength = 1 + this.AADispersalRadius * 2; this.possibleAANeighbors = AADispersalLength * AADispersalLength - 1; this.AAGrid = new double[this.gridLength][this.gridLength][3]; this.critterCountGrid = new int[this.gridLength][this.gridLength][this.numberOfSpecies]; this.KAAProducedOverPossibleNeighbors = this.KAAProduced / (double) this.possibleNeighbors; this.KAAProducedOverPossibleAANeighbors = this.KAAProduced / (double) this.possibleAANeighbors; this.posCGR = new double[this.numberOfSpecies][this.gridLength][3]; this.posAA = new double[3][this.gridLength][3]; this.posCC = new
	 * int[this.numberOfSpecies][this.gridLength][3]; this.compValuesMat = new double[this.gridLength][this.gridLength][this.numberOfSpecies];
	 * 
	 * if (this.AADispersalRadius > 9) { this.useMovingWindowForAACounts = true; } if (this.dispersalRadius > 1) { this.useMovingWindowForCumulativeGrowthRates = true; }
	 * 
	 * // sets up the numbers that appear end up on the grid for (int i = 0; i < this.numberOfSpecies; i++) { this.speciesList.get(i).setGridProxy(i + 1); }
	 * 
	 * // if none of the species in the species list makes AA3, make it so none of the species need any AA3 for (int i = 0; i < numberOfSpecies; i++) { if (speciesList.get(i).makesAA3()) { break; } if (i == numberOfSpecies - 1) { noAA3(); }
	 * 
	 * } scaleByDt(); }
	 */

	public Community(int gridLength, double dt, int dispersalRadius, int AADispersalRadius, double KAAProduced, boolean useStep2, boolean useSharedInitProp, double initProp,
			boolean useSharedDeathProb, double deathProb, boolean use0, double initProp0, double cmax0, double death0, int inoculateWhen0, boolean inoculateOverwrite0, int AA1Kx0, int AA2Kx0,
			boolean use1, double initProp1, double cmax1, double death1, int inoculateWhen1, boolean inoculateOverwrite1, int AA1Kx1, int AA2Kx1, boolean use2, double initProp2, double cmax2,
			double death2, int inoculateWhen2, boolean inoculateOverwrite2, int AA1Kx2, int AA2Kx2, boolean use12, double initProp12, double cmax12, double death12, int inoculateWhen12,
			boolean inoculateOverwrite12, int AA1Kx12, int AA2Kx12)
	{
		// instantiate a list of species
		this.speciesList = new ArrayList<Species>();

		// add detail to the speciesList in accordance with constructor parameters
		if (use0)
		{
			this.speciesList.add(new Species(0, abundFromProp(initProp0), cmax0, death0, inoculateWhen0, inoculateOverwrite0, false, false, false, AA1Kx0, AA2Kx0, 0));
		}
		if (use1)
		{
			this.speciesList.add(new Species(1, abundFromProp(initProp1), cmax1, death1, inoculateWhen1, inoculateOverwrite1, true, false, false, AA1Kx1, AA2Kx1, 0));
		}
		if (use2)
		{
			this.speciesList.add(new Species(2, abundFromProp(initProp2), cmax2, death2, inoculateWhen2, inoculateOverwrite2, false, true, false, AA1Kx2, AA2Kx2, 0));
		}
		if (use12)
		{
			this.speciesList.add(new Species(12, abundFromProp(initProp12), cmax12, death12, inoculateWhen12, inoculateOverwrite12, true, true, false, AA1Kx12, AA2Kx12, 0));
		}

		if (useSharedInitProp)
		{
			int initAbund = (int) Math.round((initProp / (double) this.speciesList.size()) * Math.pow(gridLength, 2));

			for (int i = 0; i < this.speciesList.size(); i++)
			{
				Species currentSpecies = this.speciesList.get(i);
				currentSpecies.setInitialAbundance(initAbund);

			}
		}

		if (useSharedDeathProb)
		{

			for (int i = 0; i < this.speciesList.size(); i++)
			{
				Species currentSpecies = this.speciesList.get(i);
				currentSpecies.setD(deathProb);

			}
		}
		// sets up instance variables
		this.generator = new Random();
		this.dt = dt;
		this.timeStep = 0;
		this.env = new Environment(gridLength);
		this.gridLength = gridLength;
		this.totalSites = this.gridLength * this.gridLength;
		this.numberOfSpecies = speciesList.size();
		this.dispersalRadius = dispersalRadius;
		this.AADispersalRadius = AADispersalRadius;
		this.neverInoculate = false;
		this.useStep2 = useStep2;
		this.KAAProduced = KAAProduced;
		int dispersalLength = 1 + this.dispersalRadius * 2;
		this.possibleNeighbors = dispersalLength * dispersalLength - 1;
		int AADispersalLength = 1 + this.AADispersalRadius * 2;
		this.possibleAANeighbors = AADispersalLength * AADispersalLength - 1;
		this.AAGrid = new double[this.gridLength][this.gridLength][3];
		this.critterCountGrid = new int[this.gridLength][this.gridLength][this.numberOfSpecies];
		this.KAAProducedOverPossibleNeighbors = this.KAAProduced / (double) this.possibleNeighbors;
		this.KAAProducedOverPossibleAANeighbors = this.KAAProduced / (double) this.possibleAANeighbors;
		this.posCGR = new double[this.numberOfSpecies][this.gridLength][3];
		this.posAA = new double[3][this.gridLength][3];
		this.posCC = new int[this.numberOfSpecies][this.gridLength][3];
		this.compValuesMat = new double[this.gridLength][this.gridLength][this.numberOfSpecies];

		if (this.AADispersalRadius > 9)
		{
			this.useMovingWindowForAACounts = true;
		}
		if (this.dispersalRadius > 1)
		{
			this.useMovingWindowForCumulativeGrowthRates = true;
		}

		// sets up the numbers that appear end up on the grid
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			this.speciesList.get(i).setGridProxy(i + 1);
		}

		// if none of the species in the species list makes AA3, make it so none of the species need any AA3
		for (int i = 0; i < numberOfSpecies; i++)
		{
			if (speciesList.get(i).makesAA3())
			{
				break;
			}
			if (i == numberOfSpecies - 1)
			{
				noAA3();
			}

		}

		scaleByDt();
	}

	// used to see if the moving window algorithms give the same result as a simple (fool proof) case.
	public double[][][] AAGridTest()
	{
		double[][][] testGrid = new double[this.gridLength][this.gridLength][3];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{

				for (int row2 = row - this.AADispersalRadius; row2 <= row + this.AADispersalRadius; row2++)
				{
					for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
					{

						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);

						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								testGrid[row][col][0] += this.KAAProducedOverPossibleAANeighbors;
								/*
								 * if (row == 3 && col == 3) { System.out.print(this.KAAProducedOverPossibleAANeighbors); }
								 */
							}
							if (curSpecies.makesAA2())
							{
								testGrid[row][col][1] += this.KAAProducedOverPossibleAANeighbors;
								/*
								 * if (row == 3 && col == 3) { System.out.print(this.KAAProducedOverPossibleAANeighbors); }
								 */
							}
							if (curSpecies.makesAA3())
							{
								testGrid[row][col][2] += this.KAAProducedOverPossibleAANeighbors;
								/*
								 * if (row == 3 && col == 3) { System.out.print(this.KAAProducedOverPossibleAANeighbors); }
								 */
							}
							/*
							 * if (row == 3 && col == 3) { System.out.println(""); }
							 */
						}
					}

				}
			}
		}
		return testGrid;
	}

	// used to see if the moving window algorithms give the same result as a simple (fool proof) case.
	public double[][][] AAGridTestOld()
	{
		double[][][] testGrid = new double[this.gridLength][this.gridLength][3];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				int gridValue = this.env.getGridValue(row, col);
				if (gridValue != 0)
				{

					Species curSpecies = this.speciesList.get(gridValue - 1);
					if (curSpecies.makesAA1())
					{
						for (int row2 = row - this.AADispersalRadius; row2 <= row + this.AADispersalRadius; row2++)
						{
							for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
							{
								int realRow = WrapAround.wrapAround(row2, this.gridLength);
								int realCol = WrapAround.wrapAround(col2, this.gridLength);
								testGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;
								if (row == 3 && col == 3)
								{
									System.out.print(this.KAAProducedOverPossibleAANeighbors);
								}
							}
							if (row == 3 && col == 3)
							{
								System.out.println("");
							}
						}
					}
					if (row == 3 && col == 3)
					{
						System.out.println(" ");
						System.out.println(" ");
						System.out.println(" ");
						System.out.println(" ");

					}
					if (curSpecies.makesAA2())
					{
						for (int row2 = row - this.AADispersalRadius; row2 <= row + this.AADispersalRadius; row2++)
						{
							for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
							{
								int realRow = WrapAround.wrapAround(row2, this.gridLength);
								int realCol = WrapAround.wrapAround(col2, this.gridLength);
								testGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;
							}
						}
					}
					if (curSpecies.makesAA3())
					{
						for (int row2 = row - this.AADispersalRadius; row2 <= row + this.AADispersalRadius; row2++)
						{
							for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
							{
								int realRow = WrapAround.wrapAround(row2, this.gridLength);
								int realCol = WrapAround.wrapAround(col2, this.gridLength);
								testGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;
							}
						}
					}
				}
			}
		}
		return testGrid;
	}

	/**
	 * Takes a proportion of microsites and turns it into an number of microsites. This is a helper method for inoculation methods.
	 * @param prop the proportion of microsites
	 * @return abundace a integer of individuals
	 * @see inoculateInMiddle, inoculateSpecies
	 */
	public int abundFromProp(double prop)
	{
		return (int) Math.round(prop * (double) Math.pow(this.gridLength, 2));
	}

	/**
	 * used to dynamically update the grid of amino acid availibility when a new bacterium is birthed on the grid. The sites within the AADispersalRadius of the focal microsite are updated.
	 * Also, updates the critter count grid (shows how many bacteria within the AADispersalRadius are available to give birth.
	 * @param row the row location of the new bacterium
	 * @param col the col location of the new bacterium
	 * @param aSpecies
	 */
	public void addAAStep1(int row, int col, Species aSpecies)
	{
		int name = aSpecies.getSpeciesName();
		int gridProxy = aSpecies.getGridProxy();

		// use switch because it's the fastest option (like a hashtable) for the 9 species case
		switch (name)
		{

		case 0:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 1:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;
					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 2:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 3:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 12:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 23:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 13:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 123:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		}

	}

	/**
	 * used to dynamically update the grid of amino acid availibility when a new bacterium is birthed on the grid. The sites within the AADispersalRadius of the focal microsite are updated.
	 * 
	 * @param row the row location of the new bacterium
	 * @param col the col location of the new bacterium
	 * @param aSpecies
	 */
	public void addAAStep2(int row, int col, Species aSpecies)
	{
		int name = aSpecies.getSpeciesName();
		switch (name)
		{

		case 0:
			break;

		case 1:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 2:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 3:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 12:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 23:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 13:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 123:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		}

	}

	// used to see if the moving window algorithms give the same result as a simple (fool proof) case.
	public double[][][] CGRGridTest()
	{
		double[][][] growthRateGrid = new double[this.gridLength][this.gridLength][this.numberOfSpecies];
		double[][][] testGrid = new double[this.gridLength][this.gridLength][this.numberOfSpecies];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				int gridValue = this.env.getGridValue(row, col);
				if (gridValue != 0)
				{
					Species curSpecies = this.speciesList.get(gridValue - 1);
					growthRateGrid[row][col][gridValue - 1] = getResourceLimitation(row, col, curSpecies) * curSpecies.getCmax();

				}
			}
		}
		for (int s = 0; s < this.numberOfSpecies; s++)
		{

			for (int row = 0; row < this.gridLength; row++)
			{
				for (int col = 0; col < this.gridLength; col++)
				{
					int gridValue = this.env.getGridValue(row, col);
					/*
					 * if (gridValue == 0) {
					 */
					for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
					{
						for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
						{
							int realRow = WrapAround.wrapAround(row2, this.gridLength);
							int realCol = WrapAround.wrapAround(col2, this.gridLength);
							testGrid[row][col][s] += growthRateGrid[realRow][realCol][s] / (double) this.possibleNeighbors;
						}
					}
					/* } */

				}
			}
		}

		/*
		 * for (int row = 0; row < this.gridLength; row++) { for (int col = 0; col < this.gridLength; col++) { System.out.println("testGrid val at " + row + " " + col + " is " + testGrid[row][col][1]); } }
		 */
		return testGrid;
	}

	/**
	 * goes through the list of species and checks if it's time for that species to be inoculated. If it's time, then the species is inoculated. A helper for step1 and step2
	 */
	public void checkForInoculations()
	{
		if (!this.neverInoculate)
		{
			// System.out.println("stepping");
			for (int sp = 0; sp < this.numberOfSpecies; sp++)
			{
				// System.out.println(" time step : " + this.timeStep);
				if (this.timeStep == this.speciesList.get(sp).getInoculateWhen())
				{
					// System.out.println("inoculating species " + this.speciesList.get(sp).getSpeciesName() + " at time step " + this.timeStep );
					inoculateSpecies(sp, this.speciesList.get(sp).getInoculateOverwrite());
					this.inoculateCounter++;

					/*
					 * if (this.useMovingWindowForCumulativeGrowthRates) { setGrowthRateGrid(); setCumulativeGrowthRateGrid(); // System.out.println("set the grids"); }
					 */

				}

			}
		}
	}

	/**
	 * uppdates the grid of amino acid availibility using a moving window algorithm. This is faster than updating the grid with each birth / death once the amino acid dispersal radius gets up around 9.
	 */
	public void fillAAGridStep1()
	{

		// resets the AA grid. This is much faster than just calling ... = new double[][][]
		for (int r = 0; r < this.gridLength; r++)
		{
			for (int c = 0; c < this.gridLength; c++)
			{
				for (int a = 0; a < 3; a++)
				{
					this.AAGrid[r][c][a] = 0;
				}
			}

		}
		// resets the critter count grid. This is much faster than just calling ... = new double[][][]
		for (int r = 0; r < this.gridLength; r++)
		{
			for (int c = 0; c < this.gridLength; c++)
			{
				for (int s = 0; s < this.numberOfSpecies; s++)
				{
					this.critterCountGrid[r][c][s] = 0;
				}
			}

		}

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. These values are stored in the pos array.
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid location, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPold - TOPold.leftMost + TOPnew.rightmost. BOTnew can be written BOTold - BOTold.leftMost + BOTnew.rightmost.
		// In actuality, the algorithm is more complex because there are different subroutines that depend on your grid position. When both the row and the column are 0
		// (i.e. the first microsite you investigate, you have to go ahead and find the values of every neighbor, and then store these in the pos array. When the row is is still zero but you've gotten
		// past the first cell, the new top can be rexpressed as TOPold - TOPold.leftMost + TOPnew.rightmost. Same with the bottom. For the MID, you essentialy do the same thing, except the righmost and
		// lestmost values are sums over multiple rows. If you've gotten past the first row but the column is zero, then you have to caculate a new top and bottom. If you're in the meat
		// of the grid, follow the basic procedure outlined in the beginning of this description.
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				// the first loop is the most costly, each TOP, MID, and BOT is caclulated independently.
				// if (row == 0 && col == 0)

				if (col != 0 && row != 0)
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - this.AADispersalRadius, this.gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - this.AADispersalRadius, this.gridLength);
					int NERow = WrapAround.wrapAround(row - this.AADispersalRadius, this.gridLength);
					int NECol = WrapAround.wrapAround(col + this.AADispersalRadius, this.gridLength);

					int SWRow = WrapAround.wrapAround(row + this.AADispersalRadius, this.gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - this.AADispersalRadius, this.gridLength);
					int SERow = WrapAround.wrapAround(row + this.AADispersalRadius, this.gridLength);
					int SECol = WrapAround.wrapAround(col + this.AADispersalRadius, this.gridLength);

					double[] NWCorner = new double[3];
					int[] NWCornerCrit = new int[this.numberOfSpecies];

					int gridValue = this.env.getGridValue(NWRow, NWCol);
					if (gridValue != 0)
					{
						NWCornerCrit[gridValue - 1]++;

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							NWCorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							NWCorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							NWCorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					double[] NECorner = new double[3];
					int[] NECornerCrit = new int[this.numberOfSpecies];
					gridValue = this.env.getGridValue(NERow, NECol);
					if (gridValue != 0)
					{
						NECornerCrit[gridValue - 1]++;
						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							NECorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							NECorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							NECorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][0] = this.posAA[s][col - 1][0] - NWCorner[s] + NECorner[s];
					}
					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCC[s][col][0] = this.posCC[s][col - 1][0] - NWCornerCrit[s] + NECornerCrit[s];
					}

					/*
					 * if (col == 100) { System.out.println("row: " + row + "       col: " + col); System.out.println(" old mid is " + this.posAA[1][col][1]); System.out.println(" old bottom is " + this.posAA[1][col][2]); System.out.println(" new top is " + this.posAA[1][col][0]);
					 * 
					 * System.out.println("add this... " + (this.posAA[1][col][2] - this.posAA[1][col][0])); }
					 */
					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][1] += this.posAA[s][col][2] - this.posAA[s][col][0];
					}
					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCC[s][col][1] += this.posCC[s][col][2] - this.posCC[s][col][0];
					}
					/*
					 * if (col == 100) { System.out.println(" new mid is " + this.posAA[1][col][1]); System.out.println(this.posAA[1][col][2]); System.out.println(""); }
					 */
					double[] SWCorner = new double[3];
					int[] SWCornerCrit = new int[this.numberOfSpecies];
					gridValue = this.env.getGridValue(SWRow, SWCol);
					if (gridValue != 0)
					{
						SWCornerCrit[gridValue - 1]++;
						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							SWCorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							SWCorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							SWCorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					double[] SECorner = new double[3];
					int[] SECornerCrit = new int[this.numberOfSpecies];
					gridValue = this.env.getGridValue(SERow, SECol);
					if (gridValue != 0)
					{
						SECornerCrit[gridValue - 1]++;
						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							SECorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							SECorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							SECorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][2] = this.posAA[s][col - 1][2] - SWCorner[s] + SECorner[s];
					}
					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCC[s][col][2] = this.posCC[s][col - 1][2] - SWCornerCrit[s] + SECornerCrit[s];
					}

				}

				else if (col == 0 && row != 0)
				{

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][0] = 0;
					}
					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCC[s][col][0] = 0;
					}

					int row2 = row - this.AADispersalRadius;
					for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{
							this.posCC[gridValue - 1][col][0]++;
							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								this.posAA[0][col][0] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA2())
							{
								this.posAA[1][col][0] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA3())
							{
								this.posAA[2][col][0] += this.KAAProducedOverPossibleAANeighbors;
							}

						}
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][1] += this.posAA[s][col][2] - this.posAA[s][col][0];
					}
					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCC[s][col][1] += this.posCC[s][col][2] - this.posCC[s][col][0];
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][2] = 0;
					}
					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCC[s][col][2] = 0;
					}
					row2 = row + this.AADispersalRadius;
					for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{
							this.posCC[gridValue - 1][col][2]++;

							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								this.posAA[0][col][2] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA2())
							{
								this.posAA[1][col][2] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA3())
							{
								this.posAA[2][col][2] += this.KAAProducedOverPossibleAANeighbors;
							}
						}
					}

				}
				else if (row == 0 && col != 0)
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - this.AADispersalRadius, this.gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - this.AADispersalRadius, this.gridLength);
					int NERow = WrapAround.wrapAround(row - this.AADispersalRadius, this.gridLength);
					int NECol = WrapAround.wrapAround(col + this.AADispersalRadius, this.gridLength);

					int SWRow = WrapAround.wrapAround(row + this.AADispersalRadius, this.gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - this.AADispersalRadius, this.gridLength);
					int SERow = WrapAround.wrapAround(row + this.AADispersalRadius, this.gridLength);
					int SECol = WrapAround.wrapAround(col + this.AADispersalRadius, this.gridLength);

					double[] NWCorner = new double[3];
					int[] NWCornerCrit = new int[this.numberOfSpecies];
					int gridValue = this.env.getGridValue(NWRow, NWCol);
					if (gridValue != 0)
					{
						NWCornerCrit[gridValue - 1]++;

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							NWCorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							NWCorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							NWCorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					double[] NECorner = new double[3];
					int[] NECornerCrit = new int[this.numberOfSpecies];

					gridValue = this.env.getGridValue(NERow, NECol);
					if (gridValue != 0)
					{
						NECornerCrit[gridValue - 1]++;

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							NECorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							NECorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							NECorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][0] = this.posAA[s][col - 1][0] - NWCorner[s] + NECorner[s];
					}
					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCC[s][col][0] = this.posCC[s][col - 1][0] - NWCornerCrit[s] + NECornerCrit[s];
					}

					double[] leftSideOfOldMid = new double[3];
					int[] leftSideOfOldMidCrit = new int[this.numberOfSpecies];

					int col2 = col - this.AADispersalRadius - 1;
					for (int row2 = row - this.AADispersalRadius + 1; row2 <= row + this.AADispersalRadius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{
							leftSideOfOldMidCrit[gridValue - 1]++;
							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								leftSideOfOldMid[0] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA2())
							{
								leftSideOfOldMid[1] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA3())
							{
								leftSideOfOldMid[2] += this.KAAProducedOverPossibleAANeighbors;
							}

						}
					}

					double[] rightSideOfNewMid = new double[3];
					int[] rightSideOfNewMidCrit = new int[this.numberOfSpecies];

					col2 = col + this.AADispersalRadius;
					for (int row2 = row - this.AADispersalRadius + 1; row2 <= row + this.AADispersalRadius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{
							rightSideOfNewMidCrit[gridValue - 1]++;
							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								rightSideOfNewMid[0] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA2())
							{
								rightSideOfNewMid[1] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA3())
							{
								rightSideOfNewMid[2] += this.KAAProducedOverPossibleAANeighbors;
							}

						}
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][1] = this.posAA[s][col - 1][1] - leftSideOfOldMid[s] + rightSideOfNewMid[s];
					}
					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCC[s][col][1] = this.posCC[s][col - 1][1] - leftSideOfOldMidCrit[s] + rightSideOfNewMidCrit[s];
					}

					double[] SWCorner = new double[3];
					int[] SWCornerCrit = new int[this.numberOfSpecies];

					gridValue = this.env.getGridValue(SWRow, SWCol);
					if (gridValue != 0)
					{
						SWCornerCrit[gridValue - 1]++;

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							SWCorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							SWCorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							SWCorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					double[] SECorner = new double[3];
					int[] SECornerCrit = new int[this.numberOfSpecies];

					gridValue = this.env.getGridValue(SERow, SECol);
					if (gridValue != 0)
					{
						SECornerCrit[gridValue - 1]++;

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							SECorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							SECorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							SECorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][2] = this.posAA[s][col - 1][2] - SWCorner[s] + SECorner[s];
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCC[s][col][2] = this.posCC[s][col - 1][2] - SWCornerCrit[s] + SECornerCrit[s];
					}

				}
				else if

				(col == 0 && row == 0)
				{
					// /////////////////////
					// ONLY KEEP THIS PART
					// pos = new double[this.numberOfSpecies][this.gridLength][3];
					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][0] = 0;
						this.posAA[s][col][1] = 0;
						this.posAA[s][col][2] = 0;
					}
					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCC[s][col][0] = 0;
						this.posCC[s][col][1] = 0;
						this.posCC[s][col][2] = 0;
					}
					int row2 = row - this.AADispersalRadius;
					for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							this.posCC[gridValue - 1][col][0]++;
							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								this.posAA[0][col][0] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA2())
							{
								this.posAA[1][col][0] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA3())
							{
								this.posAA[2][col][0] += this.KAAProducedOverPossibleAANeighbors;
							}

						}
					}

					for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
					{
						for (row2 = row - this.AADispersalRadius + 1; row2 <= row + this.AADispersalRadius - 1; row2++)
						{
							int realRow = WrapAround.wrapAround(row2, this.gridLength);
							int realCol = WrapAround.wrapAround(col2, this.gridLength);
							int gridValue = this.env.getGridValue(realRow, realCol);
							if (gridValue != 0)
							{
								this.posCC[gridValue - 1][col][1]++;

								Species curSpecies = this.speciesList.get(gridValue - 1);
								if (curSpecies.makesAA1())
								{
									this.posAA[0][col][1] += this.KAAProducedOverPossibleAANeighbors;
								}
								if (curSpecies.makesAA2())
								{
									this.posAA[1][col][1] += this.KAAProducedOverPossibleAANeighbors;
								}
								if (curSpecies.makesAA3())
								{
									this.posAA[2][col][1] += this.KAAProducedOverPossibleAANeighbors;
								}
							}
						}
					}

					row2 = row + this.AADispersalRadius;
					for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{
							this.posCC[gridValue - 1][col][2]++;

							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								this.posAA[0][col][2] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA2())
							{
								this.posAA[1][col][2] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA3())
							{
								this.posAA[2][col][2] += this.KAAProducedOverPossibleAANeighbors;
							}
						}
					}

				}

				for (int a = 0; a < 3; a++)
				{
					this.AAGrid[row][col][a] = this.posAA[a][col][0] + this.posAA[a][col][1] + this.posAA[a][col][2];
				}

				for (int a = 0; a < this.numberOfSpecies; a++)
				{
					this.critterCountGrid[row][col][a] = this.posCC[a][col][0] + this.posCC[a][col][1] + this.posCC[a][col][2];
				}

			}
		}

	}

	/**
	 * uppdates the grid of amino acid availibility using a moving window algorithm. This is faster than updating the grid with each birth / death once the amino acid dispersal radius gets up around 9.
	 */
	public void fillAAGridStep2()
	{
		// resets the grid
		for (int r = 0; r < this.gridLength; r++)
		{
			for (int c = 0; c < this.gridLength; c++)
			{
				for (int a = 0; a < 3; a++)
				{
					this.AAGrid[r][c][a] = 0;
				}
			}

		}

		// double[][][] pos = new double[3][this.gridLength][3];
		// double[][][] pos2 = new double[3][this.gridLength][3];

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. These values are stored in the pos array.
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid location, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPold - TOPold.leftMost + TOPnew.rightmost. BOTnew can be written BOTold - BOTold.leftMost + BOTnew.rightmost.
		// In actuality, the algorithm is more complex because there are different subroutines that depend on your grid position. When both the row and the column are 0
		// (i.e. the first microsite you investigate, you have to go ahead and find the values of every neighbor, and then store these in the pos array. When the row is is still zero but you've gotten
		// past the first cell, the new top can be rexpressed as TOPold - TOPold.leftMost + TOPnew.rightmost. Same with the bottom. For the MID, you essentialy do the same thing, except the righmost and
		// lestmost values are sums over multiple rows. If you've gotten past the first row but the column is zero, then you have to caculate a new top and bottom. If you're in the meat
		// of the grid, follow the basic procedure outlined in the beginning of this description.
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				// the first loop is the most costly, each TOP, MID, and BOT is caclulated independently.
				// if (row == 0 && col == 0)

				if (col == 0 && row == 0)
				{
					// /////////////////////
					// ONLY KEEP THIS PART
					// pos = new double[this.numberOfSpecies][this.gridLength][3];
					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][0] = 0;
						this.posAA[s][col][1] = 0;
						this.posAA[s][col][2] = 0;
					}
					int row2 = row - this.AADispersalRadius;
					for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{
							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								this.posAA[0][col][0] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA2())
							{
								this.posAA[1][col][0] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA3())
							{
								this.posAA[2][col][0] += this.KAAProducedOverPossibleAANeighbors;
							}

						}
					}

					for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
					{
						for (row2 = row - this.AADispersalRadius + 1; row2 <= row + this.AADispersalRadius - 1; row2++)
						{
							int realRow = WrapAround.wrapAround(row2, this.gridLength);
							int realCol = WrapAround.wrapAround(col2, this.gridLength);
							int gridValue = this.env.getGridValue(realRow, realCol);
							if (gridValue != 0)
							{
								Species curSpecies = this.speciesList.get(gridValue - 1);
								if (curSpecies.makesAA1())
								{
									this.posAA[0][col][1] += this.KAAProducedOverPossibleAANeighbors;
								}
								if (curSpecies.makesAA2())
								{
									this.posAA[1][col][1] += this.KAAProducedOverPossibleAANeighbors;
								}
								if (curSpecies.makesAA3())
								{
									this.posAA[2][col][1] += this.KAAProducedOverPossibleAANeighbors;
								}
							}
						}
					}

					row2 = row + this.AADispersalRadius;
					for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								this.posAA[0][col][2] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA2())
							{
								this.posAA[1][col][2] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA3())
							{
								this.posAA[2][col][2] += this.KAAProducedOverPossibleAANeighbors;
							}
						}
					}

				}

				else if (row == 0)
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - this.AADispersalRadius, this.gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - this.AADispersalRadius, this.gridLength);
					int NERow = WrapAround.wrapAround(row - this.AADispersalRadius, this.gridLength);
					int NECol = WrapAround.wrapAround(col + this.AADispersalRadius, this.gridLength);

					int SWRow = WrapAround.wrapAround(row + this.AADispersalRadius, this.gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - this.AADispersalRadius, this.gridLength);
					int SERow = WrapAround.wrapAround(row + this.AADispersalRadius, this.gridLength);
					int SECol = WrapAround.wrapAround(col + this.AADispersalRadius, this.gridLength);

					double[] NWCorner = new double[3];

					int gridValue = this.env.getGridValue(NWRow, NWCol);
					if (gridValue != 0)
					{

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							NWCorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							NWCorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							NWCorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					double[] NECorner = new double[3];

					gridValue = this.env.getGridValue(NERow, NECol);
					if (gridValue != 0)
					{

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							NECorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							NECorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							NECorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][0] = this.posAA[s][col - 1][0] - NWCorner[s] + NECorner[s];
					}

					double[] leftSideOfOldMid = new double[3];
					int col2 = col - this.AADispersalRadius - 1;
					for (int row2 = row - this.AADispersalRadius + 1; row2 <= row + this.AADispersalRadius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								leftSideOfOldMid[0] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA2())
							{
								leftSideOfOldMid[1] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA3())
							{
								leftSideOfOldMid[2] += this.KAAProducedOverPossibleAANeighbors;
							}

						}
					}

					double[] rightSideOfNewMid = new double[3];
					col2 = col + this.AADispersalRadius;
					for (int row2 = row - this.AADispersalRadius + 1; row2 <= row + this.AADispersalRadius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								rightSideOfNewMid[0] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA2())
							{
								rightSideOfNewMid[1] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA3())
							{
								rightSideOfNewMid[2] += this.KAAProducedOverPossibleAANeighbors;
							}

						}
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][1] = this.posAA[s][col - 1][1] - leftSideOfOldMid[s] + rightSideOfNewMid[s];
					}

					double[] SWCorner = new double[3];

					gridValue = this.env.getGridValue(SWRow, SWCol);
					if (gridValue != 0)
					{

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							SWCorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							SWCorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							SWCorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					double[] SECorner = new double[3];

					gridValue = this.env.getGridValue(SERow, SECol);
					if (gridValue != 0)
					{

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							SECorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							SECorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							SECorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][2] = this.posAA[s][col - 1][2] - SWCorner[s] + SECorner[s];
					}

				}
				else if (col == 0)
				{

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][0] = 0;
					}
					int row2 = row - this.AADispersalRadius;
					for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								this.posAA[0][col][0] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA2())
							{
								this.posAA[1][col][0] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA3())
							{
								this.posAA[2][col][0] += this.KAAProducedOverPossibleAANeighbors;
							}

						}
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][1] += this.posAA[s][col][2] - this.posAA[s][col][0];
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][2] = 0;
					}
					row2 = row + this.AADispersalRadius;
					for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							Species curSpecies = this.speciesList.get(gridValue - 1);
							if (curSpecies.makesAA1())
							{
								this.posAA[0][col][2] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA2())
							{
								this.posAA[1][col][2] += this.KAAProducedOverPossibleAANeighbors;
							}
							if (curSpecies.makesAA3())
							{
								this.posAA[2][col][2] += this.KAAProducedOverPossibleAANeighbors;
							}
						}
					}

				}
				else
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - this.AADispersalRadius, this.gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - this.AADispersalRadius, this.gridLength);
					int NERow = WrapAround.wrapAround(row - this.AADispersalRadius, this.gridLength);
					int NECol = WrapAround.wrapAround(col + this.AADispersalRadius, this.gridLength);

					int SWRow = WrapAround.wrapAround(row + this.AADispersalRadius, this.gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - this.AADispersalRadius, this.gridLength);
					int SERow = WrapAround.wrapAround(row + this.AADispersalRadius, this.gridLength);
					int SECol = WrapAround.wrapAround(col + this.AADispersalRadius, this.gridLength);

					double[] NWCorner = new double[3];

					int gridValue = this.env.getGridValue(NWRow, NWCol);
					if (gridValue != 0)
					{

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							NWCorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							NWCorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							NWCorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					double[] NECorner = new double[3];

					gridValue = this.env.getGridValue(NERow, NECol);
					if (gridValue != 0)
					{

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							NECorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							NECorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							NECorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][0] = this.posAA[s][col - 1][0] - NWCorner[s] + NECorner[s];
					}

					/*
					 * if (col == 100) { System.out.println("row: " + row + "       col: " + col); System.out.println(" old mid is " + this.posAA[1][col][1]); System.out.println(" old bottom is " + this.posAA[1][col][2]); System.out.println(" new top is " + this.posAA[1][col][0]);
					 * 
					 * System.out.println("add this... " + (this.posAA[1][col][2] - this.posAA[1][col][0])); }
					 */
					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][1] += this.posAA[s][col][2] - this.posAA[s][col][0];
					}
					/*
					 * if (col == 100) { System.out.println(" new mid is " + this.posAA[1][col][1]); System.out.println(this.posAA[1][col][2]); System.out.println(""); }
					 */
					double[] SWCorner = new double[3];

					gridValue = this.env.getGridValue(SWRow, SWCol);
					if (gridValue != 0)
					{

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							SWCorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							SWCorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							SWCorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					double[] SECorner = new double[3];

					gridValue = this.env.getGridValue(SERow, SECol);
					if (gridValue != 0)
					{

						Species curSpecies = this.speciesList.get(gridValue - 1);
						if (curSpecies.makesAA1())
						{
							SECorner[0] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA2())
						{
							SECorner[1] = this.KAAProducedOverPossibleAANeighbors;
						}
						if (curSpecies.makesAA3())
						{
							SECorner[2] = this.KAAProducedOverPossibleAANeighbors;
						}
					}

					for (int s = 0; s < 3; s++)
					{
						this.posAA[s][col][2] = this.posAA[s][col - 1][2] - SWCorner[s] + SECorner[s];
					}

					/*
					 * for (int a = 0; a < 3; a++) { this.AAGrid[row][col][a] = this.posAA[a][col][0] + this.posAA[a][col][1] + this.posAA[a][col][2]; }
					 */

					/*
					 * if (col == 100) { System.out.println("top trick is " + this.posAA[1][col][0]); System.out.println("mid trick is " + this.posAA[1][col][1]); System.out.println("bottom trick is " + this.posAA[1][col][2]); System.out.println(""); System.out.println("top is " + pos2[1][col][0]); System.out.println("mid is " + pos2[1][col][1]); System.out.println("bottom is " + pos2[1][col][2]); System.out.println(""); System.out.println(""); System.out.println("");
					 * 
					 * for (int row2 = (row - 1 - this.AADispersalRadius); row2 <= row + this.AADispersalRadius; row2++) { for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); gridValue = this.env.getGridValue(realRow, realCol); if (gridValue == 0) { System.out.print(0 + "      "); } else { Species curSpecies = this.speciesList.get(gridValue - 1);
					 * 
					 * if (curSpecies.makesAA2()) { System.out.print(this.KAAProducedOverPossibleAANeighbors + "      "); } else { System.out.print(0 + "      "); }
					 * 
					 * } } System.out.println(""); }
					 * 
					 * System.out.println(""); System.out.println(""); System.out.println(""); System.out.println(""); System.out.println(""); System.out.println(""); System.out.println(""); System.out.println(""); }
					 */
					/*
					 * if (row == 3 && col == 3) { System.out.print("the top is " + this.posAA[0][col][0]); System.out.print("the mid is " + this.posAA[0][col][1]); System.out.print("the bottom is " + this.posAA[0][col][2]);
					 * 
					 * }
					 */

				}

				for (int a = 0; a < 3; a++)
				{
					this.AAGrid[row][col][a] = this.posAA[a][col][0] + this.posAA[a][col][1] + this.posAA[a][col][2];
				}
			}
		}

	}

	/**
	 * uppdates the grid of amino acid availibility using a moving window algorithm. This is faster than updating the grid with each birth / death once the amino acid dispersal radius gets up around 9.
	 */
	/*
	 * public void fillAAGridStep2Old() { // resets the grid for (int r = 0; r < this.gridLength; r++) { for (int c = 0; c < this.gridLength; c++) { for (int a = 0; a < 3; a++) { this.AAGrid[r][c][a] = 0; } }
	 * 
	 * }
	 * 
	 * // double[][][] pos = new double[3][this.gridLength][3]; // double[][][] pos2 = new double[3][this.gridLength][3];
	 * 
	 * // this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm. // It works by summing all of the // cumulative birth rates in the topmost row, the bottommost row, and everything in between. These values are stored in the pos array. // 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid location, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew. // (where north indicates the position above you). TOPnew can be written TOPold - TOPold.leftMost + TOPnew.rightmost. BOTnew can be written BOTold - BOTold.leftMost + BOTnew.rightmost. // In actuality, the algorithm is more complex because there are different subroutines that depend on your grid position. When both the row and the column are 0 // (i.e. the first microsite you investigate, you have to go ahead
	 * and find the values of every neighbor, and then store these in the pos array. When the row is is still zero but you've gotten // past the first cell, the new top can be rexpressed as TOPold - TOPold.leftMost + TOPnew.rightmost. Same with the bottom. For the MID, you essentialy do the same thing, except the righmost and // lestmost values are sums over multiple rows. If you've gotten past the first row but the column is zero, then you have to caculate a new top and bottom. If you're in the meat // of the grid, follow the basic procedure outlined in the beginning of this description. for (int row = 0; row < this.gridLength; row++) { for (int col = 0; col < this.gridLength; col++) { // the first loop is the most costly, each TOP, MID, and BOT is caclulated independently. // if (row == 0 && col == 0)
	 * 
	 * if (col != 0 && row != 0) {
	 * 
	 * // generate new top int NWRow = WrapAround.wrapAround(row - this.AADispersalRadius, this.gridLength); int NWCol = WrapAround.wrapAround(col - 1 - this.AADispersalRadius, this.gridLength); int NERow = WrapAround.wrapAround(row - this.AADispersalRadius, this.gridLength); int NECol = WrapAround.wrapAround(col + this.AADispersalRadius, this.gridLength);
	 * 
	 * int SWRow = WrapAround.wrapAround(row + this.AADispersalRadius, this.gridLength); int SWCol = WrapAround.wrapAround(col - 1 - this.AADispersalRadius, this.gridLength); int SERow = WrapAround.wrapAround(row + this.AADispersalRadius, this.gridLength); int SECol = WrapAround.wrapAround(col + this.AADispersalRadius, this.gridLength);
	 * 
	 * double[] NWCorner = new double[3];
	 * 
	 * int gridValue = this.env.getGridValue(NWRow, NWCol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { NWCorner[0] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { NWCorner[1] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { NWCorner[2] = this.KAAProducedOverPossibleAANeighbors; } }
	 * 
	 * double[] NECorner = new double[3];
	 * 
	 * gridValue = this.env.getGridValue(NERow, NECol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { NECorner[0] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { NECorner[1] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { NECorner[2] = this.KAAProducedOverPossibleAANeighbors; } }
	 * 
	 * for (int s = 0; s < 3; s++) { this.posAA[s][col][0] = this.posAA[s][col - 1][0] - NWCorner[s] + NECorner[s]; }
	 * 
	 * 
	 * if (col == 100) { System.out.println("row: " + row + "       col: " + col); System.out.println(" old mid is " + this.posAA[1][col][1]); System.out.println(" old bottom is " + this.posAA[1][col][2]); System.out.println(" new top is " + this.posAA[1][col][0]);
	 * 
	 * System.out.println("add this... " + (this.posAA[1][col][2] - this.posAA[1][col][0])); }
	 * 
	 * for (int s = 0; s < 3; s++) { this.posAA[s][col][1] += this.posAA[s][col][2] - this.posAA[s][col][0]; }
	 * 
	 * if (col == 100) { System.out.println(" new mid is " + this.posAA[1][col][1]); System.out.println(this.posAA[1][col][2]); System.out.println(""); }
	 * 
	 * double[] SWCorner = new double[3];
	 * 
	 * gridValue = this.env.getGridValue(SWRow, SWCol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { SWCorner[0] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { SWCorner[1] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { SWCorner[2] = this.KAAProducedOverPossibleAANeighbors; } }
	 * 
	 * double[] SECorner = new double[3];
	 * 
	 * gridValue = this.env.getGridValue(SERow, SECol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { SECorner[0] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { SECorner[1] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { SECorner[2] = this.KAAProducedOverPossibleAANeighbors; } }
	 * 
	 * for (int s = 0; s < 3; s++) { this.posAA[s][col][2] = this.posAA[s][col - 1][2] - SWCorner[s] + SECorner[s]; }
	 * 
	 * for (int a = 0; a < 3; a++) { this.AAGrid[row][col][a] = this.posAA[a][col][0] + this.posAA[a][col][1] + this.posAA[a][col][2]; }
	 * 
	 * for (int a = 0; a < 3; a++) { this.AAGrid[row][col][a] = this.posAA[a][col][0] + this.posAA[a][col][1] + this.posAA[a][col][2]; }
	 * 
	 * 
	 * 
	 * if (col == 100) { System.out.println("top trick is " + this.posAA[1][col][0]); System.out.println("mid trick is " + this.posAA[1][col][1]); System.out.println("bottom trick is " + this.posAA[1][col][2]); System.out.println(""); System.out.println("top is " + pos2[1][col][0]); System.out.println("mid is " + pos2[1][col][1]); System.out.println("bottom is " + pos2[1][col][2]); System.out.println(""); System.out.println(""); System.out.println("");
	 * 
	 * for (int row2 = (row - 1 - this.AADispersalRadius); row2 <= row + this.AADispersalRadius; row2++) { for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); gridValue = this.env.getGridValue(realRow, realCol); if (gridValue == 0) { System.out.print(0 + "      "); } else { Species curSpecies = this.speciesList.get(gridValue - 1);
	 * 
	 * if (curSpecies.makesAA2()) { System.out.print(this.KAAProducedOverPossibleAANeighbors + "      "); } else { System.out.print(0 + "      "); }
	 * 
	 * } } System.out.println(""); }
	 * 
	 * System.out.println(""); System.out.println(""); System.out.println(""); System.out.println(""); System.out.println(""); System.out.println(""); System.out.println(""); System.out.println(""); }
	 * 
	 * 
	 * if (row == 3 && col == 3) { System.out.print("the top is " + this.posAA[0][col][0]); System.out.print("the mid is " + this.posAA[0][col][1]); System.out.print("the bottom is " + this.posAA[0][col][2]);
	 * 
	 * }
	 * 
	 * }
	 * 
	 * else if (col == 0 && row != 0) {
	 * 
	 * for (int s = 0; s < 3; s++) { this.posAA[s][col][0] = 0; } int row2 = row - this.AADispersalRadius; for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { this.posAA[0][col][0] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { this.posAA[1][col][0] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { this.posAA[2][col][0] += this.KAAProducedOverPossibleAANeighbors; }
	 * 
	 * } }
	 * 
	 * for (int s = 0; s < 3; s++) { this.posAA[s][col][1] += this.posAA[s][col][2] - this.posAA[s][col][0]; }
	 * 
	 * for (int s = 0; s < 3; s++) { this.posAA[s][col][2] = 0; } row2 = row + this.AADispersalRadius; for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { this.posAA[0][col][2] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { this.posAA[1][col][2] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { this.posAA[2][col][2] += this.KAAProducedOverPossibleAANeighbors; } } }
	 * 
	 * for (int a = 0; a < 3; a++) { this.AAGrid[row][col][a] = this.posAA[a][col][0] + this.posAA[a][col][1] + this.posAA[a][col][2]; }
	 * 
	 * } else if (row == 0 && col != 0) {
	 * 
	 * // generate new top int NWRow = WrapAround.wrapAround(row - this.AADispersalRadius, this.gridLength); int NWCol = WrapAround.wrapAround(col - 1 - this.AADispersalRadius, this.gridLength); int NERow = WrapAround.wrapAround(row - this.AADispersalRadius, this.gridLength); int NECol = WrapAround.wrapAround(col + this.AADispersalRadius, this.gridLength);
	 * 
	 * int SWRow = WrapAround.wrapAround(row + this.AADispersalRadius, this.gridLength); int SWCol = WrapAround.wrapAround(col - 1 - this.AADispersalRadius, this.gridLength); int SERow = WrapAround.wrapAround(row + this.AADispersalRadius, this.gridLength); int SECol = WrapAround.wrapAround(col + this.AADispersalRadius, this.gridLength);
	 * 
	 * double[] NWCorner = new double[3];
	 * 
	 * int gridValue = this.env.getGridValue(NWRow, NWCol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { NWCorner[0] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { NWCorner[1] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { NWCorner[2] = this.KAAProducedOverPossibleAANeighbors; } }
	 * 
	 * double[] NECorner = new double[3];
	 * 
	 * gridValue = this.env.getGridValue(NERow, NECol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { NECorner[0] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { NECorner[1] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { NECorner[2] = this.KAAProducedOverPossibleAANeighbors; } }
	 * 
	 * for (int s = 0; s < 3; s++) { this.posAA[s][col][0] = this.posAA[s][col - 1][0] - NWCorner[s] + NECorner[s]; }
	 * 
	 * double[] leftSideOfOldMid = new double[3]; int col2 = col - this.AADispersalRadius - 1; for (int row2 = row - this.AADispersalRadius + 1; row2 <= row + this.AADispersalRadius - 1; row2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { leftSideOfOldMid[0] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { leftSideOfOldMid[1] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { leftSideOfOldMid[2] += this.KAAProducedOverPossibleAANeighbors; }
	 * 
	 * } }
	 * 
	 * double[] rightSideOfNewMid = new double[3]; col2 = col + this.AADispersalRadius; for (int row2 = row - this.AADispersalRadius + 1; row2 <= row + this.AADispersalRadius - 1; row2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { rightSideOfNewMid[0] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { rightSideOfNewMid[1] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { rightSideOfNewMid[2] += this.KAAProducedOverPossibleAANeighbors; }
	 * 
	 * } }
	 * 
	 * for (int s = 0; s < 3; s++) { this.posAA[s][col][1] = this.posAA[s][col - 1][1] - leftSideOfOldMid[s] + rightSideOfNewMid[s]; }
	 * 
	 * double[] SWCorner = new double[3];
	 * 
	 * gridValue = this.env.getGridValue(SWRow, SWCol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { SWCorner[0] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { SWCorner[1] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { SWCorner[2] = this.KAAProducedOverPossibleAANeighbors; } }
	 * 
	 * double[] SECorner = new double[3];
	 * 
	 * gridValue = this.env.getGridValue(SERow, SECol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { SECorner[0] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { SECorner[1] = this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { SECorner[2] = this.KAAProducedOverPossibleAANeighbors; } }
	 * 
	 * for (int s = 0; s < 3; s++) { this.posAA[s][col][2] = this.posAA[s][col - 1][2] - SWCorner[s] + SECorner[s]; }
	 * 
	 * for (int a = 0; a < 3; a++) { this.AAGrid[row][col][a] = this.posAA[a][col][0] + this.posAA[a][col][1] + this.posAA[a][col][2]; }
	 * 
	 * } else if
	 * 
	 * (col == 0 && row == 0) { // ///////////////////// // ONLY KEEP THIS PART // pos = new double[this.numberOfSpecies][this.gridLength][3]; for (int s = 0; s < 3; s++) { this.posAA[s][col][0] = 0; this.posAA[s][col][1] = 0; this.posAA[s][col][2] = 0; } int row2 = row - this.AADispersalRadius; for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) { Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { this.posAA[0][col][0] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { this.posAA[1][col][0] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { this.posAA[2][col][0] += this.KAAProducedOverPossibleAANeighbors; }
	 * 
	 * } }
	 * 
	 * for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++) { for (row2 = row - this.AADispersalRadius + 1; row2 <= row + this.AADispersalRadius - 1; row2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) { Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { this.posAA[0][col][1] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { this.posAA[1][col][1] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { this.posAA[2][col][1] += this.KAAProducedOverPossibleAANeighbors; } } } }
	 * 
	 * row2 = row + this.AADispersalRadius; for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) {
	 * 
	 * Species curSpecies = this.speciesList.get(gridValue - 1); if (curSpecies.makesAA1()) { this.posAA[0][col][2] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA2()) { this.posAA[1][col][2] += this.KAAProducedOverPossibleAANeighbors; } if (curSpecies.makesAA3()) { this.posAA[2][col][2] += this.KAAProducedOverPossibleAANeighbors; } } } for (int a = 0; a < 3; a++) { this.AAGrid[row][col][a] = this.posAA[a][col][0] + this.posAA[a][col][1] + this.posAA[a][col][2]; }
	 * 
	 * }
	 * 
	 * } }
	 * 
	 * }
	 */

	/**
	 * Gives an array of species abundances or densities after a number of time steps.
	 * 
	 * @param numSteps run for this many time steps before recording abundances/densities
	 * @param reportDensity if true, return an array of densities. If false, return an array of abundances
	 * @return a one dimensional array of abundances or densities (depending on the reportDensity) parameter
	 */
	public double[] finalValue(int numSteps, boolean reportDensity)
	{

		for (int s = 0; s < numSteps; s++)
		{
			step();
		}

		return getAbundances(reportDensity);
	}

	/**
	 * gives the average and sd of species abundances/densities over replicated simulations.
	 * 
	 * @param numSteps
	 * @param numReps
	 * @param reportDensity if false, then abundances are reported instead of density
	 * @return
	 */
	public double[] finalValueReps(int numSteps, int numReps, boolean reportDensity)
	{
		double[][] finalAbundsOverTime = new double[speciesList.size()][numReps];
		for (int r = 0; r < numReps; r++)
		{
			Community com = new Community(this);
			double[] temp = com.finalValue(numSteps, reportDensity);

			for (int t = 0; t < temp.length; t++)
			{
				finalAbundsOverTime[t][r] = temp[t];
			}
		}

		double[] toReturn = new double[finalAbundsOverTime.length * 2];
		for (int i = 0; i < finalAbundsOverTime.length; i++)
		{
			toReturn[2 * i] = MeanAndSD.meanAcrossColumns(finalAbundsOverTime, i);
			toReturn[2 * i + 1] = MeanAndSD.SDAcrossColumns(finalAbundsOverTime, i, toReturn[2 * i]);

		}

		return toReturn;

	}

	/**
	 * @return the community-wide amino acid dispersal radius
	 */
	public int getAADispersalRadius()
	{
		return this.AADispersalRadius;
	}

	public double[][][] getAAGrid()
	{
		return this.AAGrid;
	}

	/**
	 * gets the abundance for each species.
	 * 
	 * @param reportDensity if true, then return an array of densities
	 * @return abundances an array of abundances. Exception: the first index of the array is the time step.
	 */
	public double[] getAbundances(boolean reportDensity)
	{
		int[] abundances = new int[this.numberOfSpecies + 1];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				abundances[this.env.getGridValue(row, col)]++;
			}
		}

		double[] realAbundances = new double[this.numberOfSpecies];
		if (reportDensity)
		{
			for (int s = 0; s < this.numberOfSpecies; s++)
			{
				realAbundances[s] = abundances[s + 1] / (double) this.totalSites;
			}
		}
		else
		{
			for (int s = 0; s < this.numberOfSpecies; s++)
			{
				realAbundances[s] = abundances[s + 1];
			}
		}
		return realAbundances;

	}

	/**
	 * gets the average resource limitation of a species across the landscape.
	 * @param currentSpecies
	 * @return
	 */
	public double getAvgFC(int speciesIndex)
	{
		Species currentSpecies = this.speciesList.get(speciesIndex);
		double AvgFC = 0;
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{

				// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
				//
				AvgFC += getResourceLimitation(row, col, currentSpecies);
			}
		}

		return AvgFC / (double) this.totalSites;

	}

	public double getAvgFC(double[][] fCGrid)
	{
		double total = 0;
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{

				total += fCGrid[row][col];
			}
		}

		return total / (double) this.totalSites;

	}

	public double getAvgE(double[][] EGrid)
	{
		double total = 0;
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{

				total += EGrid[row][col];
			}
		}

		return total / (double) this.totalSites;
	}

	/**
	 * gets the average resource limitation of a species across the landscape.
	 * @param currentSpecies
	 * @return
	 */
	public double getAvgFC(Species currentSpecies)
	{
		double AvgFC = 0;
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{

				// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
				//
				AvgFC += getResourceLimitation(row, col, currentSpecies);
			}
		}

		return AvgFC / (double) this.totalSites;

	}

	/**
	 * @return the community-wid microbial dispersal (actually dispersion; adults don't move) radius.
	 */
	public int getDispersalRadius()
	{
		return this.dispersalRadius;
	}

	public double getDt()
	{
		return this.dt;
	}

	/**
	 * gets a grid of average empty sites (e.g. te number of empty sites in a dispersalNeghborhood / the number of possible sites in a dispersalNeighborhood.
	 * Uses a moving window algorithm.
	 * @return a grid of average neighborhood emptiness values 
	 */
	public double[][] getEGrid()
	{
		double[][] EGrid = new double[this.gridLength][this.gridLength];
		double[][] posE = new double[this.gridLength][3];

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. These values are stored in the pos array.
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid location, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPold - TOPold.leftMost + TOPnew.rightmost. BOTnew can be written BOTold - BOTold.leftMost + BOTnew.rightmost.
		// In actuality, the algorithm is more complex because there are different subroutines that depend on your grid position. When both the row and the column are 0
		// (i.e. the first microsite you investigate, you have to go ahead and find the values of every neighbor, and then store these in the pos array. When the row is is still zero but you've gotten
		// past the first cell, the new top can be rexpressed as TOPold - TOPold.leftMost + TOPnew.rightmost. Same with the bottom. For the MID, you essentialy do the same thing, except the righmost and
		// lestmost values are sums over multiple rows. If you've gotten past the first row but the column is zero, then you have to caculate a new top and bottom. If you're in the meat
		// of the grid, follow the basic procedure outlined in the beginning of this description.
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				// the first loop is the most costly, each TOP, MID, and BOT is caclulated independently.
				if (row == 0 && col == 0)
				{
					// pos = new double[this.numberOfSpecies][this.gridLength][3];
					int row2 = row - this.dispersalRadius;
					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue == 0)
						{

							posE[col][0]++;
						}
					}
					// System.out.println("col == " + col + " first is " + first[1]);

					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						for (row2 = row - this.dispersalRadius + 1; row2 <= row + this.dispersalRadius - 1; row2++)
						{
							int realRow = WrapAround.wrapAround(row2, this.gridLength);
							int realCol = WrapAround.wrapAround(col2, this.gridLength);
							int gridValue = this.env.getGridValue(realRow, realCol);
							if (gridValue == 0)
							{

								posE[col][1]++;
							}
						}
					}
					// System.out.println("col == 0 middle is " + middle[1]);

					row2 = row + this.dispersalRadius;
					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue == 0)
						{

							posE[col][2]++;
						}
					}

				}
				else if (row == 0)
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength);
					int NERow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength);
					int NECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);

					int SWRow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength);
					int SERow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength);
					int SECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);

					double NWCorner = 0;
					if (this.env.getGridValue(NWRow, NWCol) == 0)
					{
						NWCorner = 1;
					}
					double NECorner = 0;
					if (this.env.getGridValue(NERow, NECol) == 0)
					{
						NECorner = 1;
					}
					posE[col][0] = posE[col - 1][0] - NWCorner + NECorner;

					double leftSideOfOldMid = 0;
					int col2 = col - this.dispersalRadius - 1;
					for (int row2 = row - this.dispersalRadius + 1; row2 <= row + this.dispersalRadius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue == 0)
						{

							leftSideOfOldMid++;

						}
					}

					double rightSideOfNewMid = 0;
					col2 = col + this.dispersalRadius;
					for (int row2 = row - this.dispersalRadius + 1; row2 <= row + this.dispersalRadius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue == 0)
						{

							rightSideOfNewMid++;

						}
					}

					posE[col][1] = posE[col - 1][1] - leftSideOfOldMid + rightSideOfNewMid;

					double SWCorner = 0;
					if (this.env.getGridValue(SWRow, SWCol) == 0)
					{
						SWCorner = 1;
					}
					double SECorner = 0;
					if (this.env.getGridValue(SERow, SECol) == 0)
					{
						SECorner = 1;
					}
					posE[col][2] = posE[col - 1][2] - SWCorner + SECorner;
				}
				// if we're on a new row, but not the first row, the TOPnew and BOTnew must be calculated independently
				else if (col == 0)
				{

					posE[col][0] = 0;
					int row2 = row - this.dispersalRadius;
					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue == 0)
						{

							posE[col][0]++;

						}
					}

					posE[col][1] += posE[col][2] - posE[col][0];

					posE[col][2] = 0;
					row2 = row + this.dispersalRadius;
					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue == 0)
						{

							posE[col][2]++;

						}
					}

				}
				else
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength);
					int NERow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength);
					int NECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);

					int SWRow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength);
					int SERow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength);
					int SECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);

					double NWCorner = 0;
					if (this.env.getGridValue(NWRow, NWCol) == 0)
					{
						NWCorner = 1;
					}
					double NECorner = 0;
					if (this.env.getGridValue(NERow, NECol) == 0)
					{
						NECorner = 1;
					}
					posE[col][0] = posE[col - 1][0] - NWCorner + NECorner;

					posE[col][1] += posE[col][2] - posE[col][0];

					double SWCorner = 0;
					if (this.env.getGridValue(SWRow, SWCol) == 0)
					{
						SWCorner = 1;
					}
					double SECorner = 0;
					if (this.env.getGridValue(SERow, SECol) == 0)
					{
						SECorner = 1;
					}
					posE[col][2] = posE[col - 1][2] - SWCorner + SECorner;

				}

				int correctForMiddle = 0;
				if (this.env.getGridValue(row, col) == 0)
				{
					correctForMiddle = -1;
				}
				EGrid[row][col] = (posE[col][0] + posE[col][1] + posE[col][2] + correctForMiddle) / (double) this.possibleNeighbors;
			}
		}
		return EGrid;
	}

	/**
	 * calculates fitness density covariance using the forfmula derived in Stump and Chesson, 2015.
	 * 
	 * @param aSpecies
	 * @return
	 */
	public double getEmptySiteDensityCovariance(int speciesIndex)
	{
		Species aSpecies = this.speciesList.get(speciesIndex);
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();
		double[][] ELocal = getEGrid();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += ELocal[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += ELocal[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates fitness density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param aSpecies
	 * @return
	 */
	public double getEmptySiteDensityCovariance(Species aSpecies)
	{
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();
		double[][] ELocal = getEGrid();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += ELocal[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += ELocal[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates fitness density covariance using the forfmula derived in Stump and Chesson, 2015.
	 * 
	 * @param ELocal the grid of ELBar values (empty sites / possible sites) 
	 * @param speciesIndex the location of the species in the species list
	 * @return
	 */
	public double getEmptySiteDensityCovariance(double[][] ELocal, int speciesIndex)
	{
		Species aSpecies = this.speciesList.get(speciesIndex);
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += ELocal[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += ELocal[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates fitness density covariance using the forfmula derived in Stump and Chesson, 2015.
	 * 
	 * @param ELocal the grid of ELBar values (empty sites / possible sites) 
	 * @param speciesIndex the location of the species in the species list
	 * @return
	 */
	public double getEmptySiteDensityCovariance(double[][] ELocal, Species aSpecies)
	{
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += ELocal[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += ELocal[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * Gets the environment, which consists of a grid and that grid's length.
	 * @return Environment 
	 */
	public Environment getEnvironment()
	{
		return this.env;
	}

	/**
	 * @param AACounts
	 * @param critterCounts
	 * @return
	 */
	/*
	 * public double[] getBirthProbabilities(double[][] AACounts, int[][] critterCounts) { double[] birthProbs = new double[this.numberOfSpecies]; for (int spp = 0; spp < this.numberOfSpecies; spp++) { Species currentSpecies = this.speciesList.get(spp); double tempF = 1; if (!currentSpecies.makesAA1()) { double aA1 = AACounts[0][0] + AACounts[0][1] + AACounts[0][2]; if (aA1 / currentSpecies.getAA1K() < tempF) { tempF = aA1 / currentSpecies.getAA1K(); } }
	 * 
	 * if (!currentSpecies.makesAA2()) { double aA2 = AACounts[1][0] + AACounts[1][1] + AACounts[1][2]; if (aA2 / currentSpecies.getAA2K() < tempF) { tempF = aA2 / currentSpecies.getAA2K(); } }
	 * 
	 * if (!currentSpecies.makesAA3()) { double aA3 = AACounts[2][0] + AACounts[2][1] + AACounts[2][2];
	 * 
	 * if (aA3 / currentSpecies.getAA3K() < tempF) { tempF = aA3 / currentSpecies.getAA3K(); } }
	 * 
	 * int realCritterCount = 0; for (int i = 0; i < 3; i++) { realCritterCount += critterCounts[spp][i]; } // this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors // are around to give birth birthProbs[spp] = currentSpecies.getCmax() * tempF * (realCritterCount / (double) this.possibleAANeighbors);
	 * 
	 * } return birthProbs; }
	 */

	/**
	 * gets the resource limitation of the average Amino acid availibility
	 * @param currentSpecies
	 * @return
	 */
	public double getFAvgC(int speciesIndex)
	{
		Species currentSpecies = this.speciesList.get(speciesIndex);
		double[] abunds = getAbundances(true);

		double tempF = 1;
		if (!currentSpecies.makesAA1())
		{
			double temp = this.KAAProduced * abunds[1];
			if (temp < tempF)
			{
				tempF = temp;
			}
		}

		if (!currentSpecies.makesAA2())
		{
			double temp = this.KAAProduced * abunds[2];
			if (temp < tempF)
			{
				tempF = temp;
			}
		}

		return tempF;

	}

	/**
	 * gets the resource limitation of the average Amino acid availibility
	 * @param currentSpecies
	 * @return
	 */
	public double getFAvgC(Species currentSpecies)
	{
		double[] abunds = getAbundances(true);

		double tempF = 1;
		if (!currentSpecies.makesAA1())
		{
			double temp = this.KAAProduced * abunds[1];
			if (temp < tempF)
			{
				tempF = temp;
			}
		}

		if (!currentSpecies.makesAA2())
		{
			double temp = this.KAAProduced * abunds[2];
			if (temp < tempF)
			{
				tempF = temp;
			}
		}

		return tempF;

	}

	/**
	 * calculates resource limitation - density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param aSpecies
	 * @return
	 */
	public double getFCDensityCovariance(int speciesIndex)
	{
		Species aSpecies = this.speciesList.get(speciesIndex);
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();
		double[][] fC = getResourceLimitationGrid(aSpecies);

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += fC[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += fC[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates resource limitation - density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param fCSpeciesIndex gives the species position for the resource limitation of interest
	 * @param densitySpeciesIndex gives the species position for the density of interest
	 * @returnf
	 */
	public double getFCDensityCovariance(int fCSpeciesIndex, int densitySpeciesIndex)
	{
		Species aSpecies = this.speciesList.get(densitySpeciesIndex);
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();
		double[][] fC = getResourceLimitationGrid(this.speciesList.get(fCSpeciesIndex));

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += fC[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += fC[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates resource limitation - density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param aSpecies
	 * @return
	 */
	public double getFCDensityCovariance(Species aSpecies)
	{
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();
		double[][] fC = getResourceLimitationGrid(aSpecies);

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += fC[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += fC[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates resource limitation - density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param fCSpecies gives the species position for the resource limitation of interest
	 * @param densitySpecies gives the species position for the density of interest
	 * @return
	 */
	public double getFCDensityCovariance(Species fCSpecies, Species densitySpecies)
	{
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = densitySpecies.getGridProxy();
		double[][] fC = getResourceLimitationGrid(fCSpecies);

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += fC[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += fC[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates resource limitation - density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param fCGrid the grid of resource limitation (f(C)) values
	 * @param densitySpecies gives the species position for the density of interest
	 * @return
	 */
	public double getFCDensityCovariance(double[][] fCGrid, Species densitySpecies)
	{
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = densitySpecies.getGridProxy();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += fCGrid[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += fCGrid[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates resource limitation - density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param fCGrid the grid of resource limitation (f(C)) values
	 * @param densitySpecies gives the species position for the density of interest
	 * @return
	 */
	public double getFCDensityCovariance(double[][] fCGrid, int densitySpeciesIndex)
	{
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = this.speciesList.get(densitySpeciesIndex).getGridProxy();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += fCGrid[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += fCGrid[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates the covariance between amino acid limitation and the average emptiness of neighborhoods
	 * 
	 * @param aSpecies
	 * @return 
	 */
	public double getfCEmptySiteCov(int speciesIndex)
	{
		Species aSpecies = this.speciesList.get(speciesIndex);
		double[][] EGrid = getEGrid();

		double[] resourceLimitations = new double[this.totalSites];
		double resourceLimitationsSum = 0;
		double[] EVals = new double[this.totalSites];

		double ESum = 0;
		int counter = 0;
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				double rL = getResourceLimitation(row, col, aSpecies);
				resourceLimitations[counter] = rL;
				resourceLimitationsSum += rL;
				EVals[counter] = EGrid[row][col];
				ESum += EGrid[row][col];
				counter++;
			}
		}

		double EAvg = ESum / (double) this.totalSites;
		double resourceLimitationsAvg = resourceLimitationsSum / (double) this.totalSites;

		double undividedCov = 0;
		for (int i = 0; i < this.totalSites; i++)
		{
			undividedCov += (resourceLimitations[i] - resourceLimitationsAvg) * (EVals[i] - EAvg);
		}
		return undividedCov / (double) (this.totalSites);

	}

	/**
	 * calculates the covariance between amino acid limitation and the average emptiness of neighborhoods
	 * 
	 * @param aSpecies
	 * @return 
	 */
	public double getfCEmptySiteCov(Species aSpecies)
	{
		double[][] EGrid = getEGrid();

		double[] resourceLimitations = new double[this.totalSites];
		double resourceLimitationsSum = 0;
		double[] EVals = new double[this.totalSites];

		double ESum = 0;
		int counter = 0;
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				double rL = getResourceLimitation(row, col, aSpecies);
				resourceLimitations[counter] = rL;
				resourceLimitationsSum += rL;
				EVals[counter] = EGrid[row][col];
				ESum += EGrid[row][col];
				counter++;
			}
		}

		double EAvg = ESum / (double) this.totalSites;
		double resourceLimitationsAvg = resourceLimitationsSum / (double) this.totalSites;

		double undividedCov = 0;
		for (int i = 0; i < this.totalSites; i++)
		{
			undividedCov += (resourceLimitations[i] - resourceLimitationsAvg) * (EVals[i] - EAvg);
		}
		return undividedCov / (double) (this.totalSites);

	}

	/**
	 * calculates fitness density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param aSpecies
	 * @return
	 */
	public double getFitnessDensityCovariance(int speciesIndex)
	{
		Species aSpecies = this.speciesList.get(speciesIndex);
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();
		double[][] fitnessGrid = getFitnessGrid(aSpecies);

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += fitnessGrid[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += fitnessGrid[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	public double getCovEFCDensityCovariance(double[][] EGrid, double EAvg, double[][] fCGrid, double fCAvg, int densitySpeciesIndex)
	{
		Species aSpecies = this.speciesList.get(densitySpeciesIndex);
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += (EGrid[row][col] - EAvg) * (fCGrid[row][col] - fCAvg);
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += (EGrid[row][col] - EAvg) * (fCGrid[row][col] - fCAvg);
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	public double getCovEFCDensityCovariance(double[][] EGrid, double EAvg, double[][] fCGrid, double fCAvg, Species densitySpecies)
	{
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = densitySpecies.getGridProxy();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += (EGrid[row][col] - EAvg) * (fCGrid[row][col] - fCAvg);
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += (EGrid[row][col] - EAvg) * (fCGrid[row][col] - fCAvg);
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates fitness density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param aSpecies
	 * @return
	 */
	public double getFitnessDensityCovariance(Species aSpecies)
	{
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();
		double[][] fitnessGrid = getFitnessGrid(aSpecies);

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += fitnessGrid[row][col];
					// //System.out.println((EArray[row][col] / CArray[row][col]) + (1 - this.deathProb));
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += fitnessGrid[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates a grid of fitnesses that are not adjusted by birth and death rates. In other words, this method returns a grid of f(C) * emptySites^l
	 * @param aSpecies
	 * @return
	 */
	public double[][] getFitnessGrid(Species aSpecies)
	{

		double[][] EGrid = getEGrid();
		double[][] fitnessGrid = new double[this.gridLength][this.gridLength];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				fitnessGrid[row][col] = EGrid[row][col] * getResourceLimitation(row, col, aSpecies);
			}
		}

		return fitnessGrid;

	}

	public double[][] getFitnessGridWithBirthRate(Species aSpecies)
	{
		double birthRate = aSpecies.getCmax();

		double[][] EGrid = getEGrid();

		double[][] fitnessGrid = new double[this.gridLength][this.gridLength];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				fitnessGrid[row][col] = birthRate * EGrid[row][col] * getResourceLimitation(row, col, aSpecies);
			}
		}

		return fitnessGrid;

	}

	public double[][][] getSimpsonsGrid()
	{

		double[][][] allFitnesses = new double[this.numberOfSpecies][this.gridLength][this.gridLength];
		double[][][] cumFitnesses = new double[this.numberOfSpecies][this.gridLength][this.gridLength];
		for (int s = 0; s < this.numberOfSpecies; s++)
		{
			allFitnesses[s] = getFitnessGridWithBirthRate(this.speciesList.get(s));
		}
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{

				for (int row2 = row - this.AADispersalRadius; row2 <= row + this.AADispersalRadius; row2++)
				{
					for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{
							cumFitnesses[gridValue - 1][row][col] += allFitnesses[gridValue - 1][realRow][realCol];
						}
					}
				}

			}
		}
		return cumFitnesses;
	}

	public double[] getWinLossTieGenVSCheat()
	{
		double[] winLossTie = new double[3];
		double[][][] simpsonsGrid = getSimpsonsGrid();
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (simpsonsGrid[1][row][col] == simpsonsGrid[0][row][col])
				{
					winLossTie[2]++;
				}
				else if (simpsonsGrid[1][row][col] > simpsonsGrid[0][row][col])
				{
					winLossTie[0]++;
				}
				else
				{
					winLossTie[1]++;
				}
			}
		}
		return winLossTie;
	}

	public double[] getCumulativeFitnessesGenVSCheat()
	{
		double[] cheatGenTotal = new double[2];
		double[][][] allFitnesses = new double[this.numberOfSpecies][this.gridLength][this.gridLength];
		for (int s = 0; s < this.numberOfSpecies; s++)
		{
			allFitnesses[s] = getFitnessGridWithBirthRate(this.speciesList.get(s));
		}

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == 1)
				{
					cheatGenTotal[0] += allFitnesses[0][row][col];
				}
			}
		}

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == 2)
				{
					cheatGenTotal[1] += allFitnesses[1][row][col];
				}
			}
		}

		return cheatGenTotal;

	}

	public double[] getWinLossTieSynsVSCheat()
	{
		double[] winLossTie = new double[3];
		double[][][] simpsonsGrid = getSimpsonsGrid();
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (simpsonsGrid[1][row][col] == simpsonsGrid[0][row][col])
				{
					winLossTie[2]++;
				}
				else if (simpsonsGrid[1][row][col] > simpsonsGrid[0][row][col])
				{
					winLossTie[0]++;
				}
				else
				{
					winLossTie[1]++;
				}
			}
		}
		return winLossTie;
	}

	public double[] getCumulativeFitnessesSynsVSCheat()
	{
		double[] cheatGenTotal = new double[2];
		double[][][] allFitnesses = new double[this.numberOfSpecies][this.gridLength][this.gridLength];
		for (int s = 0; s < this.numberOfSpecies; s++)
		{
			allFitnesses[s] = getFitnessGridWithBirthRate(this.speciesList.get(s));
		}

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == 1)
				{
					cheatGenTotal[0] += allFitnesses[0][row][col];
				}
			}
		}

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == 2)
				{
					cheatGenTotal[1] += allFitnesses[1][row][col];
				}
			}
		}

		return cheatGenTotal;

	}

	/**
	 * Gets the environment grid.
	 * @return grid
	 */
	public int[][] getGrid()
	{
		return this.env.getGrid();
	}

	/**
	 * Returns a grid where the location of an individual is denoted with its species name as opposed to its grid proxy. The cheater is named the 0, so empty sites are -1.
	 * @return grid a grid where the locations of individuals are denoted with species names. For more information on species names, see the documentation for the Species class.
	 */
	public int[][] getGridWithNames()
	{
		int[][] namedGrid = new int[this.gridLength][this.gridLength];

		int[][] grid = this.env.getGrid();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				int gridValue = grid[row][col];

				if (gridValue == 0)
				{
					namedGrid[row][col] = -1;
				}
				else
				{
					namedGrid[row][col] = this.speciesList.get(gridValue - 1).getSpeciesName();
				}
			}
		}
		return namedGrid;

	}

	public double getKNBar1(int row, int col)
	{
		int gridValue = this.env.getGridValue(row, col);

		double AA1Avail = this.AAGrid[row][col][0];

		if (gridValue != 0)
		{
			Species tempSpecies = this.speciesList.get(gridValue - 1);
			if (tempSpecies.makesAA1())
			{
				AA1Avail -= this.KAAProducedOverPossibleAANeighbors;
			}

		}

		return AA1Avail;
	}

	/**
	 * calculates KN1Bar density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param aSpecies
	 * @return
	 */
	public double getKNBar1DensityCovariance(int speciesIndex)
	{
		Species aSpecies = this.speciesList.get(speciesIndex);
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();
		double[][] KNBar1Grid = getKNBar1Grid();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += KNBar1Grid[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += KNBar1Grid[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates KN1Bar density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param aSpecies
	 * @return
	 */
	public double getKNBar1DensityCovariance(Species aSpecies)
	{
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();
		double[][] KNBar1Grid = getKNBar1Grid();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += KNBar1Grid[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += KNBar1Grid[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	public double[][] getKNBar1Grid()
	{
		double[][] KNBar1Grid = new double[this.gridLength][this.gridLength];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				KNBar1Grid[row][col] = getKNBar1(row, col);
			}
		}
		return KNBar1Grid;
	}

	public double getKNBar2(int row, int col)
	{
		int gridValue = this.env.getGridValue(row, col);

		double AA2Avail = this.AAGrid[row][col][1];

		if (gridValue != 0)
		{
			Species tempSpecies = this.speciesList.get(gridValue - 1);
			if (tempSpecies.makesAA2())
			{
				AA2Avail -= this.KAAProducedOverPossibleAANeighbors;
			}

		}

		return AA2Avail;
	}

	/**
	 * calculates KN1Bar density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param aSpecies
	 * @return
	 */
	public double getKNBar2DensityCovariance(int speciesIndex)
	{
		Species aSpecies = this.speciesList.get(speciesIndex);
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();
		double[][] KNBar2Grid = getKNBar2Grid();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += KNBar2Grid[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += KNBar2Grid[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	/**
	 * calculates KN1Bar density covariance using the formula derived in Stump and Chesson, 2015.
	 * 
	 * @param aSpecies
	 * @return
	 */
	public double getKNBar2DensityCovariance(Species aSpecies)
	{
		int OccupiedCounter = 0;
		int EmptyCounter = 0;
		double OccupiedFitnessTotal = 0;
		double EmptyFitnessTotal = 0;
		int speciesValue = aSpecies.getGridProxy();
		double[][] KNBar2Grid = getKNBar2Grid();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == speciesValue)
				{
					OccupiedFitnessTotal += KNBar2Grid[row][col];
					OccupiedCounter++;
				}
				else
				{
					EmptyFitnessTotal += KNBar2Grid[row][col];
					EmptyCounter++;
				}
			}
		}

		if (OccupiedCounter == 0)
		{
			OccupiedCounter = 1;
		}
		if (EmptyCounter == 0)
		{
			EmptyCounter = 1;
		}

		double proportionOfOccupiedSites = OccupiedCounter / (double) this.totalSites;
		double averageOccupied = (OccupiedFitnessTotal / (double) OccupiedCounter);
		double averageEmpty = (EmptyFitnessTotal / (double) EmptyCounter);
		/*
		 * //System.out.println("averageOccupied is " + averageOccupied); //System.out.println("averageEmpty is " + averageEmpty); //System.out.println("proportion of sites occupied is " + proportionOfOccupiedSites);
		 */
		return (1 - proportionOfOccupiedSites) * (averageOccupied - averageEmpty);
	}

	public double[][] getKNBar2Grid()
	{
		double[][] KNBar2Grid = new double[this.gridLength][this.gridLength];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				KNBar2Grid[row][col] = getKNBar2(row, col);
			}
		}
		return KNBar2Grid;
	}

	/**
	 * caculates the loss function
	 * @param currentSpecies
	 * @return
	 */
	public double getL(int speciesIndex)
	{
		return getAvgFC(speciesIndex) - getFAvgC(speciesIndex);
	}

	/**
	 * caculates the loss function
	 * @param currentSpecies
	 * @return
	 */
	public double getL(Species currentSpecies)
	{
		return getAvgFC(currentSpecies) - getFAvgC(currentSpecies);
	}

	public ArrayList<Location> getListOfLocations(Species aSpecies)
	{
		ArrayList<Location> listOfLocations = new ArrayList<Location>();
		int gridProxy = aSpecies.getGridProxy();
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.getGridValue(row, col) == gridProxy)
				{
					listOfLocations.add(new Location(row, col));
				}
			}
		}
		return listOfLocations;
	}

	/*
	 * public double getResourceLimitation(int row, int col) { int gridValue = this.env.getGridValue(row, col);
	 * 
	 * Species currentSpecies = this.speciesList.get(gridValue - 1); double AA1Avail = this.AAGrid[row][col][0]; double AA2Avail = this.AAGrid[row][col][1]; double AA3Avail = this.AAGrid[row][col][2];
	 * 
	 * if(gridValue != 0) { Species tempSpecies = this.speciesList.get(gridValue - 1); if(tempSpecies.makesAA1()) { AA1Avail -= this.KAAProducedOverPossibleAANeighbors; } if(tempSpecies.makesAA2()) { AA2Avail -= this.KAAProducedOverPossibleAANeighbors; } if(tempSpecies.makesAA3()) { AA3Avail -= this.KAAProducedOverPossibleAANeighbors; } }
	 * 
	 * 
	 * 
	 * double tempF = 1; if (!currentSpecies.makesAA1()) { if ( AA1Avail / currentSpecies.getAA1K() < tempF) { tempF = AA1Avail / currentSpecies.getAA1K(); } }
	 * 
	 * if (!currentSpecies.makesAA2()) { if ( AA2Avail / currentSpecies.getAA2K() < tempF) { tempF = AA2Avail / currentSpecies.getAA2K(); } }
	 * 
	 * if (!currentSpecies.makesAA3()) { if ( AA3Avail / currentSpecies.getAA3K() < tempF) { tempF = AA3Avail / currentSpecies.getAA3K(); } } return tempF; }
	 */
	public double getResourceLimitation(int row, int col, Species currentSpecies)
	{
		int gridValue = this.env.getGridValue(row, col);

		double AA1Avail = this.AAGrid[row][col][0];
		double AA2Avail = this.AAGrid[row][col][1];
		double AA3Avail = this.AAGrid[row][col][2];

		if (gridValue != 0)
		{
			Species tempSpecies = this.speciesList.get(gridValue - 1);
			if (tempSpecies.makesAA1())
			{
				AA1Avail -= this.KAAProducedOverPossibleAANeighbors;
			}
			if (tempSpecies.makesAA2())
			{
				AA2Avail -= this.KAAProducedOverPossibleAANeighbors;
			}
			if (tempSpecies.makesAA3())
			{
				AA3Avail -= this.KAAProducedOverPossibleAANeighbors;
			}
		}

		double tempF = 1;
		if (!currentSpecies.makesAA1())
		{
			if (AA1Avail / currentSpecies.getAA1K() < tempF)
			{
				tempF = AA1Avail / currentSpecies.getAA1K();
			}
		}

		if (!currentSpecies.makesAA2())
		{
			if (AA2Avail / currentSpecies.getAA2K() < tempF)
			{
				tempF = AA2Avail / currentSpecies.getAA2K();
			}
		}

		if (!currentSpecies.makesAA3())
		{
			if (AA3Avail / currentSpecies.getAA3K() < tempF)
			{
				tempF = AA3Avail / currentSpecies.getAA3K();
			}
		}
		return tempF;
	}

	/**
	 * 	get 
	 * @return a grid of resource limitation
	 */
	public double[][] getResourceLimitationGrid(Species aSpecies)
	{
		double[][] fC = new double[this.gridLength][this.gridLength];

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				fC[row][col] = getResourceLimitation(row, col, aSpecies);
			}
		}
		return fC;
	}

	public double[][] getResourceLimitationGrid(int speciesIndex)
	{
		double[][] fC = new double[this.gridLength][this.gridLength];
		Species aSpecies = this.speciesList.get(speciesIndex);

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				fC[row][col] = getResourceLimitation(row, col, aSpecies);
			}
		}
		return fC;
	}

	/**
	 * @return speciesList an arrayList of species. This method is exclusivelty for Jlink use (mathematica - java interface), since JLink was have a hard time accessing fields directly.
	 */
	public ArrayList<Species> getSpeciesList()
	{
		return this.speciesList;
	}

	public int getTimeStep()
	{
		return this.timeStep;
	}

	/**
	 * Gets the environment grid after exacting a specified number of time steps.
	 * @param numSteps
	 * @return grid
	 */
	public int[][] gridFinal(int numSteps)
	{
		for (int i = 0; i < numSteps; i++)
		{
			step();
		}
		return getGrid();
	}

	/**
	 * Gives a time series of environment grids. Mostly for analyzing spatial structure over time.
	 * 
	 * @param numSteps how many time steps the method runs for
	 * @param measureHowOften how often should data be collected
	 * @return a three dimensional [row][col][time] array of species locationss
	 */
	public int[][][] gridTimeSeries(int numSteps, int measureHowOften)
	{
		int[][][] abundanceArray = new int[(numSteps / measureHowOften) + 1][this.gridLength][this.gridLength];
		int counter = 0;

		int[][] currentAbundances = this.env.getGrid();
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				abundanceArray[counter][row][col] = currentAbundances[row][col];
			}
		}
		counter++;

		for (int s = 1; s <= numSteps; s++)
		{
			step();
			// scatter();
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = this.env.getGrid();
				for (int row = 0; row < this.gridLength; row++)
				{
					for (int col = 0; col < this.gridLength; col++)
					{
						abundanceArray[counter][row][col] = currentAbundances[row][col];
					}
				}
				counter++;
			}
		}
		return abundanceArray;
	}

	/**
	 * Gives a time series of environment grids.
	 * 
	 * @param start run this many time steps before recording any data
	 * @param end how many time steps elapse in total before the method ends
	 * @param measureHowOften how often should data be collected
	 * @return a three dimensional [row][col][time] array of species locationss
	 */
	public int[][][] gridTimeSeries(int start, int end, int measureHowOften)
	{
		int numSteps = end - start;
		int[][][] abundanceArray = new int[(numSteps / measureHowOften) + 1][this.gridLength][this.gridLength];
		int counter = 0;
		int s = 1;
		for (; s <= start; s++)
		{
			step();
		}

		int[][] currentAbundances = this.env.getGrid();
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				abundanceArray[counter][row][col] = currentAbundances[row][col];
			}
		}
		counter++;

		for (; s <= end; s++)
		{
			step();
			// scatter();
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = this.env.getGrid();
				for (int row = 0; row < this.gridLength; row++)
				{
					for (int col = 0; col < this.gridLength; col++)
					{
						abundanceArray[counter][row][col] = currentAbundances[row][col];
					}
				}
				counter++;
			}
		}
		return abundanceArray;
	}

	/**
	 * 
	 * GetGridScatter is identical to getGridTimeSeries, except that it scatters the populations
	 * after every time step. This formulation brings the model closer to a "well mixed" DE model, but maintains the effects of local interactions.
	 * 
	 * @param numSteps how many steps should the method run for 
	 * @param measureHowOften how often should data be collected
	 * @return a three dimensional [row][col][time] array of species locationss
	 */
	public int[][][] gridTimeSeriesScatter(int numSteps, int measureHowOften)
	{
		int[][][] abundanceArray = new int[(numSteps / measureHowOften) + 1][this.gridLength][this.gridLength];
		int counter = 0;

		int[][] currentAbundances = this.env.getGrid();
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				abundanceArray[counter][row][col] = currentAbundances[row][col];
			}
		}
		counter++;

		for (int s = 1; s <= numSteps; s++)
		{
			step();
			scatter(); // this is the one step different than getGridTimeSeries
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = this.env.getGrid();
				for (int row = 0; row < this.gridLength; row++)
				{
					for (int col = 0; col < this.gridLength; col++)
					{
						abundanceArray[counter][row][col] = currentAbundances[row][col];
					}
				}
				counter++;
			}
		}
		return abundanceArray;
	}

	/**
	 * 
	 * getGridScatter is identical to getGridTimeSeries, except that it scatters the populations
	 * after every time step. This formulation brings the model closer to a "well mixed" DE model, but maintains the effects of local interactions.
	 * 
	 * @param start run this many time steps before starting
	 * @param end how many time steps elapse in total before the method ends
	 * @param measureHowOften how often should data be collected
	 * @return a three dimensional [row][col][time] array of species locationss
	 */
	public int[][][] gridTimeSeriesScatter(int start, int end, int measureHowOften)
	{
		int numSteps = end - start;
		int[][][] abundanceArray = new int[(numSteps / measureHowOften) + 1][this.gridLength][this.gridLength];
		int counter = 0;
		int s = 1;
		for (; s <= start; s++)
		{
			step();
		}

		int[][] currentAbundances = this.env.getGrid();
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				abundanceArray[counter][row][col] = currentAbundances[row][col];
			}
		}
		counter++;

		for (; s <= end; s++)
		{
			step();
			scatter();
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = this.env.getGrid();
				for (int row = 0; row < this.gridLength; row++)
				{
					for (int col = 0; col < this.gridLength; col++)
					{
						abundanceArray[counter][row][col] = currentAbundances[row][col];
					}
				}
				counter++;
			}
		}
		return abundanceArray;
	}

	public String[] headerForTimeSeries()
	{
		String[] header = new String[this.numberOfSpecies];
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			String curString = "0";

			if (this.speciesList.get(i).makesAA1())
			{
				curString += "1";
			}
			if (this.speciesList.get(i).makesAA2())
			{
				curString += "2";
			}
			if (this.speciesList.get(i).makesAA3())
			{
				curString += "3";
			}

			header[i] = "makesAA" + curString;

		}
		return header;
	}

	/**
	 * Inoculates all the species into a small area in the middle of the envrionment grid. Used to illustrate quadratic population growth. 
	 * 
	 * @param initAbund the cumulative number of individuals that will be inoculated
	 */
	public void inoculateInMiddle(int initAbund)
	{
		// clear env of critters
		this.env.clearEnvOfCritters();

		int inocSquareLength = (int) Math.ceil(Math.sqrt(initAbund * numberOfSpecies));
		int totalInitAbund = inocSquareLength * inocSquareLength;
		int realInitAbund = totalInitAbund / this.numberOfSpecies;

		// set up new abundances
		for (int i = 0; i < numberOfSpecies; i++)
		{
			this.speciesList.get(i).setInitialAbundance(realInitAbund);
		}

		int referenceRowCol = (int) Math.floor(this.gridLength / 2) - (int) Math.ceil(inocSquareLength / (double) 2);

		for (int s = 0; s < this.numberOfSpecies; s++)
		{
			Species curSpecies = this.speciesList.get(s);
			int val = curSpecies.getGridProxy();

			int init = curSpecies.getInitialAbundance();
			int i = 0;
			while (i < init)
			{

				int row = this.generator.nextInt(inocSquareLength) + referenceRowCol;
				int col = this.generator.nextInt(inocSquareLength) + referenceRowCol;
				if (this.env.isEmpty(row, col))
				{
					this.env.add(row, col, val);
					i++;
				}
			}
		}
	}

	/**
	 * 
	 * Randomly places a population on the environment grid.
	 * 
	 * @param speciesListIndex the speciesList index of the species that is to be inoculated
	 * @param overrideOtherCritters if true, overwrite heterospecifics upon inocuation. If false, try to find an empty microsite 500 times. If that doesn't work, go ahead and overwrite heterospecifics
	 */
	public void inoculateSpecies(int speciesListIndex, boolean overrideOtherCritters)
	{
		Species curSpecies = this.speciesList.get(speciesListIndex);
		int val = curSpecies.getGridProxy();

		int init = curSpecies.getInitialAbundance();
		int i = 0;
		// if we don't plan to overwrite other critters
		if (!overrideOtherCritters)

			// do the following for each individual
			while (i < init)
			{
				int k = 0;
				// try to find an empty site 500 times
				while (k < 500)
				{
					int row = this.generator.nextInt(this.env.getGridLength());
					int col = this.generator.nextInt(this.env.getGridLength());
					if (this.env.isEmpty(row, col))
					{
						this.env.add(row, col, val);

						if (!this.useMovingWindowForAACounts)
						{
							if (!useStep2)
							{
								addAAStep1(row, col, curSpecies);
							}
							else
							{
								addAAStep2(row, col, curSpecies);
							}
						}

						break;
					}
					k++;
				}

				// if that doesn't work, keep trying to establish until you find an empty site or a heterospecific
				if (k == 500)
				{
					while (true)
					{
						int row = this.generator.nextInt(this.env.getGridLength());
						int col = this.generator.nextInt(this.env.getGridLength());
						int gridValue = this.env.getGridValue(row, col);
						if (gridValue != val)
						{
							if (gridValue == 0)
							{
								// take over that spot
								this.env.add(row, col, val);
								if (!this.useMovingWindowForAACounts)
								{
									if (!useStep2)
									{
										addAAStep1(row, col, curSpecies);
									}
									else
									{
										addAAStep2(row, col, curSpecies);
									}

								}
							}
							else
							{
								// take over that spot
								this.env.add(row, col, val);
								if (!this.useMovingWindowForAACounts)
								{
									if (!useStep2)
									{
										addAAStep1(row, col, curSpecies);
										subtractAAStep1(row, col, this.speciesList.get(gridValue - 1));
									}
									else
									{
										addAAStep2(row, col, curSpecies);
										subtractAAStep2(row, col, this.speciesList.get(gridValue - 1));

									}
								}
							}

							break;
						}
					}
				}

				i++;

			}
		// if we don't have a problem with overwriting heterospecifics
		else
		{
			// do the following for each individual
			while (i < init)
			{
				// search for an empty site or a site with a heterospecific
				while (true)
				{
					int row = this.generator.nextInt(this.env.getGridLength());
					int col = this.generator.nextInt(this.env.getGridLength());
					int gridValue = this.env.getGridValue(row, col);
					if (gridValue != val)
					{
						if (gridValue == 0)
						{
							// take over that spot
							this.env.add(row, col, val);
							if (!this.useMovingWindowForAACounts)
							{
								if (!useStep2)
								{
									addAAStep1(row, col, curSpecies);
								}
								else
								{
									addAAStep2(row, col, curSpecies);
								}

							}
						}
						else
						{
							// take over that spot
							this.env.add(row, col, val);
							if (!this.useMovingWindowForAACounts)
							{
								if (!useStep2)
								{
									addAAStep1(row, col, curSpecies);
									subtractAAStep1(row, col, this.speciesList.get(gridValue - 1));
								}
								else
								{
									addAAStep2(row, col, curSpecies);
									subtractAAStep2(row, col, this.speciesList.get(gridValue - 1));

								}
							}
						}

						break;
					}
				}
				i++;
			}
		}
	}

	/*
	 * If there are no invaders, add some to each of the invader's good patches. If it's too low, add new invaders the dispersal distance around a randomly selected invader, overwriting residents as neccessary. If it's too high, delete randomly selected invaders
	 */
	public void invaderCheck(Species invader, double tooLow, double tooHigh)
	{
		int invaderValue = invader.getGridProxy();
		double equilibriumDensity = (tooLow + tooHigh) / (double) 2;
		int lowAbund = (int) Math.round(tooLow * this.totalSites);
		int highAbund = (int) Math.round(tooHigh * this.totalSites);

		int equilibriumAbund = (int) Math.round(equilibriumDensity * this.totalSites);
		int invaderIndex = invader.getGridProxy() - 1;
		// System.out.println("too Low is " + lowAbund);
		ArrayList<Location> listOfLocations = getListOfLocations(invader);
		// System.out.println(listOfLocations.size());

		// int totalIndividuals = getTotalNumberOfIndividuals();
		int invaderAbund = listOfLocations.size();
		// //System.out.println(invaderAbund)
		// double invaderDensity = invaderAbund / this.totalSites;

		if (invaderAbund == 0)
		{

			if (equilibriumAbund < 1)
			{
				throw new IllegalStateException("ERROR: the program wants to add less than one individual");
			}
			// System.out.println("THERE ARE NO INVADERS, ADDING SOME");
			this.speciesList.get(invaderIndex).setInitialAbundance(equilibriumAbund);
			inoculateSpecies(invaderIndex, true);
			// //System.out.println("there are no invaders. about to add " + xPerPatch + " individuals per patch.");
			// System.out.println("invaderCheck: about to add " + xPerPatch + " to each patch.");

			// invader.addXIndividualsToEnv(numberToAdd, env);
		}
		else

		if (invaderAbund < lowAbund)
		{
			/*
			 * System.out.println("too low... gonna add some invaders"); System.out.println("invader abund is " + invaderAbund); System.out.println("low abund is " + lowAbund); System.out.println("");
			 */
			int dispersalLength = this.dispersalRadius * 2 + 1;
			int numberToAdd = equilibriumAbund - invaderAbund;
			// //System.out.println("invader density too low. Adding " + numberToAdd + " individuals.");
			if (numberToAdd == 0)
			{
				System.out.println("BLEEEEP");
				throw new IllegalStateException("the disparity between the equilbrium invader density and the equilibrium invader density corresponds to 0 individuasl");
			}
			int k = 0;
			System.out.println("number to add is " + numberToAdd);
			while (k < numberToAdd)
			{
				// System.out.println("k is " + k);
				// System.out.println("k i s " + k + ". Size of location list is " + listOfLocations.size());
				int indexToAddAround = generator.nextInt(listOfLocations.size());
				Location loc = listOfLocations.get(indexToAddAround);
				int critterRow = loc.row();
				int critterCol = loc.col();
				/*
				 * int k = 0; while (k < 100) { int randRow = generator.nextInt(dispersalLength) - this.dispersalAbility; int randCol = generator.nextInt(dispersalLength) - this.dispersalAbility; int newRow = WrapAround.wrapAround(critterRow + randRow, this.gridLength); int newCol = WrapAround.wrapAround(critterCol + randCol, this.gridLength); if (this.env.isEmpty(newRow, newCol)) { Location newLoc = new Location(newRow, newCol); this.env.add(newLoc, this.invaderValue); invaderList.add(new Critter(this.invaderValue, newLoc)); break; } k++; }
				 */

				int randRow = generator.nextInt(dispersalLength) - this.dispersalRadius;
				int randCol = generator.nextInt(dispersalLength) - this.dispersalRadius;
				int newRow = WrapAround.wrapAround(critterRow + randRow, this.gridLength);
				int newCol = WrapAround.wrapAround(critterCol + randCol, this.gridLength);
				int gridValue = this.env.getGridValue(newRow, newCol);
				if (gridValue == 0)
				{
					this.env.add(newRow, newCol, invaderValue);
					listOfLocations.add(new Location(newRow, newCol));

					if (!this.useMovingWindowForAACounts)
					{
						if (useStep2)
						{
							addAAStep2(newRow, newCol, invader);
						}
						else
						{
							addAAStep1(newRow, newCol, invader);
						}
					}

					k++;

				}
				else if (gridValue != invaderValue)
				{
					this.env.add(newRow, newCol, invaderValue);
					listOfLocations.add(new Location(newRow, newCol));
					if (!this.useMovingWindowForAACounts)
					{
						if (useStep2)
						{
							addAAStep2(newRow, newCol, invader);
							subtractAAStep2(newRow, newCol, this.speciesList.get(gridValue - 1));

						}
						else
						{
							addAAStep1(newRow, newCol, invader);
							subtractAAStep1(newRow, newCol, this.speciesList.get(gridValue - 1));

						}
					}
					k++;
				}
			}
			// System.out.println("done adding invaders");
		}
		else if (invaderAbund > highAbund)
		{
			int numberToRemove = invaderAbund - equilibriumAbund;
			/*
			 * System.out.println("invader density too high. Removing " + numberToRemove + " individuals."); System.out.println("invader abund is " + invaderAbund); System.out.println("high abund is " + highAbund); System.out.println("");
			 */
			if (numberToRemove == 0)
			{
				throw new IllegalStateException("the disparity between the equilbrium invader density and the equilibrium invader density corresponds to 0 individuasl");
			}

			for (int i = 0; i < numberToRemove; i++)
			{
				int indexToRemove = generator.nextInt(listOfLocations.size());
				Location loc = listOfLocations.get(indexToRemove);
				this.env.remove(loc);
				if (!this.useMovingWindowForAACounts)
				{
					if (useStep2)
					{
						subtractAAStep2(loc.row(), loc.col(), invader);
					}
					else
					{
						subtractAAStep1(loc.row(), loc.col(), invader);
					}
				}
				listOfLocations.remove(indexToRemove);
			}
		}
	}

	/*
	 * public double[] measureStuff(int numMeasurements, int timeBetweenMeasurements, double tooLow, double tooHigh, int inoculateWhen, int stepsAfterInoculation, double dt, int gridLength, int AADispersalRadius, int dispersalRadius, double KAAProduced, double death, double initCMaxCheat, double deltaB0, double cMaxSyn1, double cMaxSyn2, boolean useStep2, double initProp0, double AA1Kx0, double AA2Kx0, double AA1Kx1, double AA2Kx1, double AA1Kx2, double AA2Kx2) { double[] toReturn = new double[57]; double cmax0 = initCMaxCheat;
	 * 
	 * double L0 = 0; double L1 = 0; double L2 = 0; double covfCE0 = 0; double covfCE1 = 0; double covfCE2 = 0; double deltaOverB1 = 0; double deltaOverB2 = 0; double covFitnessDensity1 = 0; double covFitnessDensity2 = 0; double covEmptySiteDensity1 = 0; double covEmptySiteDensity2 = 0; double covFCDensity1 = 0; double covFCDensity2 = 0; double covKN1LocalBarDensity2 = 0; double covKN2LocalBarDensity1 = 0;
	 * 
	 * double L0After = 0; double L1After = 0; double L2After = 0; double covfCE0After = 0; double covfCE1After = 0; double covfCE2After = 0; double covFitnessDensity0After = 0; double covFitnessDensity1After = 0; double covFitnessDensity2After = 0; double covEmptySiteDensity0After = 0; double covEmptySiteDensity1After = 0; double covEmptySiteDensity2After = 0; double covFCDensity0After = 0; double covFCDensity1After = 0; double covFCDensity2After = 0; double covKN1LocalBarDensity2After = 0; double covKN2LocalBarDensity1After = 0; double covKN1LocalBarDensity0After = 0; double covKN2LocalBarDensity0After = 0; double b0After = 0; double N0After = 0;
	 * 
	 * double L0AfterInvasion = 0; double L1AfterInvasion = 0; double L2AfterInvasion = 0; double covfCE0AfterInvasion = 0; double covfCE1AfterInvasion = 0; double covfCE2AfterInvasion = 0; double covFitnessDensity0AfterInvasion = 0; double covFitnessDensity1AfterInvasion = 0; double covFitnessDensity2AfterInvasion = 0; double covEmptySiteDensity0AfterInvasion = 0; double covEmptySiteDensity1AfterInvasion = 0; double covEmptySiteDensity2AfterInvasion = 0; double covFCDensity0AfterInvasion = 0; double covFCDensity1AfterInvasion = 0; double covFCDensity2AfterInvasion = 0; double covKN1LocalBarDensity2AfterInvasion = 0; double covKN2LocalBarDensity1AfterInvasion = 0; double covKN1LocalBarDensity0AfterInvasion = 0; double covKN2LocalBarDensity0AfterInvasion = 0; double N0AfterInvasion = 0;
	 * 
	 * 
	 * Community refCom = new Community(this); Community tempCom = new Community(this); tempCom.step(this.speciesList.get(0).getInoculateWhen());
	 * 
	 * // make a carbon copy of the temporary community (the community with the cheater). Community invasionCom = new Community(tempCom); // step once to inoculate the cheater
	 * 
	 * tempCom.step(); invasionCom.step();
	 * 
	 * 
	 * // take the sum (over time) of metrics in the reference community (no cheater), the tempCom (the community with the unabated cheater), and the invasion community (where the cehater is kept at low density). for (int m = 0; m < numMeasurements; m++) { refCom.step(timeBetweenMeasurements); L0 += refCom.getL(speciesList.get(0)); L1 += refCom.getL(speciesList.get(1)); L2 += refCom.getL(speciesList.get(2)); covfCE0 += refCom.getfCEmptySiteCov(speciesList.get(0)); covfCE1 += refCom.getfCEmptySiteCov(speciesList.get(1)); covfCE2 += refCom.getfCEmptySiteCov(speciesList.get(2)); deltaOverB1 += death / cMaxSyn1; deltaOverB2 += death / cMaxSyn2; covFitnessDensity1 += refCom.getFitnessDensityCovariance(speciesList.get(1)); covFitnessDensity2 += refCom.getFitnessDensityCovariance(speciesList.get(2)); covEmptySiteDensity1 += refCom.getEmptySiteDensityCovariance(speciesList.get(1)); covEmptySiteDensity2 += refCom.getEmptySiteDensityCovariance(speciesList.get(2)); covFCDensity1 +=
	 * refCom.getFCDensityCovariance(speciesList.get(1)); covFCDensity2 += refCom.getFCDensityCovariance(speciesList.get(2)); covKN1LocalBarDensity2 += refCom.getKNBar1DensityCovariance(speciesList.get(2)); covKN2LocalBarDensity1 += refCom.getKNBar2DensityCovariance(speciesList.get(1));
	 * 
	 * tempCom.step(timeBetweenMeasurements);
	 * 
	 * L0After += tempCom.getL(speciesList.get(0)); L1After += tempCom.getL(speciesList.get(1)); L2After += tempCom.getL(speciesList.get(2)); covfCE0After += tempCom.getfCEmptySiteCov(speciesList.get(0)); covfCE1After += tempCom.getfCEmptySiteCov(speciesList.get(1)); covfCE2After += tempCom.getfCEmptySiteCov(speciesList.get(2)); covFitnessDensity0After += tempCom.getFitnessDensityCovariance(speciesList.get(0)); covFitnessDensity1After += tempCom.getFitnessDensityCovariance(speciesList.get(1)); covFitnessDensity2After += tempCom.getFitnessDensityCovariance(speciesList.get(2)); covEmptySiteDensity0After += tempCom.getEmptySiteDensityCovariance(speciesList.get(0)); covEmptySiteDensity1After += tempCom.getEmptySiteDensityCovariance(speciesList.get(1)); covEmptySiteDensity2After += tempCom.getEmptySiteDensityCovariance(speciesList.get(2)); covFCDensity0After += tempCom.getFCDensityCovariance(speciesList.get(0)); covFCDensity1After += tempCom.getFCDensityCovariance(speciesList.get(1));
	 * covFCDensity2After += tempCom.getFCDensityCovariance(speciesList.get(2)); covKN1LocalBarDensity0After += tempCom.getKNBar1DensityCovariance(speciesList.get(0)); covKN2LocalBarDensity0After += tempCom.getKNBar2DensityCovariance(speciesList.get(0)); covKN1LocalBarDensity2After += tempCom.getKNBar1DensityCovariance(speciesList.get(2)); covKN2LocalBarDensity1After += tempCom.getKNBar2DensityCovariance(speciesList.get(1)); b0After += cmax0; N0After += tempCom.getAbundances(true)[0];
	 * 
	 * for (int step = 0; step < timeBetweenMeasurements; step++) { invasionCom.step(); invasionCom.invaderCheck(speciesList.get(0), tooLow, tooHigh); }
	 * 
	 * L0AfterInvasion += invasionCom.getL(speciesList.get(0)); L1AfterInvasion += invasionCom.getL(speciesList.get(1)); L2AfterInvasion += invasionCom.getL(speciesList.get(2)); covfCE0AfterInvasion += invasionCom.getfCEmptySiteCov(speciesList.get(0)); covfCE1AfterInvasion += invasionCom.getfCEmptySiteCov(speciesList.get(1)); covfCE2AfterInvasion += invasionCom.getfCEmptySiteCov(speciesList.get(2)); covFitnessDensity0AfterInvasion += invasionCom.getFitnessDensityCovariance(speciesList.get(0)); covFitnessDensity1AfterInvasion += invasionCom.getFitnessDensityCovariance(speciesList.get(1)); covFitnessDensity2AfterInvasion += invasionCom.getFitnessDensityCovariance(speciesList.get(2)); covEmptySiteDensity0AfterInvasion += invasionCom.getEmptySiteDensityCovariance(speciesList.get(0)); covEmptySiteDensity1AfterInvasion += invasionCom.getEmptySiteDensityCovariance(speciesList.get(1)); covEmptySiteDensity2AfterInvasion += invasionCom.getEmptySiteDensityCovariance(speciesList.get(2));
	 * covFCDensity0AfterInvasion += invasionCom.getFCDensityCovariance(speciesList.get(0)); covFCDensity1AfterInvasion += invasionCom.getFCDensityCovariance(speciesList.get(1)); covFCDensity2AfterInvasion += invasionCom.getFCDensityCovariance(speciesList.get(2)); covKN1LocalBarDensity0AfterInvasion += invasionCom.getKNBar1DensityCovariance(speciesList.get(0)); covKN2LocalBarDensity0AfterInvasion += invasionCom.getKNBar2DensityCovariance(speciesList.get(0)); covKN1LocalBarDensity2AfterInvasion += invasionCom.getKNBar1DensityCovariance(speciesList.get(2)); covKN2LocalBarDensity1AfterInvasion += invasionCom.getKNBar2DensityCovariance(speciesList.get(1)); N0AfterInvasion += invasionCom.getAbundances(true)[0];
	 * 
	 * }
	 * 
	 * // / get the average. toReturn[0] = L0 / (double) numMeasurements; toReturn[1] = L1 / (double) numMeasurements; toReturn[2] = L2 / (double) numMeasurements; toReturn[3] = covfCE0 / (double) numMeasurements; toReturn[4] = covfCE1 / (double) numMeasurements; toReturn[5] = covfCE2 / (double) numMeasurements; toReturn[6] = deltaOverB1 / (double) numMeasurements; toReturn[7] = deltaOverB2 / (double) numMeasurements; toReturn[8] = covFitnessDensity1 / (double) numMeasurements; toReturn[9] = covFitnessDensity2 / (double) numMeasurements; toReturn[10] = covEmptySiteDensity1 / (double) numMeasurements; toReturn[11] = covEmptySiteDensity2 / (double) numMeasurements; toReturn[12] = covFCDensity1 / (double) numMeasurements; toReturn[13] = covFCDensity2 / (double) numMeasurements; toReturn[14] = covKN1LocalBarDensity2 / (double) numMeasurements; toReturn[15] = covKN2LocalBarDensity1 / (double) numMeasurements;
	 * 
	 * toReturn[16] = L0After / (double) numMeasurements; toReturn[17] = L1After / (double) numMeasurements; toReturn[18] = L2After / (double) numMeasurements; toReturn[19] = covfCE0After / (double) numMeasurements; toReturn[20] = covfCE1After / (double) numMeasurements; toReturn[21] = covfCE2After / (double) numMeasurements; toReturn[22] = covFitnessDensity0After / (double) numMeasurements; toReturn[23] = covFitnessDensity1After / (double) numMeasurements; toReturn[24] = covFitnessDensity2After / (double) numMeasurements; toReturn[25] = covEmptySiteDensity0After / (double) numMeasurements; toReturn[26] = covEmptySiteDensity1After / (double) numMeasurements; toReturn[27] = covEmptySiteDensity2After / (double) numMeasurements; toReturn[28] = covFCDensity0After / (double) numMeasurements; toReturn[29] = covFCDensity1After / (double) numMeasurements; toReturn[30] = covFCDensity2After / (double) numMeasurements; toReturn[31] = covKN1LocalBarDensity2After / (double) numMeasurements;
	 * toReturn[32] = covKN2LocalBarDensity1After / (double) numMeasurements; toReturn[33] = covKN1LocalBarDensity0After / (double) numMeasurements; toReturn[34] = covKN2LocalBarDensity0After / (double) numMeasurements; toReturn[35] = b0After / (double) numMeasurements; toReturn[36] = N0After / (double) numMeasurements;
	 * 
	 * toReturn[37] = L0AfterInvasion / (double) numMeasurements; toReturn[38] = L1AfterInvasion / (double) numMeasurements; toReturn[39] = L2AfterInvasion / (double) numMeasurements; toReturn[40] = covfCE0AfterInvasion / (double) numMeasurements; toReturn[41] = covfCE1AfterInvasion / (double) numMeasurements; toReturn[42] = covfCE2AfterInvasion / (double) numMeasurements; toReturn[43] = covFitnessDensity0AfterInvasion / (double) numMeasurements; toReturn[44] = covFitnessDensity1AfterInvasion / (double) numMeasurements; toReturn[45] = covFitnessDensity2AfterInvasion / (double) numMeasurements; toReturn[46] = covEmptySiteDensity0AfterInvasion / (double) numMeasurements; toReturn[47] = covEmptySiteDensity1AfterInvasion / (double) numMeasurements; toReturn[48] = covEmptySiteDensity2AfterInvasion / (double) numMeasurements; toReturn[49] = covFCDensity0AfterInvasion / (double) numMeasurements; toReturn[50] = covFCDensity1AfterInvasion / (double) numMeasurements; toReturn[51] =
	 * covFCDensity2AfterInvasion / (double) numMeasurements; toReturn[52] = covKN1LocalBarDensity2AfterInvasion / (double) numMeasurements; toReturn[53] = covKN2LocalBarDensity1AfterInvasion / (double) numMeasurements; toReturn[54] = covKN1LocalBarDensity0AfterInvasion / (double) numMeasurements; toReturn[55] = covKN2LocalBarDensity0AfterInvasion / (double) numMeasurements; toReturn[56] = N0AfterInvasion / (double) numMeasurements;
	 * 
	 * 
	 * return toReturn;
	 * 
	 * }
	 */
	/**
	 * Makes sure that no species can be added to the environmment after this method is called.
	 */
	public void neverInoculate()
	{
		this.neverInoculate = true;

	}

	/**
	 * If there are no species that produce amino acid three, then make it so no species need amino acid 3. This method is 
	 * for when you're interested in the set/subsets of microbes 0, 1, 2, 12.
	 */
	public void noAA3()
	{
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			this.speciesList.get(i).dontUseAA3();
		}
	}

	/**
	 * call this method to find the most efficient step method. Runs tests with auser specified number of steps.
	 * @param testSteps how many steps the program should run and time for each combination of stepping algorithm.
	 */
	public void optimizeEfficiency(int testSteps)
	{

		if (this.useStep2)
		{
			long start = 0;
			long end = 0;
			long nanoTime1 = 0;
			long nanoTime2 = 0;
			long nanoTime3 = 0;
			long nanoTime4 = 0;

			start = System.nanoTime();
			Community comTemp = new Community(this);
			comTemp.setSeed(20);
			for (int i = 0; i < testSteps; i++)
			{
				comTemp.step2AAMovingWindowCGRMovingWindow();
			}
			end = System.nanoTime();
			nanoTime1 = end - start;
			// System.out.println("step2 " + nanoTime / (double) 1000000000 + " seconds");

			start = System.nanoTime();
			Community comTemp2 = new Community(this);
			comTemp.setSeed(20);
			for (int i = 0; i < testSteps; i++)
			{
				comTemp2.step2AAUpdateCGRMovingWindow();
			}
			end = System.nanoTime();
			nanoTime2 = end - start;
			// System.out.println("step2g " + nanoTime2 / (double) 1000000000 + " seconds");
			if (nanoTime1 < nanoTime2)
			{
				this.useMovingWindowForAACounts = true;
				System.out.println("step2: using a moving window to calculate amino acid counts");
			}
			else
			{
				this.useMovingWindowForAACounts = false;
				System.out.println("step2: using individual-based updating to calculate amino acid counts");

			}

			// ////// NOW FOR THE CGR MOVING WINDOW
			start = System.nanoTime();
			Community comTemp3 = new Community(this);
			comTemp.setSeed(20);
			for (int i = 0; i < testSteps; i++)
			{
				comTemp3.step2AAUpdateCGRMovingWindow();
			}
			end = System.nanoTime();
			nanoTime3 = end - start;
			// System.out.println("step2 " + nanoTime / (double) 1000000000 + " seconds");

			start = System.nanoTime();
			Community comTemp4 = new Community(this);
			comTemp.setSeed(20);
			for (int i = 0; i < testSteps; i++)
			{
				comTemp4.step2AAUpdateCGRBland();
			}
			end = System.nanoTime();
			nanoTime4 = end - start;
			// System.out.println("step2g " + nanoTime2 / (double) 1000000000 + " seconds");
			if (nanoTime3 < nanoTime4)
			{
				this.useMovingWindowForCumulativeGrowthRates = true;
				System.out.println("step2: using a moving window to calculate growth rates");

			}
			else
			{
				this.useMovingWindowForCumulativeGrowthRates = false;
				System.out.println("step2: using individual-based measurements to calculate growth rates");

			}
		}
		else
		{
			long start = 0;
			long end = 0;
			long nanoTime1 = 0;
			long nanoTime2 = 0;

			start = System.nanoTime();
			Community comTemp = new Community(this);
			comTemp.setSeed(20);
			for (int i = 0; i < testSteps; i++)
			{
				comTemp.step1AAMovingWindow();
			}
			end = System.nanoTime();
			nanoTime1 = end - start;
			// System.out.println("step2 " + nanoTime / (double) 1000000000 + " seconds");

			start = System.nanoTime();
			Community comTemp2 = new Community(this);
			comTemp.setSeed(20);
			for (int i = 0; i < testSteps; i++)
			{
				comTemp2.step1AAUpdate();
			}
			end = System.nanoTime();
			nanoTime2 = end - start;
			// System.out.println("step2g " + nanoTime2 / (double) 1000000000 + " seconds");
			if (nanoTime1 < nanoTime2)
			{
				this.useMovingWindowForAACounts = true;
				System.out.println("step1: using a moving window to calculate amino acid counts");

			}
			else
			{
				this.useMovingWindowForAACounts = false;
				System.out.println("step1: using individual-based updating to calculate amino acid counts");

			}
		}

	}

	/**
	 * resets the community. Time goes back to zero and the environment has no critters.
	 */
	public void reset()
	{
		this.env.clearEnvOfCritters();
		this.timeStep = 0;
		this.neverInoculate = false;
		this.AAGrid = new double[this.gridLength][this.gridLength][3];
		this.critterCountGrid = new int[this.gridLength][this.gridLength][this.numberOfSpecies];
	}

	/**
	 * scales species birth and death rates by dt. The lower the dt, the more simulation steps are in a single time unit; called by the community constructor.
	 * 
	 */
	public void scaleByDt()
	{
		for (int s = 0; s < this.numberOfSpecies; s++)
		{
			Species tempSpecies = this.speciesList.get(s);
			tempSpecies.setCmax(tempSpecies.getCmax() * this.dt);
			tempSpecies.setD(tempSpecies.getD() * this.dt);
			tempSpecies.setInoculateWhen((int) Math.round(tempSpecies.getInoculateWhen() / this.dt));
		}

		/*
		 * for (int s = 0; s < this.numberOfSpecies; s++) { Species tempSpecies = this.speciesList.get(s); System.out.println("species " + s + " has a birth rate of " + tempSpecies.getCmax()); System.out.println("species " + s + " has a death rate of " + tempSpecies.getD()); System.out.println(""); }
		 */
	}

	/**
	 * The program scatter randomly mixes up all of the individuals, without changing
	 * the actual population.
	 */
	public void scatter()
	{

		double[] currentAbundances = getAbundances(false);

		// Here I clear out the population, so I can add new microbes back in.
		// Basically, I go through the grid, and if a location is occupied, I remove it.
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.isOccupied(row, col))
				{
					this.env.remove(row, col);
				}
			}
		}

		// I then randomly adds specified number of individuals to the grid.
		// This code is copied from when we create the initial population.
		for (int jtemp = 1; jtemp < this.numberOfSpecies + 1; jtemp++)
		{

			double init = currentAbundances[jtemp - 1];
			int i = 0;

			// I repeatedly add in new individuals until I have added in
			// a number equal to the currentAbundance of that species.
			while (i < init)
			{

				// Choose a random location- (X,Y) coordinate.
				int row = this.generator.nextInt(this.env.getGridLength());
				int col = this.generator.nextInt(this.env.getGridLength());

				// This is to make sure that I add the microbe to an empty space.
				// If it is empty, I add it. Otherwise, I draw a new random number
				if (this.env.isEmpty(row, col))
				{
					this.env.add(row, col, jtemp);
					i++;
				}
			}
		}
		
		if(this.useStep2)
		{
			fillAAGridStep2();
		} else
		{
			fillAAGridStep1();
		}

	}

	/**
	 * 	The program scatter randomly mixes up all of the individuals, without changing
	 * the actual population. This uses a different randomization algorithm than scatter().
	 */
	public void scatter2()
	{

		double[] currentAbundances = getAbundances(false);
		int total = this.gridLength * this.gridLength;
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			total += currentAbundances[i];
		}

		// Here I clear out the population, so I can add new microbes back in.
		// Basically, I go through the grid, and if a location is occupied, I remove it.
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.isOccupied(row, col))
				{
					this.env.remove(row, col);
				}
			}
		}

		int[] ar = new int[total];
		for (int i = 0; i < total; i++)
		{
			ar[i] = i;
		}

		for (int i = 0; i < total - 1; i++)
		{
			int num = this.generator.nextInt(total - i);
			int temp = ar[num];
			ar[num] = ar[total - 1 - i];
			ar[total - 1 - i] = temp;
		}

		int counter = 0;
		for (int jtemp = 1; jtemp < this.numberOfSpecies + 1; jtemp++)
		{

			double init = currentAbundances[jtemp - 1];

			// I repeatedly add in new individuals until I have added in
			// a number equal to the currentAbundance of that species.
			for (int i = 0; i < init; i++)
			{
				int row = ar[counter] / this.gridLength;
				int col = ar[counter] % this.gridLength;
				counter++;

				this.env.add(row, col, jtemp);
			}
		}
		
		if(this.useStep2)
		{
			fillAAGridStep2();
		} else
		{
			fillAAGridStep1();
		}

	}

	/**
	 * Sets a new AADispersalRadius.
	 * @param AADispersalRadius
	 */
	public void setAADispersalRadius(int AADispersalRadius)
	{
		this.AADispersalRadius = AADispersalRadius;
		int dispersalAALength = this.AADispersalRadius * 2 + 1;
		this.possibleNeighbors = dispersalAALength * dispersalAALength - 1;
		this.KAAProducedOverPossibleAANeighbors = this.KAAProduced / (double) this.possibleAANeighbors;
	}

	/*
	 * // could add a moving window later public void setCumulativeGrowthRateGrid() {
	 * 
	 * this.cumulativeGrowthRateGrid = new double[this.gridLength][this.gridLength][this.numberOfSpecies];
	 * 
	 * for (int row = 0; row < this.gridLength; row++) { for (int col = 0; col < this.gridLength; col++) {
	 * 
	 * for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++) { for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++) {
	 * 
	 * int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength);
	 * 
	 * int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) { this.cumulativeGrowthRateGrid[row][col][gridValue - 1] += this.growthRateGrid[realRow][realCol][gridValue - 1]; } } } } } }
	 */
	/**
	 * Sets a new dispersalRadius.
	 * @param dispersalRadius
	 */
	public void setDispersalRadius(int dispersalRadius)
	{
		this.dispersalRadius = dispersalRadius;
		int dispersalLength = this.dispersalRadius * 2 + 1;
		this.possibleNeighbors = dispersalLength * dispersalLength - 1;
		this.KAAProducedOverPossibleNeighbors = this.KAAProduced / (double) this.possibleNeighbors;
	}

	/**
	 * gives the simulation a new dt (time scaling factor) and changes the birth and death rates accordingly.
	 * @param newDt
	 */
	public void setDt(double newDt)
	{
		this.dt = newDt;
		scaleByDt();
	}

	/**
	 * Replaces the old environment grid with the grid parameter. WARNING: Note that simulations require species-specific information that is stored in the speciesList;
	 * if species in the grid parameter don't match up with the species in the species list, the simulation will run funky i.e. individuals of a species will never die or reproduce.  
	 * @param grid
	 */
	public void setGrid(int[][] grid)
	{
		this.env.setGrid(grid);
	}

	/**
	 * Sets the time step counter. Although the timeStep variable is incremented after every step() call, the timeStep variable is only useful in determining when species are inoculated.
	 * Time dependent methods (e.g. timeseries(...), gridTimeSeries(...), finalValues(...) ) use a local time variable to keep track of time.
	 * @param timeStep
	 */
	public void seTimeStep(int timeStep)
	{
		this.timeStep = timeStep;
	}

	/*
	 * public void setGrowthRateGrid() { this.growthRateGrid = new double[this.gridLength][this.gridLength][this.numberOfSpecies];
	 * 
	 * for (int row = 0; row < this.gridLength; row++) { for (int col = 0; col < this.gridLength; col++) { int gridValue = this.env.getGridValue(row, col); if (gridValue != 0) { Species currentSpecies = this.speciesList.get(gridValue - 1);
	 * 
	 * this.growthRateGrid[row][col][gridValue - 1] = currentSpecies.getCmax() * getResourceLimitation(row, col); } } } }
	 */

	/**
	 * Set a new KAAProduced.
	 * @param KAAProduced
	 */
	public void setKAAProduced(double KAAProduced)
	{
		this.KAAProduced = KAAProduced;
		this.KAAProducedOverPossibleNeighbors = this.KAAProduced / (double) this.possibleNeighbors;
		this.KAAProducedOverPossibleAANeighbors = this.KAAProduced / (double) this.possibleAANeighbors;

	}

	/**
	 * Setting the seed allows simulations to be repeatable.
	 * @param setHere
	 */
	public void setSeed(int setHere)
	{
		this.generator.setSeed(setHere);
	}

	/**
	 * Tells the simulation to use the time stepping function where amino acid availibility directly affects recruitment.
	 */
	public void setToStep1()
	{
		this.useStep2 = false;
	}

	/**
	 * Tells the simulations to use the time stepping function where amino acid availibility directly affects fecunditiy, i.e. adult reproductie capability.
	 */
	public void setToStep2()
	{
		this.useStep2 = true;
	}

	/**
	 * @param YorN if true, then a moving window algorithm will be used for counting up amino acids. If false, amino acids will be dynamically updated when an individual is added to the landscape. 
	 */
	public void setUseMovingWindowForAACounts(boolean YorN)
	{
		this.useMovingWindowForAACounts = YorN;
	}

	/**
	 * @param YorN if true, then a moving window algorithm will be used for counting up the realized birth rates of conspecifics. If false, birth rates will be summed on an ad hoc basis (see step2AAUpdateCGRBland or step2AAMovingWindowCGRBland) 
	 */
	public void setUseMovingWindowForCumulativeGrowthRates(boolean YorN)
	{
		this.useMovingWindowForCumulativeGrowthRates = YorN;
	}

	/**
	 * Calls either step1 or step2. The variants of the step1 or step2 methods are for the sake of efficiency. A couple of rules of thumb determine the exact stepping method in the constructor, but optimizeEfficiency() can be called for more certainty.
	 * The useStep2 variable decides which stepping method to use. The useStep2 variable can be set in the constructor or in the methods setToStep1() and setToStep2().
	 * @param numSteps
	 */
	public void step()
	{
		if (this.useStep2)
		{
			if (this.useMovingWindowForCumulativeGrowthRates)
			{
				if (this.useMovingWindowForAACounts)
				{
					step2AAMovingWindowCGRMovingWindow();

				}
				else
				{
					step2AAUpdateCGRMovingWindow();

				}
			}
			else
			{
				if (this.useMovingWindowForAACounts)
				{
					step2AAMovingWindowCGRBland();

				}
				else
				{
					step2AAUpdateCGRBland();

				}
			}
		}
		else
		{
			if (this.useMovingWindowForAACounts)
			{
				step1AAMovingWindow();

			}
			else
			{
				step1AAUpdate();

			}

		}
	}

	/**
	 * Calls either step1 or step2. The variants of the step1 or step2 methods are for the sake of efficiency. A couple of rules of thumb determine the exact stepping method in the constructor, but optimizeEfficiency() can be called for more certainty.
	 * The useStep2 variable decides which stepping method to use. The useStep2 variable can be set in the constructor or in the methods setToStep1() and setToStep2().
	 * @param numSteps
	 */
	public void step(int numSteps)
	{
		if (this.useStep2)
		{
			if (this.useMovingWindowForCumulativeGrowthRates)
			{
				if (this.useMovingWindowForAACounts)
				{
					for (int i = 0; i < numSteps; i++)
					{
						step2AAMovingWindowCGRMovingWindow();
					}
				}
				else
				{
					for (int i = 0; i < numSteps; i++)
					{
						step2AAUpdateCGRMovingWindow();
					}
				}
			}
			else
			{
				if (this.useMovingWindowForAACounts)
				{
					for (int i = 0; i < numSteps; i++)
					{
						step2AAMovingWindowCGRBland();
					}
				}
				else
				{
					for (int i = 0; i < numSteps; i++)
					{
						step2AAUpdateCGRBland();
					}
				}
			}
		}
		else
		{
			if (this.useMovingWindowForAACounts)
			{
				for (int i = 0; i < numSteps; i++)
				{
					step1AAMovingWindow();
				}
			}
			else
			{
				for (int i = 0; i < numSteps; i++)
				{
					step1AAUpdate();
				}
			}

		}
	}

	public boolean stepAndMaybeTerminate(int numSteps, int checkHowOften, int speciesIndex)
	{
		boolean terminate = false;
		if (this.useStep2)
		{
			if (this.useMovingWindowForCumulativeGrowthRates)
			{
				if (this.useMovingWindowForAACounts)
				{
					for (int i = 0; i < numSteps; i++)
					{
						// long start = System.nanoTime();

						/*
						 * System.out.println(nanoTime + " nanoseconds"); System.out.println(nanoTime/(double)1000000 + " milliseconds");
						 */

						step2AAMovingWindowCGRMovingWindow();
						/*
						 * long end = System.nanoTime(); long nanoTime = end - start;
						 * 
						 * System.out.println("step: " + nanoTime / (double) 1000 + "micro-seconds");
						 */

						if (this.timeStep / checkHowOften != 0 && this.timeStep % checkHowOften == 0)
						{
							// start = System.nanoTime();
							if (getAbundances(false)[speciesIndex] == 0)
							{
								terminate = true;
								break;
							}
							/*
							 * end = System.nanoTime(); nanoTime = end - start;
							 * 
							 * System.out.println("check abundances took: " + nanoTime / (double) 1000 + " micro-seconds"); System.out.println("");
							 */
						}
					}
				}
				else
				{
					for (int i = 0; i < numSteps; i++)
					{
						step2AAUpdateCGRMovingWindow();
						if (this.timeStep / checkHowOften != 0 && this.timeStep % checkHowOften == 0)
						{
							if (getAbundances(false)[speciesIndex] == 0)
							{
								terminate = true;
								break;
							}
						}
					}
				}
			}
			else
			{
				if (this.useMovingWindowForAACounts)
				{
					for (int i = 0; i < numSteps; i++)
					{
						step2AAMovingWindowCGRBland();
						if (this.timeStep / checkHowOften != 0 && this.timeStep % checkHowOften == 0)
						{
							if (getAbundances(false)[speciesIndex] == 0)
							{
								terminate = true;
								break;
							}
						}
					}
				}
				else
				{
					for (int i = 0; i < numSteps; i++)
					{
						step2AAUpdateCGRBland();
						if (this.timeStep / checkHowOften != 0 && this.timeStep % checkHowOften == 0)
						{
							if (getAbundances(false)[speciesIndex] == 0)
							{
								terminate = true;
								break;
							}
						}

					}
				}
			}
		}
		else
		{
			if (this.useMovingWindowForAACounts)
			{
				for (int i = 0; i < numSteps; i++)
				{
					step1AAMovingWindow();
					if (this.timeStep / checkHowOften != 0 && this.timeStep % checkHowOften == 0)
					{
						if (getAbundances(false)[speciesIndex] == 0)
						{
							terminate = true;
							break;
						}
					}
				}
			}
			else
			{
				for (int i = 0; i < numSteps; i++)
				{
					step1AAUpdate();
					if (this.timeStep / checkHowOften != 0 && this.timeStep % checkHowOften == 0)
					{
						if (getAbundances(false)[speciesIndex] == 0)
						{
							terminate = true;
							break;
						}
					}
				}
			}
		}
		System.out.println(this.timeStep);
		return terminate;
	}

	/**
	 * a stepping method where AA avaibility affectss recruitment, and where the amino acids are kept track of using a moving window algorithm. Good for large AADispersalRadius parameter values;
	 */
	public void step1AAMovingWindow()
	{
		checkForInoculations();

		fillAAGridStep1();

		ArrayList<Location> toRemoveLocation = new ArrayList<Location>();
		ArrayList<Species> toRemoveCritter = new ArrayList<Species>();

		ArrayList<Location> toAddLocation = new ArrayList<Location>();
		ArrayList<Species> toAddCritter = new ArrayList<Species>();

		// go throught the rows and columns
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				int gridValue = this.env.getGridValue(row, col);
				if (gridValue != 0)
				{

					double deathProb = this.speciesList.get(gridValue - 1).getD();
					if (this.generator.nextDouble() < deathProb)
					{
						// index it to remove at the end of the time step
						toRemoveLocation.add(new Location(row, col));
						toRemoveCritter.add(this.speciesList.get(gridValue - 1));
					}
					// if it does die, go to the next row,col location
					continue;
				}
				else
				// if it's empty, enter birth process
				{

					double[] birthProbs = new double[this.numberOfSpecies];
					double AA1Avail = this.AAGrid[row][col][0];
					double AA2Avail = this.AAGrid[row][col][1];
					double AA3Avail = this.AAGrid[row][col][2];

					// System.out.println(counter);
					// System.out.println(AACounts[0]);

					// for each critter determine the term of the birth probability that follows leibigs law of the minimum with respect to AA.
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						Species currentSpecies = this.speciesList.get(spp);
						double tempF = 1;
						if (!currentSpecies.makesAA1())
						{
							if (AA1Avail / currentSpecies.getAA1K() < tempF)
							{
								tempF = AA1Avail / currentSpecies.getAA1K();
							}
						}

						if (!currentSpecies.makesAA2())
						{
							if (AA2Avail / currentSpecies.getAA2K() < tempF)
							{
								tempF = AA2Avail / currentSpecies.getAA2K();
							}
						}

						if (!currentSpecies.makesAA3())
						{
							if (AA3Avail / currentSpecies.getAA3K() < tempF)
							{
								tempF = AA3Avail / currentSpecies.getAA3K();
							}
						}

						// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
						// are around to give birth
						birthProbs[spp] = currentSpecies.getCmax() * tempF * (this.critterCountGrid[row][col][spp] / (double) this.possibleAANeighbors);

					}

					// figure out which bacterium (if any) is going to give birth
					double theBirthProb = this.generator.nextDouble();
					double compareTo = 0;
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						compareTo += birthProbs[spp];

						if (theBirthProb < compareTo)
						{
							toAddCritter.add(this.speciesList.get(spp));
							toAddLocation.add(new Location(row, col));
							// this.env.add(new Location(row, col), this.speciesList.get(spp).getGridProxy());
							break;
						}

					}
				}
			}

		}

		// Exception thrower if critters and location get unsynchronized
		/*
		 * if (toAddLocation.size() != toAddCritter.size()) { IllegalStateException e = new IllegalStateException("critters and locations are unsynchronized"); throw e; }
		 */
		for (int i = 0; i < toRemoveLocation.size(); i++)
		{
			Location loc = toRemoveLocation.get(i);
			this.env.remove(loc.row(), loc.col());

		}
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location loc = toAddLocation.get(i);
			Species tempSpecies = toAddCritter.get(i);
			this.env.add(loc, tempSpecies.getGridProxy());
		}
		this.timeStep++;
	}

	/**
	 * 
	 * Execute one time step where amino acid availibility affects recruitment, and the amino acids are kept track of by updating a stack of amino acid grids whenever a critter is born/dies. The probability of a birth in an empty site is determined by amount of amino acid that reaches that site.   
	 */
	public void step1AAUpdate()
	{
		checkForInoculations();
		/*
		 * if(this.timeStep == 1) for (int row = 0; row < this.gridLength; row++) { for (int col = 0; col < this.gridLength; col++) { System.out.print(this.AAGrid[row][col][0] + "  ");
		 * 
		 * } System.out.println(""); }
		 */
		// System.out.println("starting main step loop");
		ArrayList<Location> toRemoveLocation = new ArrayList<Location>();
		ArrayList<Species> toRemoveCritter = new ArrayList<Species>();

		ArrayList<Location> toAddLocation = new ArrayList<Location>();
		ArrayList<Species> toAddCritter = new ArrayList<Species>();

		// go throught the rows and columns
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				// if it's occupied, pull a random number to see if it dies
				int gridValue = this.env.getGridValue(row, col);
				if (gridValue != 0)
				{

					double deathProb = this.speciesList.get(gridValue - 1).getD();
					if (this.generator.nextDouble() < deathProb)
					{
						// index it to remove at the end of the time step
						toRemoveLocation.add(new Location(row, col));
						toRemoveCritter.add(this.speciesList.get(gridValue - 1));
					}
					// if it does die, go to the next row,col location
					continue;
				}
				else
				// if it's empty, enter birth process
				{

					double[] birthProbs = new double[this.numberOfSpecies];
					double AA1Avail = this.AAGrid[row][col][0];
					double AA2Avail = this.AAGrid[row][col][1];
					double AA3Avail = this.AAGrid[row][col][2];

					// System.out.println(counter);
					// System.out.println(AACounts[0]);

					// for each critter determine the term of the birth probability that follows leibigs law of the minimum with respect to AA.
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						Species currentSpecies = this.speciesList.get(spp);
						double tempF = 1;
						if (!currentSpecies.makesAA1())
						{
							if (AA1Avail / currentSpecies.getAA1K() < tempF)
							{
								tempF = AA1Avail / currentSpecies.getAA1K();
							}
						}

						if (!currentSpecies.makesAA2())
						{
							if (AA2Avail / currentSpecies.getAA2K() < tempF)
							{
								tempF = AA2Avail / currentSpecies.getAA2K();
							}
						}

						if (!currentSpecies.makesAA3())
						{
							if (AA3Avail / currentSpecies.getAA3K() < tempF)
							{
								tempF = AA3Avail / currentSpecies.getAA3K();
							}
						}

						// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
						// are around to give birth
						birthProbs[spp] = currentSpecies.getCmax() * tempF * (this.critterCountGrid[row][col][spp] / (double) this.possibleAANeighbors);

					}

					// figure out which bacterium (if any) is going to give birth
					double theBirthProb = this.generator.nextDouble();
					double compareTo = 0;
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						compareTo += birthProbs[spp];

						if (theBirthProb < compareTo)
						{
							toAddCritter.add(this.speciesList.get(spp));
							toAddLocation.add(new Location(row, col));
							// this.env.add(new Location(row, col), this.speciesList.get(spp).getGridProxy());
							break;
						}

					}
				}
			}

		}

		// Exception thrower if critters and location get unsynchronized
		/*
		 * if (toAddLocation.size() != toAddCritter.size()) { IllegalStateException e = new IllegalStateException("critters and locations are unsynchronized"); throw e; }
		 */
		for (int i = 0; i < toRemoveLocation.size(); i++)
		{
			Location loc = toRemoveLocation.get(i);
			Species tempSpecies = toRemoveCritter.get(i);
			this.env.remove(loc.row(), loc.col());
			subtractAAStep1(loc.row(), loc.col(), tempSpecies);
		}
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location loc = toAddLocation.get(i);
			Species tempSpecies = toAddCritter.get(i);
			this.env.add(loc, tempSpecies.getGridProxy());
			addAAStep1(loc.row(), loc.col(), tempSpecies);
		}
		this.timeStep++;
	}

	/**
	 * 
	 * Execute one time step where amino acid availibility affects fecundity, and the amino acids are kept track of by updating a stack of amino acid grids whenever a critter is born/dies.
	 *  The probability of a birth in an empty site is determined by amount of amino acid that reaches that site.   
	 */
	public void step2AAMovingWindowCGRBland()
	{
		for (int r = 0; r < this.gridLength; r++)
		{
			for (int c = 0; c < this.gridLength; c++)
			{
				for (int s = 0; s < this.numberOfSpecies; s++)
				{
					this.compValuesMat[r][c][s] = 0;
				}
			}
		}

		// this.CGRGrid = new double[this.gridLength][this.gridLength][this.numberOfSpecies];

		// System.out.println("time step " + this.timeStep);
		checkForInoculations();

		// instantiate a stack of grids that gives the competitive values in each location of each species, respectively

		ArrayList<Location> toRemoveLocation = new ArrayList<Location>();

		ArrayList<Location> toAddLocation = new ArrayList<Location>();
		ArrayList<Species> toAddCritter = new ArrayList<Species>();
		fillAAGridStep2();

		// this second main determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				int critterValue = this.env.getGridValue(row, col);
				// if it's occupied, pull a random number to see if it dies
				if (critterValue != 0)
				{
					// if it's empty, enter birth process
					double AA1Avail = this.AAGrid[row][col][0];
					double AA2Avail = this.AAGrid[row][col][1];
					double AA3Avail = this.AAGrid[row][col][2];

					Species currentSpecies = this.speciesList.get(critterValue - 1);
					double tempF = 1;
					if (!currentSpecies.makesAA1())
					{
						if (AA1Avail / currentSpecies.getAA1K() < tempF)
						{
							tempF = AA1Avail / currentSpecies.getAA1K();
						}
					}

					if (!currentSpecies.makesAA2())
					{
						if (AA2Avail / currentSpecies.getAA2K() < tempF)
						{
							tempF = AA2Avail / currentSpecies.getAA2K();
						}
					}

					if (!currentSpecies.makesAA3())
					{
						if (AA3Avail / currentSpecies.getAA3K() < tempF)
						{
							tempF = AA3Avail / currentSpecies.getAA3K();
						}
					}

					// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
					//
					this.compValuesMat[row][col][critterValue - 1] = currentSpecies.getCmax() * tempF;
				}
			}
		}

		// this second main determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				int gridValue = this.env.getGridValue(row, col);
				if (gridValue != 0)
				{

					double deathProb = this.speciesList.get(gridValue - 1).getD();
					if (this.generator.nextDouble() < deathProb)
					{
						// index it to remove at the end of the time step
						toRemoveLocation.add(new Location(row, col));
					}
					// if it does die, go to the next row,col location
					continue;
				}
				else
				// if it's empty, enter birth process
				{
					double[] speciesCompValuesSum = new double[this.numberOfSpecies];
					for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
					{
						for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
						{
							int realRow = WrapAround.wrapAround(row2, this.gridLength);
							int realCol = WrapAround.wrapAround(col2, this.gridLength);
							gridValue = this.env.getGridValue(realRow, realCol);
							if (gridValue != 0)
							{
								/*
								 * for(int s = 0; s < this.numberOfSpecies; s++) {
								 */
								speciesCompValuesSum[gridValue - 1] += this.compValuesMat[realRow][realCol][gridValue - 1];
							}

						}
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						speciesCompValuesSum[s] /= this.possibleNeighbors;
					}
					double theBirthProb = this.generator.nextDouble();
					double compareTo = 0;
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						compareTo += speciesCompValuesSum[spp];

						if (theBirthProb < compareTo)
						{
							toAddCritter.add(this.speciesList.get(spp));
							toAddLocation.add(new Location(row, col));
							break;
						}

					}

				}
			}
		}

		// Exception thrower if critters and location get unsynchronized
		/*
		 * if (toAddLocation.size() != toAddCritter.size()) { IllegalStateException e = new IllegalStateException("critters and locations are unsynchronized"); throw e; }
		 */

		// deaths
		for (int i = 0; i < toRemoveLocation.size(); i++)
		{
			Location loc = toRemoveLocation.get(i);
			this.env.remove(loc.row(), loc.col());

		}
		// births
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location loc = toAddLocation.get(i);
			Species tempSpecies = toAddCritter.get(i);
			this.env.add(loc, tempSpecies.getGridProxy());
			// add amino acids
			// update the growth rates in the surrounding area (within AADispersalRadius neighborhood)
			// update the cumulative growth rates in the dispersalDistanceNeighborhood of every site within AADispersalRadius(potential for moving window)
		}
		/*
		 * for (int i = 0; i < toRemoveLocation.size(); i++) { Location loc = toRemoveLocation.get(i); updateGrowthRates(loc.row(), loc.col()); } for (int i = 0; i < toAddLocation.size(); i++) { Location loc = toAddLocation.get(i); updateGrowthRates(loc.row(), loc.col()); }
		 * 
		 * for (int i = 0; i < toRemoveLocation.size(); i++) { Location loc = toRemoveLocation.get(i); updateCumulativeGrowthRates(loc.row(), loc.col()); } for (int i = 0; i < toAddLocation.size(); i++) { Location loc = toAddLocation.get(i); updateCumulativeGrowthRates(loc.row(), loc.col()); }
		 */

		this.timeStep++;
	}

	/**
	 * 
	 * Execute one time step where amino acid availibility affects fecundity. Amino acids are kept track of with a moving window algorithm. So are cumulative growth rates (which determine the probability of progeny being recruited in an empty site).
	 *  The probability of a birth in an empty site is determined by amount of amino acid that reaches that site.   
	 */
	public void step2AAMovingWindowCGRMovingWindow()
	{

		for (int r = 0; r < this.gridLength; r++)
		{
			for (int c = 0; c < this.gridLength; c++)
			{
				for (int a = 0; a < this.numberOfSpecies; a++)
				{
					this.compValuesMat[r][c][a] = 0;
				}
			}

		}
		// this.CGRGrid = new double[this.gridLength][this.gridLength][this.numberOfSpecies];

		// System.out.println("time step " + this.timeStep);
		checkForInoculations();

		// instantiate a stack of grids that gives the competitive values in each location of each species, respectively

		ArrayList<Location> toRemoveLocation = new ArrayList<Location>();

		ArrayList<Location> toAddLocation = new ArrayList<Location>();
		ArrayList<Species> toAddCritter = new ArrayList<Species>();

		// this second main determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius
		fillAAGridStep2();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				// if it's occupied, pull a random number to see if it dies
				int gridValue = this.env.getGridValue(row, col);
				if (gridValue != 0)
				{

					// if it's empty, enter birth process
					double AA1Avail = this.AAGrid[row][col][0];
					double AA2Avail = this.AAGrid[row][col][1];
					double AA3Avail = this.AAGrid[row][col][2];

					Species currentSpecies = this.speciesList.get(gridValue - 1);
					double tempF = 1;
					if (!currentSpecies.makesAA1())
					{
						if (AA1Avail / currentSpecies.getAA1K() < tempF)
						{
							tempF = AA1Avail / currentSpecies.getAA1K();
						}
					}

					if (!currentSpecies.makesAA2())
					{
						if (AA2Avail / currentSpecies.getAA2K() < tempF)
						{
							tempF = AA2Avail / currentSpecies.getAA2K();
						}
					}

					if (!currentSpecies.makesAA3())
					{
						if (AA3Avail / currentSpecies.getAA3K() < tempF)
						{
							tempF = AA3Avail / currentSpecies.getAA3K();
						}
					}

					// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
					//
					this.compValuesMat[row][col][gridValue - 1] = currentSpecies.getCmax() * tempF;

				}
			}
		}
		// this records the cumulative growth rates of species wihin the dispersal radius. I
		this.posCGR = new double[this.numberOfSpecies][this.gridLength][3];

		// this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius
		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. These values are stored in the pos array.
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid location, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPold - TOPold.leftMost + TOPnew.rightmost. BOTnew can be written BOTold - BOTold.leftMost + BOTnew.rightmost.
		// In actuality, the algorithm is more complex because there are different subroutines that depend on your grid position. When both the row and the column are 0
		// (i.e. the first microsite you investigate, you have to go ahead and find the values of every neighbor, and then store these in the pos array. When the row is is still zero but you've gotten
		// past the first cell, the new top can be rexpressed as TOPold - TOPold.leftMost + TOPnew.rightmost. Same with the bottom. For the MID, you essentialy do the same thing, except the righmost and
		// lestmost values are sums over multiple rows. If you've gotten past the first row but the column is zero, then you have to caculate a new top and bottom. If you're in the meat
		// of the grid, follow the basic procedure outlined in the beginning of this description.
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				// the first loop is the most costly, each TOP, MID, and BOT is caclulated independently.
				if (row == 0 && col == 0)
				{
					// pos = new double[this.numberOfSpecies][this.gridLength][3];
					int row2 = row - this.dispersalRadius;
					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							this.posCGR[gridValue - 1][col][0] += this.compValuesMat[realRow][realCol][gridValue - 1];

						}
					}
					// System.out.println("col == " + col + " first is " + first[1]);

					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						for (row2 = row - this.dispersalRadius + 1; row2 <= row + this.dispersalRadius - 1; row2++)
						{
							int realRow = WrapAround.wrapAround(row2, this.gridLength);
							int realCol = WrapAround.wrapAround(col2, this.gridLength);
							int gridValue = this.env.getGridValue(realRow, realCol);
							if (gridValue != 0)
							{

								this.posCGR[gridValue - 1][col][1] += this.compValuesMat[realRow][realCol][gridValue - 1];

							}
						}
					}
					// System.out.println("col == 0 middle is " + middle[1]);

					row2 = row + this.dispersalRadius;
					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							this.posCGR[gridValue - 1][col][2] += this.compValuesMat[realRow][realCol][gridValue - 1];

						}
					}

				}
				else if (row == 0)
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength);
					int NERow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength);
					int NECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);

					int SWRow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength);
					int SERow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength);
					int SECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][0] = this.posCGR[s][col - 1][0] - this.compValuesMat[NWRow][NWCol][s] + this.compValuesMat[NERow][NECol][s];
					}

					double[] leftSideOfOldMid = new double[this.numberOfSpecies];
					int col2 = col - this.dispersalRadius - 1;
					for (int row2 = row - this.dispersalRadius + 1; row2 <= row + this.dispersalRadius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							leftSideOfOldMid[gridValue - 1] += this.compValuesMat[realRow][realCol][gridValue - 1];

						}
					}

					double[] rightSideOfNewMid = new double[this.numberOfSpecies];
					col2 = col + this.dispersalRadius;
					for (int row2 = row - this.dispersalRadius + 1; row2 <= row + this.dispersalRadius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							rightSideOfNewMid[gridValue - 1] += this.compValuesMat[realRow][realCol][gridValue - 1];

						}
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][1] = this.posCGR[s][col - 1][1] - leftSideOfOldMid[s] + rightSideOfNewMid[s];
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][2] = this.posCGR[s][col - 1][2] - this.compValuesMat[SWRow][SWCol][s] + this.compValuesMat[SERow][SECol][s];
					}
				}
				// if we're on a new row, but not the first row, the TOPnew and BOTnew must be calculated independently
				else if (col == 0)
				{

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][0] = 0;
					}
					int row2 = row - this.dispersalRadius;
					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							this.posCGR[gridValue - 1][col][0] += this.compValuesMat[realRow][realCol][gridValue - 1];

						}
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][1] += this.posCGR[s][col][2] - this.posCGR[s][col][0];
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][2] = 0;
					}
					row2 = row + this.dispersalRadius;
					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							this.posCGR[gridValue - 1][col][2] += this.compValuesMat[realRow][realCol][gridValue - 1];

						}
					}

				}
				else
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength);
					int NERow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength);
					int NECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);

					int SWRow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength);
					int SERow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength);
					int SECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][0] = this.posCGR[s][col - 1][0] - this.compValuesMat[NWRow][NWCol][s] + this.compValuesMat[NERow][NECol][s];
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][1] += this.posCGR[s][col][2] - this.posCGR[s][col][0];
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][2] = this.posCGR[s][col - 1][2] - this.compValuesMat[SWRow][SWCol][s] + this.compValuesMat[SERow][SECol][s];
					}

				}

				/*
				 * // if it's occupied, pull a random number to see if it dies for (int s = 0; s < this.numberOfSpecies; s++) { this.CGRGrid[row][col][s] =(this.posCGR[s][col][0] + this.posCGR[s][col][1] + this.posCGR[s][col][2]) / (double) this.possibleNeighbors; }
				 */

				// if it's occupied, pull a random number to see if it dies
				int gridValue = this.env.getGridValue(row, col);
				if (gridValue != 0)
				{

					double deathProb = this.speciesList.get(gridValue - 1).getD();
					if (this.generator.nextDouble() < deathProb)
					{
						// index it to remove at the end of the time step
						toRemoveLocation.add(new Location(row, col));
					}
					// if it does die, go to the next row,col location
				}
				else
				{
					double[] speciesCompValuesSum = new double[this.numberOfSpecies];
					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						speciesCompValuesSum[s] = (this.posCGR[s][col][0] + this.posCGR[s][col][1] + this.posCGR[s][col][2]) / (double) this.possibleNeighbors;
					}

					double theBirthProb = this.generator.nextDouble();
					double compareTo = 0;
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						compareTo += speciesCompValuesSum[spp];

						if (theBirthProb < compareTo)
						{
							toAddCritter.add(this.speciesList.get(spp));
							toAddLocation.add(new Location(row, col));
							break;
						}
					}
				}
			}
		}

		// Exception thrower if critters and location get unsynchronized
		/*
		 * if (toAddLocation.size() != toAddCritter.size()) { IllegalStateException e = new IllegalStateException("critters and locations are unsynchronized"); throw e; }
		 */

		/*
		 * double[][][] testCGRGrid = CGRGridTest(); if (!this.CGRGrid.equals(testCGRGrid)) {if(true) { //System.out.println("step2AAMovingWindowCGRMovingWindow is deficient. The AA Moving window doesn't work"); for (int row3 = 0; row3 < this.gridLength; row3++) { for (int col3 = 0; col3 < this.gridLength; col3++) {
		 * 
		 * if (this.CGRGrid[row3][col3][0] != testCGRGrid[row3][col3][0]) { System.out.println("failure at row3 " + row3 + " and col3 " + col3); System.out.println("real CGR Grid at " + row3 + " " + col3 + " is " + this.CGRGrid[row3][col3][0]); System.out.println("test CGR Grid at " + row3 + " " + col3 + " is " + testCGRGrid[row3][col3][0]); System.out.println(""); }
		 * 
		 * } } }
		 */
		// deaths
		for (int i = 0; i < toRemoveLocation.size(); i++)
		{
			Location loc = toRemoveLocation.get(i);
			this.env.remove(loc.row(), loc.col());

		}
		// births
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location loc = toAddLocation.get(i);
			Species tempSpecies = toAddCritter.get(i);
			this.env.add(loc, tempSpecies.getGridProxy());
			// add amino acids
			// update the growth rates in the surrounding area (within AADispersalRadius neighborhood)
			// update the cumulative growth rates in the dispersalDistanceNeighborhood of every site within AADispersalRadius(potential for moving window)
		}
		/*
		 * fillAAGridStep2(); testAAGrid2 = AAGridTest(); if (!this.AAGrid.equals(testAAGrid)) { System.out.println("step2AAMovingWindowCGRMovingWindow is deficient. The AA Moving window doesn't work"); for (int row = 0; row < this.gridLength; row++) { for (int col = 0; col < this.gridLength; col++) {
		 * 
		 * if (this.AAGrid[row][col][0] != testAAGrid[row][col][0]) { System.out.println("failure at row " + row + " and col " + col); System.out.println("real AA Grid mid step at " + row + " " + col + " is " + testAAGrid[row][col][0]); System.out.println("test AA Grid mid step at " + row + " " + col + " is " + testAAGrid2[row][col][0]); System.out.println(""); }
		 * 
		 * } } }
		 */
		/*
		 * for (int i = 0; i < toRemoveLocation.size(); i++) { Location loc = toRemoveLocation.get(i); updateGrowthRates(loc.row(), loc.col()); } for (int i = 0; i < toAddLocation.size(); i++) { Location loc = toAddLocation.get(i); updateGrowthRates(loc.row(), loc.col()); }
		 * 
		 * for (int i = 0; i < toRemoveLocation.size(); i++) { Location loc = toRemoveLocation.get(i); updateCumulativeGrowthRates(loc.row(), loc.col()); } for (int i = 0; i < toAddLocation.size(); i++) { Location loc = toAddLocation.get(i); updateCumulativeGrowthRates(loc.row(), loc.col()); }
		 */

		this.timeStep++;
	}

	/**
	 * 
	 * Execute one time step where amino acid availibility affects fecundity. Amino acids are kept track of with a moving window algorithm. 
	 * 
	 */
	public void step2AAUpdateCGRBland()
	{
		for (int r = 0; r < this.gridLength; r++)
		{
			for (int c = 0; c < this.gridLength; c++)
			{
				for (int a = 0; a < this.numberOfSpecies; a++)
				{
					this.compValuesMat[r][c][a] = 0;
				}
			}

		}
		// System.out.println("time step " + this.timeStep);
		checkForInoculations();

		// instantiate a stack of grids that gives the competitive values in each location of each species, respectively

		ArrayList<Location> toRemoveLocation = new ArrayList<Location>();
		ArrayList<Species> toRemoveCritter = new ArrayList<Species>();

		ArrayList<Location> toAddLocation = new ArrayList<Location>();
		ArrayList<Species> toAddCritter = new ArrayList<Species>();

		// this second main determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				int critterValue = this.env.getGridValue(row, col);
				// if it's occupied, pull a random number to see if it dies
				if (critterValue != 0)
				{
					// if it's empty, enter birth process
					double AA1Avail = this.AAGrid[row][col][0];
					double AA2Avail = this.AAGrid[row][col][1];
					double AA3Avail = this.AAGrid[row][col][2];

					Species currentSpecies = this.speciesList.get(critterValue - 1);
					double tempF = 1;
					if (!currentSpecies.makesAA1())
					{
						if (AA1Avail / currentSpecies.getAA1K() < tempF)
						{
							tempF = AA1Avail / currentSpecies.getAA1K();
						}
					}

					if (!currentSpecies.makesAA2())
					{
						if (AA2Avail / currentSpecies.getAA2K() < tempF)
						{
							tempF = AA2Avail / currentSpecies.getAA2K();
						}
					}

					if (!currentSpecies.makesAA3())
					{
						if (AA3Avail / currentSpecies.getAA3K() < tempF)
						{
							tempF = AA3Avail / currentSpecies.getAA3K();
						}
					}

					// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
					//
					this.compValuesMat[row][col][critterValue - 1] = currentSpecies.getCmax() * tempF;
				}
			}
		}

		// this second main determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				int gridValue = this.env.getGridValue(row, col);
				if (gridValue != 0)
				{

					double deathProb = this.speciesList.get(gridValue - 1).getD();
					if (this.generator.nextDouble() < deathProb)
					{
						// index it to remove at the end of the time step
						toRemoveCritter.add(this.speciesList.get(gridValue - 1));
						toRemoveLocation.add(new Location(row, col));
					}
					// if it does die, go to the next row,col location
					continue;
				}
				else
				// if it's empty, enter birth process
				{
					double[] speciesCompValuesSum = new double[this.numberOfSpecies];
					for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
					{
						for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
						{
							int realRow = WrapAround.wrapAround(row2, this.gridLength);
							int realCol = WrapAround.wrapAround(col2, this.gridLength);
							gridValue = this.env.getGridValue(realRow, realCol);
							if (gridValue != 0)
							{
								/*
								 * for(int s = 0; s < this.numberOfSpecies; s++) {
								 */
								speciesCompValuesSum[gridValue - 1] += this.compValuesMat[realRow][realCol][gridValue - 1];
							}

						}
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						speciesCompValuesSum[s] /= this.possibleNeighbors;
					}
					double theBirthProb = this.generator.nextDouble();
					double compareTo = 0;
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						compareTo += speciesCompValuesSum[spp];

						if (theBirthProb < compareTo)
						{
							toAddCritter.add(this.speciesList.get(spp));
							toAddLocation.add(new Location(row, col));
							break;
						}

					}

				}
			}
		}

		// Exception thrower if critters and location get unsynchronized
		/*
		 * if (toAddLocation.size() != toAddCritter.size()) { IllegalStateException e = new IllegalStateException("critters and locations are unsynchronized"); throw e; }
		 */

		// deaths
		for (int i = 0; i < toRemoveLocation.size(); i++)
		{
			Location loc = toRemoveLocation.get(i);
			this.env.remove(loc.row(), loc.col());
			subtractAAStep2(loc.row(), loc.col(), toRemoveCritter.get(i));

		}
		// births
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location loc = toAddLocation.get(i);
			Species tempSpecies = toAddCritter.get(i);
			this.env.add(loc, tempSpecies.getGridProxy());
			addAAStep2(loc.row(), loc.col(), tempSpecies);
			// add amino acids
			// update the growth rates in the surrounding area (within AADispersalRadius neighborhood)
			// update the cumulative growth rates in the dispersalDistanceNeighborhood of every site within AADispersalRadius(potential for moving window)
		}
		/*
		 * for (int i = 0; i < toRemoveLocation.size(); i++) { Location loc = toRemoveLocation.get(i); updateGrowthRates(loc.row(), loc.col()); } for (int i = 0; i < toAddLocation.size(); i++) { Location loc = toAddLocation.get(i); updateGrowthRates(loc.row(), loc.col()); }
		 * 
		 * for (int i = 0; i < toRemoveLocation.size(); i++) { Location loc = toRemoveLocation.get(i); updateCumulativeGrowthRates(loc.row(), loc.col()); } for (int i = 0; i < toAddLocation.size(); i++) { Location loc = toAddLocation.get(i); updateCumulativeGrowthRates(loc.row(), loc.col()); }
		 */

		this.timeStep++;
	}

	/**
	 * 
	 * Execute one time step where amino acid availibility affects fecundity. Amino acids are kept track of by updating a stack of amino acid grids whenever a critter is born/dies.
	 *  The probability of a birth in an empty site is determined by amount of amino acid that reaches that site.   
	 *
	 */
	public void step2AAUpdateCGRMovingWindow()
	{

		for (int r = 0; r < this.gridLength; r++)
		{
			for (int c = 0; c < this.gridLength; c++)
			{
				for (int a = 0; a < this.numberOfSpecies; a++)
				{
					this.compValuesMat[r][c][a] = 0;
				}
			}

		}

		// this.CGRGrid = new double[this.gridLength][this.gridLength][this.numberOfSpecies];

		// System.out.println("time step " + this.timeStep);
		checkForInoculations();

		// fillAAGridStep2();
		// instantiate a stack of grids that gives the competitive values in each location of each species, respectively

		ArrayList<Location> toRemoveLocation = new ArrayList<Location>();
		ArrayList<Species> toRemoveCritter = new ArrayList<Species>();

		ArrayList<Location> toAddLocation = new ArrayList<Location>();
		ArrayList<Species> toAddCritter = new ArrayList<Species>();

		// this second main determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				// if it's occupied, pull a random number to see if it dies
				int gridValue = this.env.getGridValue(row, col);
				if (gridValue != 0)
				{

					// if it's empty, enter birth process
					double AA1Avail = this.AAGrid[row][col][0];
					double AA2Avail = this.AAGrid[row][col][1];
					double AA3Avail = this.AAGrid[row][col][2];

					Species currentSpecies = this.speciesList.get(gridValue - 1);
					double tempF = 1;
					if (!currentSpecies.makesAA1())
					{
						if (AA1Avail / currentSpecies.getAA1K() < tempF)
						{
							tempF = AA1Avail / currentSpecies.getAA1K();
						}
					}

					if (!currentSpecies.makesAA2())
					{
						if (AA2Avail / currentSpecies.getAA2K() < tempF)
						{
							tempF = AA2Avail / currentSpecies.getAA2K();
						}
					}

					if (!currentSpecies.makesAA3())
					{
						if (AA3Avail / currentSpecies.getAA3K() < tempF)
						{
							tempF = AA3Avail / currentSpecies.getAA3K();
						}
					}

					// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
					//
					this.compValuesMat[row][col][gridValue - 1] = currentSpecies.getCmax() * tempF;

				}
			}
		}
		// this records the cumulative growth rates of species wihin the dispersal radius. I
		this.posCGR = new double[this.numberOfSpecies][this.gridLength][3];

		// this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius

		// this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm.
		// It works by summing all of the
		// cumulative birth rates in the topmost row, the bottommost row, and everything in between. These values are stored in the pos array.
		// 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid location, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew.
		// (where north indicates the position above you). TOPnew can be written TOPold - TOPold.leftMost + TOPnew.rightmost. BOTnew can be written BOTold - BOTold.leftMost + BOTnew.rightmost.
		// In actuality, the algorithm is more complex because there are different subroutines that depend on your grid position. When both the row and the column are 0
		// (i.e. the first microsite you investigate, you have to go ahead and find the values of every neighbor, and then store these in the pos array. When the row is is still zero but you've gotten
		// past the first cell, the new top can be rexpressed as TOPold - TOPold.leftMost + TOPnew.rightmost. Same with the bottom. For the MID, you essentialy do the same thing, except the righmost and
		// lestmost values are sums over multiple rows. If you've gotten past the first row but the column is zero, then you have to caculate a new top and bottom. If you're in the meat
		// of the grid, follow the basic procedure outlined in the beginning of this description.
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				// the first loop is the most costly, each TOP, MID, and BOT is caclulated independently.
				if (row == 0 && col == 0)
				{
					// pos = new double[this.numberOfSpecies][this.gridLength][3];
					int row2 = row - this.dispersalRadius;
					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							this.posCGR[gridValue - 1][col][0] += this.compValuesMat[realRow][realCol][gridValue - 1];

						}
					}
					// System.out.println("col == " + col + " first is " + first[1]);

					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						for (row2 = row - this.dispersalRadius + 1; row2 <= row + this.dispersalRadius - 1; row2++)
						{
							int realRow = WrapAround.wrapAround(row2, this.gridLength);
							int realCol = WrapAround.wrapAround(col2, this.gridLength);
							int gridValue = this.env.getGridValue(realRow, realCol);
							if (gridValue != 0)
							{

								this.posCGR[gridValue - 1][col][1] += this.compValuesMat[realRow][realCol][gridValue - 1];

							}
						}
					}
					// System.out.println("col == 0 middle is " + middle[1]);

					row2 = row + this.dispersalRadius;
					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							this.posCGR[gridValue - 1][col][2] += this.compValuesMat[realRow][realCol][gridValue - 1];

						}
					}

				}
				else if (row == 0)
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength);
					int NERow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength);
					int NECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);

					int SWRow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength);
					int SERow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength);
					int SECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][0] = this.posCGR[s][col - 1][0] - this.compValuesMat[NWRow][NWCol][s] + this.compValuesMat[NERow][NECol][s];
					}

					double[] leftSideOfOldMid = new double[this.numberOfSpecies];
					int col2 = col - this.dispersalRadius - 1;
					for (int row2 = row - this.dispersalRadius + 1; row2 <= row + this.dispersalRadius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							leftSideOfOldMid[gridValue - 1] += this.compValuesMat[realRow][realCol][gridValue - 1];

						}
					}

					double[] rightSideOfNewMid = new double[this.numberOfSpecies];
					col2 = col + this.dispersalRadius;
					for (int row2 = row - this.dispersalRadius + 1; row2 <= row + this.dispersalRadius - 1; row2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							rightSideOfNewMid[gridValue - 1] += this.compValuesMat[realRow][realCol][gridValue - 1];

						}
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][1] = this.posCGR[s][col - 1][1] - leftSideOfOldMid[s] + rightSideOfNewMid[s];
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][2] = this.posCGR[s][col - 1][2] - this.compValuesMat[SWRow][SWCol][s] + this.compValuesMat[SERow][SECol][s];
					}
				}
				// if we're on a new row, but not the first row, the TOPnew and BOTnew must be calculated independently
				else if (col == 0)
				{

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][0] = 0;
					}
					int row2 = row - this.dispersalRadius;
					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							this.posCGR[gridValue - 1][col][0] += this.compValuesMat[realRow][realCol][gridValue - 1];

						}
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][1] += this.posCGR[s][col][2] - this.posCGR[s][col][0];
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][2] = 0;
					}
					row2 = row + this.dispersalRadius;
					for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
					{
						int realRow = WrapAround.wrapAround(row2, this.gridLength);
						int realCol = WrapAround.wrapAround(col2, this.gridLength);
						int gridValue = this.env.getGridValue(realRow, realCol);
						if (gridValue != 0)
						{

							this.posCGR[gridValue - 1][col][2] += this.compValuesMat[realRow][realCol][gridValue - 1];

						}
					}

				}
				else
				{

					// generate new top
					int NWRow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength);
					int NWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength);
					int NERow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength);
					int NECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);

					int SWRow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength);
					int SWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength);
					int SERow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength);
					int SECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][0] = this.posCGR[s][col - 1][0] - this.compValuesMat[NWRow][NWCol][s] + this.compValuesMat[NERow][NECol][s];
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][1] += this.posCGR[s][col][2] - this.posCGR[s][col][0];
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						this.posCGR[s][col][2] = this.posCGR[s][col - 1][2] - this.compValuesMat[SWRow][SWCol][s] + this.compValuesMat[SERow][SECol][s];
					}

				}

				/*
				 * System.out.println(""); System.out.println(""); System.out.println("");
				 */

				// cgr critical test
				// if it's occupied, pull a random number to see if it dies
				/*
				 * for (int s = 0; s < this.numberOfSpecies; s++) { this.CGRGrid[row][col][s] =(this.posCGR[s][col][0] + this.posCGR[s][col][1] + this.posCGR[s][col][2]) / (double) this.possibleNeighbors; } double[][][] testCGRGrid = CGRGridTest(); if (!this.CGRGrid.equals(testCGRGrid)) {if(true) { System.out.println("step2AAMovingWindowCGRMovingWindow is deficient. The AA Moving window doesn't work"); for (int row3 = 0; row3 < this.gridLength; row3++) { for (int col3 = 0; col3 < this.gridLength; col3++) {
				 * 
				 * if (this.CGRGrid[row3][col3][0] != testCGRGrid[row3][col3][0]) { System.out.println("failure at row3 " + row3 + " and col3 " + col3); System.out.println("real CGR Grid at " + row3 + " " + col3 + " is " + this.CGRGrid[row3][col3][0]); System.out.println("test CGR Grid at " + row3 + " " + col3 + " is " + testCGRGrid[row3][col3][0]); System.out.println(""); }
				 * 
				 * } } }
				 */
				int gridValue = this.env.getGridValue(row, col);
				if (gridValue != 0)
				{

					double deathProb = this.speciesList.get(gridValue - 1).getD();
					if (this.generator.nextDouble() < deathProb)
					{
						// index it to remove at the end of the time step
						toRemoveCritter.add(this.speciesList.get(gridValue - 1));
						toRemoveLocation.add(new Location(row, col));
					}
					// if it does die, go to the next row,col location
				}
				else
				{
					double[] speciesCompValuesSum = new double[this.numberOfSpecies];
					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						speciesCompValuesSum[s] = (this.posCGR[s][col][0] + this.posCGR[s][col][1] + this.posCGR[s][col][2]) / (double) this.possibleNeighbors;
					}

					double theBirthProb = this.generator.nextDouble();
					double compareTo = 0;
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						compareTo += speciesCompValuesSum[spp];

						if (theBirthProb < compareTo)
						{
							toAddCritter.add(this.speciesList.get(spp));
							toAddLocation.add(new Location(row, col));
							break;
						}
					}
				}
			}
		}

		// cgr critical test
		/*
		 * double[][][] testCGRGrid = CGRGridTest(); if(true) { if (!this.CGRGrid.equals(testCGRGrid)) { //System.out.println("step2AAMovingWindowCGRMovingWindow is deficient. The CGR Moving window doesn't work"); for (int row = 0; row < this.gridLength; row++) { for (int col = 0; col < this.gridLength; col++) {
		 * 
		 * if (this.CGRGrid[row][col][1] != testCGRGrid[row][col][1]) { System.out.println("failure at row " + row + " and col " + col); System.out.println("real CGR Grid at " + row + " " + col + " is " + this.CGRGrid[row][col][1]); System.out.println("test CGR Grid at " + row + " " + col + " is " + testCGRGrid[row][col][1]); System.out.println(""); }
		 * 
		 * } } }
		 */
		// Exception thrower if critters and location get unsynchronized
		/*
		 * if (toAddLocation.size() != toAddCritter.size()) { IllegalStateException e = new IllegalStateException("critters and locations are unsynchronized"); throw e; }
		 */

		// deaths
		for (int i = 0; i < toRemoveLocation.size(); i++)
		{
			Location loc = toRemoveLocation.get(i);
			this.env.remove(loc.row(), loc.col());
			subtractAAStep2(loc.row(), loc.col(), toRemoveCritter.get(i));

		}
		// births
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location loc = toAddLocation.get(i);
			Species tempSpecies = toAddCritter.get(i);
			this.env.add(loc, tempSpecies.getGridProxy());
			addAAStep2(loc.row(), loc.col(), tempSpecies);
			// add amino acids
			// update the growth rates in the surrounding area (within AADispersalRadius neighborhood)
			// update the cumulative growth rates in the dispersalDistanceNeighborhood of every site within AADispersalRadius(potential for moving window)
		}

		/*
		 * for (int row = 0; row < gridLength; row++) { for (int col = 0; col < gridLength; col++) { int gridValue = this.env.getGridValue(row, col);
		 * 
		 * if (gridValue == 0) { continue; }
		 * 
		 * int currentName = speciesList.get(gridValue - 1).getSpeciesName();
		 * 
		 * if (currentName == 1) {
		 * 
		 * if (this.timeStep / 500 != 0 && this.timeStep % 500 == 0) {
		 * 
		 * System.out.println("Amino acid 1 after step at syn one's site " + row + " " + col + " at time step " + this.timeStep + " is " + this.AAGrid[row][col][0]); System.out.println("Amino acid 2 after step at syn two's site " + row + " " + col + " at time step " + this.timeStep + " is " + this.AAGrid[row][col][1]); System.out.println(""); } } } }
		 */
		/*
		 * for (int i = 0; i < toRemoveLocation.size(); i++) { Location loc = toRemoveLocation.get(i); updateGrowthRates(loc.row(), loc.col()); } for (int i = 0; i < toAddLocation.size(); i++) { Location loc = toAddLocation.get(i); updateGrowthRates(loc.row(), loc.col()); }
		 * 
		 * for (int i = 0; i < toRemoveLocation.size(); i++) { Location loc = toRemoveLocation.get(i); updateCumulativeGrowthRates(loc.row(), loc.col()); } for (int i = 0; i < toAddLocation.size(); i++) { Location loc = toAddLocation.get(i); updateCumulativeGrowthRates(loc.row(), loc.col()); }
		 */

		this.timeStep++;
	}

	/**
	 * Calls either step1 or step2. The variants of the step1 or step2 methods are for the sake of efficiency. A couple of rules of thumb determine the exact stepping method in the constructor, but optimizeEfficiency() can be called for more certainty.
	 * The useStep2 variable decides which stepping method to use. The useStep2 variable can be set in the constructor or in the methods setToStep1() and setToStep2().
	 * @param numSteps
	 */
	public void stepAndScatter()
	{
		if (this.useStep2)
		{
			if (this.useMovingWindowForCumulativeGrowthRates)
			{
				if (this.useMovingWindowForAACounts)
				{
					step2AAMovingWindowCGRMovingWindow();
					scatter();
				}
				else
				{
					step2AAUpdateCGRMovingWindow();
					scatter();

				}
			}
			else
			{
				if (this.useMovingWindowForAACounts)
				{
					step2AAMovingWindowCGRBland();
					scatter();

				}
				else
				{
					step2AAUpdateCGRBland();
					scatter();

				}
			}
		}
		else
		{
			if (this.useMovingWindowForAACounts)
			{
				step1AAMovingWindow();
				scatter();

			}
			else
			{
				step1AAUpdate();
				scatter();

			}

		}
	}

	/*	*//**
			* 
			* Execute one time step where amino acid availibility affects fecundity. Amino acids are kept track of by updating a stack of amino acid grids whenever a critter is born/dies.
			*  The probability of a birth in an empty site is determined by amount of amino acid that reaches that site.   
			*
			*/
	/*
	 * public void step2AAUpdateCGRMovingWindowa() {
	 * 
	 * for (int r = 0; r < this.gridLength; r++) { for (int c = 0; c < this.gridLength; c++) { for (int a = 0; a < this.numberOfSpecies; a++) { this.compValuesMat[r][c][a] = 0; } }
	 * 
	 * } // System.out.println("time step " + this.timeStep); checkForInoculations();
	 * 
	 * // instantiate a stack of grids that gives the competitive values in each location of each species, respectively
	 * 
	 * ArrayList<Location> toRemoveLocation = new ArrayList<Location>(); ArrayList<Species> toRemoveCritter = new ArrayList<Species>();
	 * 
	 * ArrayList<Location> toAddLocation = new ArrayList<Location>(); ArrayList<Species> toAddCritter = new ArrayList<Species>();
	 * 
	 * // this second main determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius for (int row = 0; row < this.gridLength; row++) { for (int col = 0; col < this.gridLength; col++) { // if it's occupied, pull a random number to see if it dies int gridValue = this.env.getGridValue(row, col); if (gridValue != 0) {
	 * 
	 * // if it's empty, enter birth process double AA1Avail = this.AAGrid[row][col][0]; double AA2Avail = this.AAGrid[row][col][1]; double AA3Avail = this.AAGrid[row][col][2];
	 * 
	 * Species currentSpecies = this.speciesList.get(gridValue - 1); double tempF = 1; if (!currentSpecies.makesAA1()) { if (AA1Avail / currentSpecies.getAA1K() < tempF) { tempF = AA1Avail / currentSpecies.getAA1K(); } }
	 * 
	 * if (!currentSpecies.makesAA2()) { if (AA2Avail / currentSpecies.getAA2K() < tempF) { tempF = AA2Avail / currentSpecies.getAA2K(); } }
	 * 
	 * if (!currentSpecies.makesAA3()) { if (AA3Avail / currentSpecies.getAA3K() < tempF) { tempF = AA3Avail / currentSpecies.getAA3K(); } }
	 * 
	 * // this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors // this.compValuesMat[row][col][gridValue - 1] = currentSpecies.getCmax() * tempF;
	 * 
	 * } } } // this records the cumulative growth rates of species wihin the dispersal radius. I this.posCGR = new double[this.numberOfSpecies][this.gridLength][3];
	 * 
	 * // this second main loop determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius
	 * 
	 * // this algorithm scans right across the grid, goes down one line, scans again, and so on (just like reading). It's time complexity is O(n) (where n is the number of microsites) compared to O(n^2) of a trivial moving window algorithm. // It works by summing all of the // cumulative birth rates in the topmost row, the bottommost row, and everything in between. These values are stored in the pos array. // 0 is TOP, 1 is MID, and 2 is BOT. when you to the next gid location, your cumulative growth rate is TOPnew + MIDnew + BOTnew. MIDnew is simply MIDnorth + BOTnorth - TOPnew. // (where north indicates the position above you). TOPnew can be written TOPold - TOPold.leftMost + TOPnew.rightmost. BOTnew can be written BOTold - BOTold.leftMost + BOTnew.rightmost. // In actuality, the algorithm is more complex because there are different subroutines that depend on your grid position. When both the row and the column are 0 // (i.e. the first microsite you investigate, you have to go ahead
	 * and find the values of every neighbor, and then store these in the pos array. When the row is is still zero but you've gotten // past the first cell, the new top can be rexpressed as TOPold - TOPold.leftMost + TOPnew.rightmost. Same with the bottom. For the MID, you essentialy do the same thing, except the righmost and // lestmost values are sums over multiple rows. If you've gotten past the first row but the column is zero, then you have to caculate a new top and bottom. If you're in the meat // of the grid, follow the basic procedure outlined in the beginning of this description. for (int row = 0; row < this.gridLength; row++) { for (int col = 0; col < this.gridLength; col++) {
	 * 
	 * if(row != 0 && col != 0) {
	 * 
	 * 
	 * // generate new top int NWRow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength); int NWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength); int NERow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength); int NECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);
	 * 
	 * int SWRow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength); int SWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength); int SERow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength); int SECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);
	 * 
	 * for (int s = 0; s < this.numberOfSpecies; s++) { this.posCGR[s][col][0] = this.posCGR[s][col - 1][0] - this.compValuesMat[NWRow][NWCol][s] + this.compValuesMat[NERow][NECol][s]; }
	 * 
	 * for (int s = 0; s < this.numberOfSpecies; s++) { this.posCGR[s][col][1] += this.posCGR[s][col][2] - this.posCGR[s][col][0]; }
	 * 
	 * for (int s = 0; s < this.numberOfSpecies; s++) { this.posCGR[s][col][2] = this.posCGR[s][col - 1][2] - this.compValuesMat[SWRow][SWCol][s] + this.compValuesMat[SERow][SECol][s]; } } else if (row != 0 && col == 0) { for (int s = 0; s < this.numberOfSpecies; s++) { this.posCGR[s][col][0] = 0; } int row2 = row - this.dispersalRadius; for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) {
	 * 
	 * this.posCGR[gridValue - 1][col][0] += this.compValuesMat[realRow][realCol][gridValue - 1];
	 * 
	 * } }
	 * 
	 * for (int s = 0; s < this.numberOfSpecies; s++) { this.posCGR[s][col][1] += this.posCGR[s][col][2] - this.posCGR[s][col][0]; }
	 * 
	 * for (int s = 0; s < this.numberOfSpecies; s++) { this.posCGR[s][col][2] = 0; } row2 = row + this.dispersalRadius; for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) {
	 * 
	 * this.posCGR[gridValue - 1][col][2] += this.compValuesMat[realRow][realCol][gridValue - 1];
	 * 
	 * } }
	 * 
	 * } else if( col != 0 && row == 0) { // generate new top int NWRow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength); int NWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength); int NERow = WrapAround.wrapAround(row - this.dispersalRadius, this.gridLength); int NECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);
	 * 
	 * int SWRow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength); int SWCol = WrapAround.wrapAround(col - 1 - this.dispersalRadius, this.gridLength); int SERow = WrapAround.wrapAround(row + this.dispersalRadius, this.gridLength); int SECol = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);
	 * 
	 * for (int s = 0; s < this.numberOfSpecies; s++) { this.posCGR[s][col][0] = this.posCGR[s][col - 1][0] - this.compValuesMat[NWRow][NWCol][s] + this.compValuesMat[NERow][NECol][s]; }
	 * 
	 * double[] leftSideOfOldMid = new double[this.numberOfSpecies]; int col2 = col - this.dispersalRadius - 1; for (int row2 = row - this.dispersalRadius + 1; row2 <= row + this.dispersalRadius - 1; row2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) {
	 * 
	 * leftSideOfOldMid[gridValue - 1] += this.compValuesMat[realRow][realCol][gridValue - 1];
	 * 
	 * } }
	 * 
	 * double[] rightSideOfNewMid = new double[this.numberOfSpecies]; col2 = col + this.dispersalRadius; for (int row2 = row - this.dispersalRadius + 1; row2 <= row + this.dispersalRadius - 1; row2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) {
	 * 
	 * rightSideOfNewMid[gridValue - 1] += this.compValuesMat[realRow][realCol][gridValue - 1];
	 * 
	 * } }
	 * 
	 * for (int s = 0; s < this.numberOfSpecies; s++) { this.posCGR[s][col][1] = this.posCGR[s][col - 1][1] - leftSideOfOldMid[s] + rightSideOfNewMid[s]; }
	 * 
	 * for (int s = 0; s < this.numberOfSpecies; s++) { this.posCGR[s][col][2] = this.posCGR[s][col - 1][2] - this.compValuesMat[SWRow][SWCol][s] + this.compValuesMat[SERow][SECol][s]; } } else
	 * 
	 * 
	 * // the first loop is the most costly, each TOP, MID, and BOT is caclulated independently. if (row == 0 && col == 0) { // pos = new double[this.numberOfSpecies][this.gridLength][3]; int row2 = row - this.dispersalRadius; for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) {
	 * 
	 * this.posCGR[gridValue - 1][col][0] += this.compValuesMat[realRow][realCol][gridValue - 1];
	 * 
	 * } } // System.out.println("col == " + col + " first is " + first[1]);
	 * 
	 * for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++) { for (row2 = row - this.dispersalRadius + 1; row2 <= row + this.dispersalRadius - 1; row2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) {
	 * 
	 * this.posCGR[gridValue - 1][col][1] += this.compValuesMat[realRow][realCol][gridValue - 1];
	 * 
	 * } } } // System.out.println("col == 0 middle is " + middle[1]);
	 * 
	 * row2 = row + this.dispersalRadius; for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++) { int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) {
	 * 
	 * this.posCGR[gridValue - 1][col][2] += this.compValuesMat[realRow][realCol][gridValue - 1];
	 * 
	 * } }
	 * 
	 * }
	 * 
	 * 
	 * 
	 * System.out.println(""); System.out.println(""); System.out.println("");
	 * 
	 * 
	 * // if it's occupied, pull a random number to see if it dies int gridValue = this.env.getGridValue(row, col); if (gridValue != 0) {
	 * 
	 * double deathProb = this.speciesList.get(gridValue - 1).getD(); if (this.generator.nextDouble() < deathProb) { // index it to remove at the end of the time step toRemoveCritter.add(this.speciesList.get(gridValue - 1)); toRemoveLocation.add(new Location(row, col)); } // if it does die, go to the next row,col location } else { double[] speciesCompValuesSum = new double[this.numberOfSpecies]; for (int s = 0; s < this.numberOfSpecies; s++) { speciesCompValuesSum[s] = (this.posCGR[s][col][0] + this.posCGR[s][col][1] + this.posCGR[s][col][2]) / (double) this.possibleNeighbors; }
	 * 
	 * double theBirthProb = this.generator.nextDouble(); double compareTo = 0; for (int spp = 0; spp < this.numberOfSpecies; spp++) { compareTo += speciesCompValuesSum[spp];
	 * 
	 * if (theBirthProb < compareTo) { toAddCritter.add(this.speciesList.get(spp)); toAddLocation.add(new Location(row, col)); break; } } } } }
	 * 
	 * // Exception thrower if critters and location get unsynchronized
	 * 
	 * if (toAddLocation.size() != toAddCritter.size()) { IllegalStateException e = new IllegalStateException("critters and locations are unsynchronized"); throw e; }
	 * 
	 * 
	 * // deaths for (int i = 0; i < toRemoveLocation.size(); i++) { Location loc = toRemoveLocation.get(i); this.env.remove(loc.row(), loc.col()); subtractAAStep2(loc.row(), loc.col(), toRemoveCritter.get(i));
	 * 
	 * } // births for (int i = 0; i < toAddLocation.size(); i++) { Location loc = toAddLocation.get(i); Species tempSpecies = toAddCritter.get(i); this.env.add(loc, tempSpecies.getGridProxy()); addAAStep2(loc.row(), loc.col(), tempSpecies); // add amino acids // update the growth rates in the surrounding area (within AADispersalRadius neighborhood) // update the cumulative growth rates in the dispersalDistanceNeighborhood of every site within AADispersalRadius(potential for moving window) }
	 * 
	 * for (int i = 0; i < toRemoveLocation.size(); i++) { Location loc = toRemoveLocation.get(i); updateGrowthRates(loc.row(), loc.col()); } for (int i = 0; i < toAddLocation.size(); i++) { Location loc = toAddLocation.get(i); updateGrowthRates(loc.row(), loc.col()); }
	 * 
	 * for (int i = 0; i < toRemoveLocation.size(); i++) { Location loc = toRemoveLocation.get(i); updateCumulativeGrowthRates(loc.row(), loc.col()); } for (int i = 0; i < toAddLocation.size(); i++) { Location loc = toAddLocation.get(i); updateCumulativeGrowthRates(loc.row(), loc.col()); }
	 * 
	 * 
	 * this.timeStep++; }
	 */

	/**
	 * Calls either step1 or step2. The variants of the step1 or step2 methods are for the sake of efficiency. A couple of rules of thumb determine the exact stepping method in the constructor, but optimizeEfficiency() can be called for more certainty.
	 * The useStep2 variable decides which stepping method to use. The useStep2 variable can be set in the constructor or in the methods setToStep1() and setToStep2().
	 * @param numSteps
	 */
	public void stepAndScatter(int numSteps)
	{
		if (this.useStep2)
		{
			if (this.useMovingWindowForCumulativeGrowthRates)
			{
				if (this.useMovingWindowForAACounts)
				{
					for (int i = 0; i < numSteps; i++)
					{
						step2AAMovingWindowCGRMovingWindow();
						scatter();

					}
				}
				else
				{
					for (int i = 0; i < numSteps; i++)
					{
						step2AAUpdateCGRMovingWindow();
						scatter();

					}
				}
			}
			else
			{
				if (this.useMovingWindowForAACounts)
				{
					for (int i = 0; i < numSteps; i++)
					{
						step2AAMovingWindowCGRBland();
						scatter();

					}
				}
				else
				{
					for (int i = 0; i < numSteps; i++)
					{
						step2AAUpdateCGRBland();
						scatter();

					}
				}
			}
		}
		else
		{
			if (this.useMovingWindowForAACounts)
			{
				for (int i = 0; i < numSteps; i++)
				{
					step1AAMovingWindow();
					scatter();

				}
			}
			else
			{
				for (int i = 0; i < numSteps; i++)
				{
					step1AAUpdate();
					scatter();

				}
			}

		}
	}

	/**
	 * used to dynamically update the grid of amino acid availibility a bacteria dies. The sites within the AADispersalRadius of the focal microsite are updated.
	 * Also, updates the critter count grid (shows how many bacteria within the AADispersalRadius are available to give birth.
	 * @param row the row location of the new bacterium
	 * @param col the col location of the new bacterium
	 * @param aSpecies
	 */
	public void subtractAAStep1(int row, int col, Species aSpecies)
	{
		int name = aSpecies.getSpeciesName();
		int gridProxy = aSpecies.getGridProxy();
		switch (name)
		{

		case 0:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 1:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);
					/*
					 * System.out.println("real row is " + realRow); System.out.println("real col is " + realCol);
					 */

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleAANeighbors;
					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 2:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleAANeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 3:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleAANeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 12:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleAANeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 23:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleAANeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 13:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleAANeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 123:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleAANeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;
		}

	}

	/**
	 * used to dynamically update the grid of amino acid availibility when a bacteria dies. The sites within the AADispersalRadius of the focal microsite are updated.
	 * @param row the row location of the new bacterium
	 * @param col the col location of the new bacterium
	 * @param aSpecies
	 */
	public void subtractAAStep2(int row, int col, Species aSpecies)
	{
		int name = aSpecies.getSpeciesName();
		switch (name)
		{

		case 0:

			break;

		case 1:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);
					/*
					 * System.out.println("real row is " + realRow); System.out.println("real col is " + realCol);
					 */
					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleAANeighbors;
				}
			}
			break;

		case 2:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 3:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 12:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 23:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 13:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleAANeighbors;
				}
			}
			break;

		case 123:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleAANeighbors;
				}
			}
			break;
		}

	}

	/**
	 * Generates time series data over a specified number of time steps, at a specified resolution.
	 * 
	 * @param numSteps the time series is recorded over this many time steps
	 * @param measureHowOften abundances are recorded once every this time steps
	 * @return an two dimensional [species][time] array of abundances
	 */
	public double[][] timeSeries(int numSteps, int measureHowOften, boolean reportDensity)
	{

		double[][] abundanceArray = new double[(numSteps / measureHowOften) + 1][this.numberOfSpecies];
		int counter = 0;

		// get abudances at time zero
		double[] currentAbundances = getAbundances(reportDensity);
		for (int i = 0; i < currentAbundances.length; i++)
		{
			abundanceArray[counter][i] = currentAbundances[i];
		}
		counter++;

		for (int s = 1; s < numSteps + 1; s++)
		{

			step();
			// scatter();

			// get abundances every so often
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = getAbundances(reportDensity);
				// System.out.println("the time step is:" + s);

				for (int i = 0; i < currentAbundances.length; i++)
				{
					abundanceArray[counter][i] = currentAbundances[i];
				}
				counter++;
			}
		}
		return abundanceArray;
	}

	/*
	 * // try a mving window later public void updateCumulativeGrowthRates(int row, int col) {
	 * 
	 * for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++) { for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++) { int realRow2 = WrapAround.wrapAround(row2, this.gridLength); int realCol2 = WrapAround.wrapAround(col2, this.gridLength); for (int s = 0; s < this.numberOfSpecies; s++) { this.cumulativeGrowthRateGrid[realRow2][realCol2][s] = 0; }
	 * 
	 * for (int row3 = realRow2 - this.dispersalRadius; row3 < realRow2 + 1 + this.dispersalRadius; row3++) { for (int col3 = realCol2 - this.dispersalRadius; col3 < realCol2 + 1 + this.dispersalRadius; col3++) { int realRow3 = WrapAround.wrapAround(row3, this.gridLength); int realCol3 = WrapAround.wrapAround(col3, this.gridLength); for (int s = 0; s < this.numberOfSpecies; s++) { this.cumulativeGrowthRateGrid[realRow2][realCol2][s] += this.growthRateGrid[realRow3][realCol3][s]; } } } } } }
	 * 
	 * public void updateGrowthRates(int row, int col) { for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++) { for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++) {
	 * 
	 * int realRow = WrapAround.wrapAround(row2, this.gridLength); int realCol = WrapAround.wrapAround(col2, this.gridLength); for (int s = 0; s < this.numberOfSpecies; s++) { this.growthRateGrid[realRow][realCol][s] = 0; } int gridValue = this.env.getGridValue(realRow, realCol); if (gridValue != 0) { this.growthRateGrid[realRow][realCol][gridValue - 1] = getResourceLimitation(realRow, realCol) * this.speciesList.get(gridValue - 1).getCmax(); }
	 * 
	 * } } }
	 */

	/**
	 * Generates time series data over a specified number of time steps, at a specified resolution.
	 * 
	 * @param numSteps the time series is recorded over this many time steps
	 * @param measureHowOften abundances are recorded once every this time steps
	 * @return an two dimensional [species][time] array of abundances
	 */
	public double[][] timeSeries(int start, int end, int measureHowOften, boolean reportDensity)
	{
		int numSteps = end - start;
		double[][] abundanceArray = new double[(numSteps / measureHowOften) + 1][this.numberOfSpecies];
		int counter = 0;
		int s = 1;
		for (; s <= start; s++)
		{
			step();
		}

		double[] currentAbundances = getAbundances(reportDensity);

		for (int i = 0; i < currentAbundances.length; i++)
		{
			abundanceArray[counter][i] = currentAbundances[i];
		}
		counter++;

		for (; s <= end; s++)
		{
			step();
			// scatter();
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = getAbundances(reportDensity);
				for (int i = 0; i < currentAbundances.length; i++)
				{
					abundanceArray[counter][i] = currentAbundances[i];
				}
				counter++;
			}
		}
		return abundanceArray;
	}

}
