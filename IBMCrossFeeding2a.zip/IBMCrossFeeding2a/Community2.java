import java.io.IOException;
import java.util.ArrayList;
//import java.util.LinkedList;
//import java.util.ListIterator;
//import java.util.List;
import java.util.Random;

/**
 * @author Evan
 * This is where simulations are exacted and data is extracted. A Community has three main things: 1) An environment with information about what type of critters are where.
 * 2) a species list with species-specific parameters (e.g. maximum birth rate) 3) instance variables that are called in the time step function
 * 
 * @date 8/18/2016
 */
/**
 * @author Evan
 *
 */
/**
 * @author Evan
 *
 */
/**
 * @author Evan
 *
 */
public class Community2
{
	// Species s123, Species s12, Species s13, Species s23, Species s1, Species s2, Species s3, Species s0
	protected ArrayList<Species> speciesList;
	protected Environment env;
	protected int numberOfSpecies;
	// protected double[][] compMatrix;
	protected int gridLength;
	private double dt;
	protected Random generator;
	protected int timeStep;
	protected int dispersalRadius;
	protected double KAAProduced;
	protected int AADispersalRadius;
	protected boolean neverInoculate;
	protected int possibleNeighbors;
	protected int inoculateCounter;
	protected boolean useStep2;
	protected int possibleAANeighbors;
	protected double[][][] AAGrid;
	protected int[][][] critterCountGrid;
	protected double[][][] growthRateGrid;
	protected double[][][] cumulativeGrowthRateGrid;
	protected double KAAProducedOverPossibleNeighbors;
	protected double KAAProducedOverPossibleAANeighbors;

	/**
	 * boogahdahboo
	 */
	protected int totalSites;

	/**
	 *  takes a community object and constructs an identical communiy object, can be seen as a safe and easy alternative to clone()
	 * 
	 * @param community a Community to be copied
	 */
	public Community2(Community2 community)
	{
		this.generator = community.generator;
		this.dt = community.dt;
		this.timeStep = community.timeStep;
		this.env = community.env;
		this.gridLength = community.gridLength;
		this.totalSites = community.totalSites;
		this.numberOfSpecies = community.numberOfSpecies;
		this.dispersalRadius = community.dispersalRadius;
		this.AADispersalRadius = community.AADispersalRadius;
		this.neverInoculate = community.neverInoculate;
		this.useStep2 = community.useStep2;
		this.KAAProduced = community.KAAProduced;
		this.possibleNeighbors = community.possibleNeighbors;
		this.possibleAANeighbors = community.possibleAANeighbors;
		this.AAGrid = community.AAGrid;
		this.critterCountGrid = community.critterCountGrid;
		this.growthRateGrid = community.growthRateGrid;
		this.cumulativeGrowthRateGrid = community.cumulativeGrowthRateGrid;
		this.speciesList = community.speciesList;
		this.KAAProducedOverPossibleNeighbors = community.KAAProducedOverPossibleNeighbors;
		this.KAAProducedOverPossibleAANeighbors = community.KAAProducedOverPossibleAANeighbors;
	}

	/**
	 * Sets up a community. Simulation and data grabbing methods will do work on the community
	 * 
	 * @param gridLength the length the square grid environment
	 * @param dt TODO
	 * @param dispersalRadius the "radius" of a square neighborhood within which propagules can be dispersed. Examples: A value of 1 denotes a 3x3 neighboorhood, A value of 2 denotes a 5x5 neighborhood.
	 * @param AADispersalRadius the "radius" of a square neighborhood within which amino acids can be utilized. This parameter is only used in the step2 function
	 * @param KAAProduced the quantity of amino acid that is produced (per type of amino acid) by a single individual. These are distributed evenly between all the neighbors within the dispersalRadius (for step1) or AADispersalRadius (for step2). 
	 * @param useStep2 if false, amino acid availibility affects recruitment. if true, amino acid availibity affects the birth rate of adults.
	 * @param speciesList a list of species objects. A species list can be created with the static [MakeSpeciesList.makeSpeciesList(...)], or with the alternative community constructor
	 */
	public Community2(int gridLength, double dt, int dispersalRadius, int AADispersalRadius, double KAAProduced, boolean useStep2, ArrayList<Species> speciesList)
	{
		// assign instance variables
		this.dt = dt;
		this.generator = new Random();
		this.timeStep = 0;
		this.env = new Environment(gridLength);
		this.gridLength = gridLength;
		this.totalSites = this.gridLength * this.gridLength;
		this.speciesList = speciesList;
		this.numberOfSpecies = speciesList.size();
		this.dispersalRadius = dispersalRadius;
		this.AADispersalRadius = AADispersalRadius;
		this.neverInoculate = false;
		this.useStep2 = useStep2;
		this.KAAProduced = KAAProduced;
		int dispersalLength = 1 + this.dispersalRadius * 2;
		this.possibleNeighbors = dispersalLength * dispersalLength - 1;
		int AADispersalLength = 1 + this.AADispersalRadius * 2;
		this.possibleAANeighbors = AADispersalLength * AADispersalLength - 1;
		this.AAGrid = new double[this.gridLength][this.gridLength][3];
		this.critterCountGrid = new int[this.gridLength][this.gridLength][this.numberOfSpecies];
		this.growthRateGrid = new double[this.gridLength][this.gridLength][this.numberOfSpecies];
		this.cumulativeGrowthRateGrid = new double[this.gridLength][this.gridLength][this.numberOfSpecies];
		this.KAAProducedOverPossibleNeighbors = this.KAAProduced / (double) this.possibleNeighbors;
		this.KAAProducedOverPossibleAANeighbors = this.KAAProduced / (double) this.possibleAANeighbors;

		// sets up the numbers that appear end up on the grid
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			this.speciesList.get(i).setGridProxy(i + 1);
		}

		// if none of the species in the species list makes AA3, make it so none of the species need any AA3
		for (int i = 0; i < numberOfSpecies; i++)
		{
			if (speciesList.get(i).makesAA3())
			{
				break;
			}
			if (i == numberOfSpecies - 1)
			{
				noAA3();
			}

		}

		// randomly adds the specified(in Species class) number of inidividuals to the grid
		/*
		 * for (int s = 0; s < this.numberOfSpecies; s++) { Species curSpecies = this.speciesList.get(s); int val = curSpecies.getGridProxy();
		 * 
		 * // if there's a quantitative cheater, don't inoculate // if (val == 1 && (curSpecies.getAA1K() == 0 || curSpecies.getAA2K() == 0)) // { // continue; // }
		 * 
		 * if (curSpecies.getInoculateWhen() == 0) { int init = curSpecies.getInitialAbundance(); int i = 0; while (i < init) {
		 * 
		 * int row = generator.nextInt(this.env.getGridLength()); int col = generator.nextInt(this.env.getGridLength()); if (this.env.isEmpty(row, col)) { this.env.add(row, col, val); i++; } } } }
		 */
	}

	/**
	 * Sets up a community. Simulation and data grabbing methods will do work on the community.
	 * 
	 * @param gridLength the length the square grid environment.
	 * @param dispersalRadius the "radius" of a square neighborhood within which propagules can be dispersed. Examples: A value of 1 denotes a 3x3 neighboorhood, A value of 2 denotes a 5x5 neighborhood.
	 * @param AADispersalRadius the "radius" of a square neighborhood within which amino acids can be utilized. This parameter is only used in the step2 function.
	 * @param KAAProduced the quantity of amino acid that is produced (per type of amino acid) by a single individuals. These are distributed evenly between all the neighbors within the dispersalRadius (for step1) or AADispersalRadius (for step2). 
	 * @param useStep2 if false, amino acid availibility affects recruitment. if true, amino acid availibity affects the birth rate of adults.
	 * @param speciesList a list of species objects. A species list can be created with the static [MakeSpeciesList.makeSpeciesList(...)], or with the alternative community constructor.
	 * @param useSharedInitProp if true, then all species are assigned the same initial abundance, and the parameters initProp0, initProp1, ... become irrelevant.
	 * @param initProp proportion of microsites occupied by all the species at their inoculation times. Basically, this quantity divided by the number of species gives the proportion of microsites that a species is to hold at inoculation time.
	 * @param useSharedDeathProb if true, then all species are assigned the same probability of death, and the parameters deathProb0, deathProb1, ... become irrelevant.
	 * @param deathProb if useSharedDeathProb is true, then this is the death probability that is assigned to each species.
	 * <p><p><p><p><p><p> note all the following parameters are ended by the number zero. This number denotes the types of amino acids that the species produces. Here, the suffix 0 denotes the cheater-specific parameter while the suffix 123 denotes a generalist-specific parameter.
	 * @param use0 if false, then the species is not used in the simulation. All species-specific parameters with the same identifying suffix are null and void.
	 * @param initProp0 the proportion of microsites that this species is to hold at inoculation time.
	 * @param cmax0 the maximum birth probability.
	 * @param death0 the death probability.
	 * @param inoculateWhen0 at what time step should the species be inoculated into the environment grid.
	 * @param inoculateOverwrite0 if true, then inoculated individuals can overwrite preexisting individuals. If false, then the inoculated individuals must find an empty microsite. If an individual cannot find a microsite after 500 tries, then it can overwrite heterospecifics. see method: inoculateSpecies. 
	 * @param AA1Kx0 the amino acid 1 requirement. If amino acid availability is less than this quantity, then an individual may be limited by this amino acid.
	 * @param AA2Kx0 the amino acid 2 requirement. If amino acid availability is less than this quantity, then an individual may be limited by this amino acid.
	 * @param AA3Kx0 the amino acid 3 requirement. If amino acid availability is less than this quantity, then an individual may be limited by this amino acid.
	 */
	public Community2(int gridLength, double dt, int dispersalRadius, int AADispersalRadius, double KAAProduced, boolean useStep2, boolean useSharedInitProp, double initProp,
			boolean useSharedDeathProb, double deathProb, boolean use0, double initProp0, double cmax0, double death0, int inoculateWhen0, boolean inoculateOverwrite0, int AA1Kx0, int AA2Kx0,
			int AA3Kx0, boolean use1, double initProp1, double cmax1, double death1, int inoculateWhen1, boolean inoculateOverwrite1, int AA1Kx1, int AA2Kx1, int AA3Kx1, boolean use2,
			double initProp2, double cmax2, double death2, int inoculateWhen2, boolean inoculateOverwrite2, int AA1Kx2, int AA2Kx2, int AA3Kx2, boolean use3, double initProp3, double cmax3,
			double death3, int inoculateWhen3, boolean inoculateOverwrite3, int AA1Kx3, int AA2Kx3, int AA3Kx3, boolean use12, double initProp12, double cmax12, double death12, int inoculateWhen12,
			boolean inoculateOverwrite12, int AA1Kx12, int AA2Kx12, int AA3Kx12, boolean use23, double initProp23, double cmax23, double death23, int inoculateWhen23, boolean inoculateOverwrite23,
			int AA1Kx23, int AA2Kx23, int AA3Kx23, boolean use13, double initProp13, double cmax13, double death13, int inoculateWhen13, boolean inoculateOverwrite13, int AA1Kx13, int AA2Kx13,
			int AA3Kx13, boolean use123, double initProp123, double cmax123, double death123, int inoculateWhen123, boolean inoculateOverwrite123, int AA1Kx123, int AA2Kx123, int AA3Kx123)
	{
		// instantiate a list of species
		this.speciesList = new ArrayList<Species>();

		// add detail to the speciesList in accordance with constructor parameters
		if (use0)
		{
			this.speciesList.add(new Species(0, abundFromProp(initProp0), cmax0, death0, inoculateWhen0, inoculateOverwrite0, false, false, false, AA1Kx0, AA2Kx0, AA3Kx0));
		}
		if (use1)
		{
			this.speciesList.add(new Species(1, abundFromProp(initProp1), cmax1, death1, inoculateWhen1, inoculateOverwrite1, true, false, false, AA1Kx1, AA2Kx1, AA3Kx1));
		}
		if (use2)
		{
			this.speciesList.add(new Species(2, abundFromProp(initProp2), cmax2, death2, inoculateWhen2, inoculateOverwrite2, false, true, false, AA1Kx2, AA2Kx2, AA3Kx2));
		}
		if (use3)
		{
			this.speciesList.add(new Species(3, abundFromProp(initProp3), cmax3, death3, inoculateWhen3, inoculateOverwrite3, false, false, true, AA1Kx3, AA2Kx3, AA3Kx3));
		}
		if (use12)
		{
			this.speciesList.add(new Species(12, abundFromProp(initProp12), cmax12, death12, inoculateWhen12, inoculateOverwrite12, true, true, false, AA1Kx12, AA2Kx12, AA3Kx12));
		}
		if (use23)
		{
			this.speciesList.add(new Species(23, abundFromProp(initProp23), cmax23, death23, inoculateWhen23, inoculateOverwrite23, true, false, true, AA1Kx23, AA2Kx23, AA3Kx23));
		}
		if (use13)
		{
			this.speciesList.add(new Species(13, abundFromProp(initProp13), cmax13, death13, inoculateWhen13, inoculateOverwrite13, false, true, true, AA1Kx13, AA2Kx13, AA3Kx13));
		}
		if (use123)
		{
			this.speciesList.add(new Species(123, abundFromProp(initProp123), cmax123, death123, inoculateWhen123, inoculateOverwrite123, true, true, true, AA1Kx123, AA2Kx123, AA3Kx123));
		}

		if (useSharedInitProp)
		{
			int initAbund = (int) Math.round((initProp / (double) this.speciesList.size()) * Math.pow(gridLength, 2));

			for (int i = 0; i < this.speciesList.size(); i++)
			{
				Species currentSpecies = this.speciesList.get(i);
				currentSpecies.setInitialAbundance(initAbund);

			}
		}

		if (useSharedDeathProb)
		{

			for (int i = 0; i < this.speciesList.size(); i++)
			{
				Species currentSpecies = this.speciesList.get(i);
				currentSpecies.setD(deathProb);

			}
		}
		// sets up instance variables
		this.generator = new Random();
		this.dt = dt;
		this.timeStep = 0;
		this.env = new Environment(gridLength);
		this.gridLength = gridLength;
		this.totalSites = this.gridLength * this.gridLength;
		this.numberOfSpecies = speciesList.size();
		this.dispersalRadius = dispersalRadius;
		this.AADispersalRadius = AADispersalRadius;
		this.neverInoculate = false;
		this.useStep2 = useStep2;
		this.KAAProduced = KAAProduced;
		int dispersalLength = 1 + this.dispersalRadius * 2;
		this.possibleNeighbors = dispersalLength * dispersalLength - 1;
		int AADispersalLength = 1 + this.AADispersalRadius * 2;
		this.possibleAANeighbors = AADispersalLength * AADispersalLength - 1;
		this.AAGrid = new double[this.gridLength][this.gridLength][3];
		this.critterCountGrid = new int[this.gridLength][this.gridLength][this.numberOfSpecies];
		this.growthRateGrid = new double[this.gridLength][this.gridLength][this.numberOfSpecies];
		this.cumulativeGrowthRateGrid = new double[this.gridLength][this.gridLength][this.numberOfSpecies];
		this.KAAProducedOverPossibleNeighbors = this.KAAProduced / (double) this.possibleNeighbors;
		this.KAAProducedOverPossibleAANeighbors = this.KAAProduced / (double) this.possibleAANeighbors;

		// sets up the numbers that appear end up on the grid
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			this.speciesList.get(i).setGridProxy(i + 1);
		}

		// if none of the species in the species list makes AA3, make it so none of the species need any AA3
		for (int i = 0; i < numberOfSpecies; i++)
		{
			if (speciesList.get(i).makesAA3())
			{
				break;
			}
			if (i == numberOfSpecies - 1)
			{
				noAA3();
			}

		}
	}

	/**
	 * scales species birth and death rates by dt. The lower the dt, the more simulation steps are in a single time unit.
	 */
	public void scaleByDt()
	{
		for (int s = 0; s < this.numberOfSpecies; s++)
		{
			Species tempSpecies = this.speciesList.get(s);
			tempSpecies.setCmax(tempSpecies.getCmax() * dt);
			tempSpecies.setD(tempSpecies.getD() * dt);

		}

	}

	/**
	 * gives the simulation a new dt (time scaling factor) and changes the birth and death rates accordingly.
	 * @param newDt
	 */
	public void setDt(double newDt)
	{
		this.dt = newDt;
		scaleByDt();
	}

	/**
	 * Takes a proportion of microsites and turns it into an number of microsites. This is a helper method for inoculation methods.
	 * @param prop the proportion of microsites
	 * @return abundace a integer of individuals
	 * @see inoculateInMiddle, inoculateSpecies
	 */
	public int abundFromProp(double prop)
	{
		return (int) Math.round(prop * (double) Math.pow(this.gridLength, 2));
	}

	/**
	 * goes through the list of species and checks if it's time for that species to be inoculated. If it's time, then the species is inoculated. A helper for step1 and step2
	 */
	public void checkForInoculations()
	{
		if (!this.neverInoculate)
		{
			// System.out.println("stepping");
			for (int sp = 0; sp < this.numberOfSpecies; sp++)
			{
				// System.out.println(" time step : " + this.timeStep);
				if (this.timeStep == this.speciesList.get(sp).getInoculateWhen())
				{
					// System.out.println("inoculating species " + this.speciesList.get(sp).getSpeciesName() + " at time step " + this.timeStep );
					inoculateSpecies(sp, this.speciesList.get(sp).getInoculateOverwrite());
					this.inoculateCounter++;
				}

			}
		}
	}

	/**
	 * Gives an array of species abundances or densities after a number of time steps.
	 * 
	 * @param numSteps run for this many time steps before recording abundances/densities
	 * @param reportDensity if true, return an array of densities. If false, return an array of abundances
	 * @return a one dimensional array of abundances or densities (depending on the reportDensity) parameter
	 */
	public double[] finalValue(int numSteps, boolean reportDensity)
	{

		for (int s = 0; s < numSteps; s++)
		{
			step();
		}

		return getAbundances(reportDensity);
	}

	public double[] finalValueReps(int numSteps, int numReps, boolean reportDensity)
	{
		double[][] finalAbundsOverTime = new double[speciesList.size()][numReps];
		for (int r = 0; r < numReps; r++)
		{
			Community2 com = new Community2(this);
			double[] temp = com.finalValue(numSteps, reportDensity);

			for (int t = 0; t < temp.length; t++)
			{
				finalAbundsOverTime[t][r] = temp[t];
			}
		}

		double[] toReturn = new double[finalAbundsOverTime.length * 2];
		for (int i = 0; i < finalAbundsOverTime.length; i++)
		{
			toReturn[2 * i] = MeanAndSD.meanAcrossColumns(finalAbundsOverTime, i);
			toReturn[2 * i + 1] = MeanAndSD.SDAcrossColumns(finalAbundsOverTime, i, toReturn[2 * i]);

		}

		return toReturn;

	}

	/**
	 * gets the abundance for each species.
	 * 
	 * @param reportDensity if true, then return an array of densities
	 * @return abundances an array of abundances. Exception: the first index of the array is the time step.
	 */
	public double[] getAbundances(boolean reportDensity)
	{
		int[] abundances = new int[this.numberOfSpecies + 1];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				abundances[this.env.getGridValue(row, col)]++;
			}
		}

		double[] realAbundances = new double[this.numberOfSpecies];
		if (reportDensity)
		{
			for (int s = 0; s < this.numberOfSpecies; s++)
			{
				realAbundances[s] = abundances[s + 1] / (double) this.totalSites;
			}
		}
		else
		{
			for (int s = 0; s < this.numberOfSpecies; s++)
			{
				realAbundances[s] = abundances[s + 1];
			}
		}
		return realAbundances;

	}

	/**
	 * Gets the environment, which consists of a grid and that grid's length.
	 * @return Environment 
	 */
	public Environment getEnvironment()
	{
		return this.env;
	}

	/**
	 * Gets the environment grid.
	 * @return grid
	 */
	public int[][] getGrid()
	{
		return this.env.getGrid();
	}

	/**
	 * Returns a grid where the location of an individual is denoted with its species name as opposed to its grid proxy. The cheater is named the 0, so empty sites are -1.
	 * @return grid a grid where the locations of individuals are denoted with species names. For more information on species names, see the documentation for the Species class.
	 */
	public int[][] getGridWithNames()
	{
		int[][] namedGrid = new int[this.gridLength][this.gridLength];

		int[][] grid = this.env.getGrid();

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				int gridValue = grid[row][col];

				if (gridValue == 0)
				{
					namedGrid[row][col] = -1;
				}
				else
				{
					namedGrid[row][col] = this.speciesList.get(gridValue - 1).getSpeciesName();
				}
			}
		}
		return namedGrid;

	}

	/**
	 * @return speciesList an arrayList of species. This method is exclusivelty for Jlink use (mathematica - java interface), since JLink was have a hard time accessing fields directly.
	 */
	public ArrayList<Species> getSpeciesList()
	{
		return this.speciesList;
	}

	/**
	 * Gets the environment grid after exacting a specified number of time steps.
	 * @param numSteps
	 * @return grid
	 */
	public int[][] gridFinal(int numSteps)
	{
		for (int i = 0; i < numSteps; i++)
		{
			step();
		}
		return getGrid();
	}

	/**
	 * Gives a time series of environment grids. Mostly for analyzing spatial structure over time.
	 * 
	 * @param numSteps how many time steps the method runs for
	 * @param measureHowOften how often should data be collected
	 * @return a three dimensional [row][col][time] array of species locationss
	 */
	public int[][][] gridTimeSeries(int numSteps, int measureHowOften)
	{
		int[][][] abundanceArray = new int[(numSteps / measureHowOften) + 1][this.gridLength][this.gridLength];
		int counter = 0;

		int[][] currentAbundances = this.env.getGrid();
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				abundanceArray[counter][row][col] = currentAbundances[row][col];
			}
		}
		counter++;

		for (int s = 1; s <= numSteps; s++)
		{
			step();
			// scatter();
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = this.env.getGrid();
				for (int row = 0; row < this.gridLength; row++)
				{
					for (int col = 0; col < this.gridLength; col++)
					{
						abundanceArray[counter][row][col] = currentAbundances[row][col];
					}
				}
				counter++;
			}
		}
		return abundanceArray;
	}

	/*
	 * public void inoculateQuantitativeCheater(boolean overrideOtherCritters) { Species curSpecies = this.speciesList.get(0); int val = curSpecies.getGridProxy();
	 * 
	 * int init = curSpecies.getInitialAbundance(); int i = 0; if (overrideOtherCritters) while (i < init) {
	 * 
	 * int row = generator.nextInt(this.env.getGridLength()); int col = generator.nextInt(this.env.getGridLength()); this.env.add(row, col, val); i++;
	 * 
	 * } else { while (i < init) {
	 * 
	 * int row = generator.nextInt(this.env.getGridLength()); int col = generator.nextInt(this.env.getGridLength()); if (this.env.isEmpty(row, col)) { this.env.add(row, col, val); i++; } } } }
	 */

	/**
	 * Gives a time series of environment grids.
	 * 
	 * @param start run this many time steps before recording any data
	 * @param end how many time steps elapse in total before the method ends
	 * @param measureHowOften how often should data be collected
	 * @return a three dimensional [row][col][time] array of species locationss
	 */
	public int[][][] gridTimeSeries(int start, int end, int measureHowOften)
	{
		int numSteps = end - start;
		int[][][] abundanceArray = new int[(numSteps / measureHowOften) + 1][this.gridLength][this.gridLength];
		int counter = 0;
		int s = 1;
		for (; s <= start; s++)
		{
			step();
		}

		int[][] currentAbundances = this.env.getGrid();
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				abundanceArray[counter][row][col] = currentAbundances[row][col];
			}
		}
		counter++;

		for (; s <= end; s++)
		{
			step();
			// scatter();
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = this.env.getGrid();
				for (int row = 0; row < this.gridLength; row++)
				{
					for (int col = 0; col < this.gridLength; col++)
					{
						abundanceArray[counter][row][col] = currentAbundances[row][col];
					}
				}
				counter++;
			}
		}
		return abundanceArray;
	}

	/**
	 * 
	 * GetGridScatter is identical to getGridTimeSeries, except that it scatters the populations
	 * after every time step. This formulation brings the model closer to a "well mixed" DE model, but maintains the effects of local interactions.
	 * 
	 * @param numSteps how many steps should the method run for 
	 * @param measureHowOften how often should data be collected
	 * @return a three dimensional [row][col][time] array of species locationss
	 */
	public int[][][] gridTimeSeriesScatter(int numSteps, int measureHowOften)
	{
		int[][][] abundanceArray = new int[(numSteps / measureHowOften) + 1][this.gridLength][this.gridLength];
		int counter = 0;

		int[][] currentAbundances = this.env.getGrid();
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				abundanceArray[counter][row][col] = currentAbundances[row][col];
			}
		}
		counter++;

		for (int s = 1; s <= numSteps; s++)
		{
			step();
			scatter(); // this is the one step different than getGridTimeSeries
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = this.env.getGrid();
				for (int row = 0; row < this.gridLength; row++)
				{
					for (int col = 0; col < this.gridLength; col++)
					{
						abundanceArray[counter][row][col] = currentAbundances[row][col];
					}
				}
				counter++;
			}
		}
		return abundanceArray;
	}

	/**
	 * 
	 * getGridScatter is identical to getGridTimeSeries, except that it scatters the populations
	 * after every time step. This formulation brings the model closer to a "well mixed" DE model, but maintains the effects of local interactions.
	 * 
	 * @param start run this many time steps before starting
	 * @param end how many time steps elapse in total before the method ends
	 * @param measureHowOften how often should data be collected
	 * @return a three dimensional [row][col][time] array of species locationss
	 */
	public int[][][] gridTimeSeriesScatter(int start, int end, int measureHowOften)
	{
		int numSteps = end - start;
		int[][][] abundanceArray = new int[(numSteps / measureHowOften) + 1][this.gridLength][this.gridLength];
		int counter = 0;
		int s = 1;
		for (; s <= start; s++)
		{
			step();
		}

		int[][] currentAbundances = this.env.getGrid();
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				abundanceArray[counter][row][col] = currentAbundances[row][col];
			}
		}
		counter++;

		for (; s <= end; s++)
		{
			step();
			scatter();
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = this.env.getGrid();
				for (int row = 0; row < this.gridLength; row++)
				{
					for (int col = 0; col < this.gridLength; col++)
					{
						abundanceArray[counter][row][col] = currentAbundances[row][col];
					}
				}
				counter++;
			}
		}
		return abundanceArray;
	}

	/**
	 * Gives a "header" (aka an array of column names) for the timeSeries method. Useful when calling from R, since R's data structures can be indexed using names.
	 * @return head
	 */
	public String[] headerForTimeSeries()
	{
		String[] header = new String[this.numberOfSpecies];
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			header[i] = "makesAA" + Integer.toString(this.speciesList.get(i).getSpeciesName());
		}
		return header;
	}

	/**
	 * Inoculates all the species into a small area in the middle of the envrionment grid. Used to illustrate quadratic population growth. 
	 * 
	 * @param initAbund the cumulative number of individuals that will be inoculated
	 */
	public void inoculateInMiddle(int initAbund)
	{
		// clear env of critters
		this.env.clearEnvOfCritters();

		int inocSquareLength = (int) Math.ceil(Math.sqrt(initAbund * numberOfSpecies));
		int totalInitAbund = inocSquareLength * inocSquareLength;
		int realInitAbund = totalInitAbund / this.numberOfSpecies;

		// set up new abundances
		for (int i = 0; i < numberOfSpecies; i++)
		{
			this.speciesList.get(i).setInitialAbundance(realInitAbund);
		}

		int referenceRowCol = (int) Math.floor(this.gridLength / 2) - (int) Math.ceil(inocSquareLength / (double) 2);

		for (int s = 0; s < this.numberOfSpecies; s++)
		{
			Species curSpecies = this.speciesList.get(s);
			int val = curSpecies.getGridProxy();

			int init = curSpecies.getInitialAbundance();
			int i = 0;
			while (i < init)
			{

				int row = this.generator.nextInt(inocSquareLength) + referenceRowCol;
				int col = this.generator.nextInt(inocSquareLength) + referenceRowCol;
				if (this.env.isEmpty(row, col))
				{
					this.env.add(row, col, val);
					i++;
				}
			}
		}
	}

	/**
	 * 
	 * Randomly places a population on the environment grid.
	 * 
	 * @param speciesListIndex the speciesList index of the species that is to be inoculated
	 * @param overrideOtherCritters if true, overwrite heterospecifics upon inocuation. If false, try to find an empty microsite 500 times. If that doesn't work, go ahead and overwrite heterospecifics
	 */
	public void inoculateSpecies(int speciesListIndex, boolean overrideOtherCritters)
	{
		Species curSpecies = this.speciesList.get(speciesListIndex);
		int val = curSpecies.getGridProxy();

		int init = curSpecies.getInitialAbundance();
		int i = 0;
		// if we don't plan to overwrite other critters
		if (!overrideOtherCritters)

			// do the following for each individual
			while (i < init)
			{
				int k = 0;
				// try to find an empty site 500 times
				while (k < 500)
				{
					int row = this.generator.nextInt(this.env.getGridLength());
					int col = this.generator.nextInt(this.env.getGridLength());
					if (this.env.isEmpty(row, col))
					{
						this.env.add(row, col, val);
						break;
					}
					k++;
				}

				// if that doesn't work, keep trying to establish until you find an empty site or a heterospecific
				if (k == 500)
				{
					while (true)
					{
						int row = this.generator.nextInt(this.env.getGridLength());
						int col = this.generator.nextInt(this.env.getGridLength());
						if (this.env.getGridValue(row, col) != val)
						{
							// take over that spot
							this.env.add(row, col, val);
							break;
						}
					}
				}

				i++;

			}
		// if we don't have a problem with overwriting heterospecifics
		else
		{
			// do the following for each individual
			while (i < init)
			{
				// search for an empty site or a site with a heterospecific
				while (true)
				{
					int row = this.generator.nextInt(this.env.getGridLength());
					int col = this.generator.nextInt(this.env.getGridLength());
					if (this.env.getGridValue(row, col) != val)
					{
						// then take over that spot
						this.env.add(row, col, val);
						break;
					}
				}
				i++;
			}
		}
	}

	/**
	 * Makes sure that no species can be added to the environmment after this method is called.
	 */
	public void neverInoculate()
	{
		this.neverInoculate = true;

	}

	/**
	 * If there are no species that produce amino acid three, then make it so no species need amino acid 3. This method is 
	 * for when you're interested in the set/subsets of microbes 0, 1, 2, 12.
	 */
	public void noAA3()
	{
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			this.speciesList.get(i).dontUseAA3();
		}
	}

	/**
	 * The program scatter randomly mixes up all of the individuals, without changing
	 * the actual population.
	 */
	public void scatter()
	{

		double[] currentAbundances = getAbundances(false);

		// Here I clear out the population, so I can add new microbes back in.
		// Basically, I go through the grid, and if a location is occupied, I remove it.
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.isOccupied(row, col))
				{
					this.env.remove(row, col);
				}
			}
		}

		// I then randomly adds specified number of individuals to the grid.
		// This code is copied from when we create the initial population.
		for (int jtemp = 1; jtemp < this.numberOfSpecies + 1; jtemp++)
		{

			double init = currentAbundances[jtemp - 1];
			int i = 0;

			// I repeatedly add in new individuals until I have added in
			// a number equal to the currentAbundance of that species.
			while (i < init)
			{

				// Choose a random location- (X,Y) coordinate.
				int row = this.generator.nextInt(this.env.getGridLength());
				int col = this.generator.nextInt(this.env.getGridLength());

				// This is to make sure that I add the microbe to an empty space.
				// If it is empty, I add it. Otherwise, I draw a new random number
				if (this.env.isEmpty(row, col))
				{
					this.env.add(row, col, jtemp);
					i++;
				}
			}
		}

	}

	/**
	 * 	The program scatter randomly mixes up all of the individuals, without changing
	 * the actual population. This uses a different randomization algorithm than scatter().
	 */
	public void scatter2()
	{

		double[] currentAbundances = getAbundances(false);
		int total = this.gridLength * this.gridLength;
		for (int i = 0; i < this.numberOfSpecies; i++)
		{
			total += currentAbundances[i];
		}

		// Here I clear out the population, so I can add new microbes back in.
		// Basically, I go through the grid, and if a location is occupied, I remove it.
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				if (this.env.isOccupied(row, col))
				{
					this.env.remove(row, col);
				}
			}
		}

		int[] ar = new int[total];
		for (int i = 0; i < total; i++)
		{
			ar[i] = i;
		}

		for (int i = 0; i < total - 1; i++)
		{
			int num = this.generator.nextInt(total - i);
			int temp = ar[num];
			ar[num] = ar[total - 1 - i];
			ar[total - 1 - i] = temp;
		}

		int counter = 0;
		for (int jtemp = 1; jtemp < this.numberOfSpecies + 1; jtemp++)
		{

			double init = currentAbundances[jtemp - 1];

			// I repeatedly add in new individuals until I have added in
			// a number equal to the currentAbundance of that species.
			for (int i = 0; i < init; i++)
			{
				int row = ar[counter] / this.gridLength;
				int col = ar[counter] % this.gridLength;
				counter++;

				this.env.add(row, col, jtemp);
			}
		}

	}

	/**
	 * Sets a new AADispersalRadius.
	 * @param AADispersalRadius
	 */
	public void setAADispersalRadius(int AADispersalRadius)
	{
		this.AADispersalRadius = AADispersalRadius;
	}

	/**
	 * Sets a new dispersalRadius.
	 * @param dispersalRadius
	 */
	public void setDispersalRadius(int dispersalRadius)
	{
		this.dispersalRadius = dispersalRadius;
	}

	/**
	 * Replaces the old environment grid with the grid parameter. WARNING: Note that simulations require species-specific information that is stored in the speciesList;
	 * if species in the grid parameter don't match up with the species in the species list, the simulation will run funky i.e. individuals of a species will never die or reproduce.  
	 * @param grid
	 */
	public void setGrid(int[][] grid)
	{
		this.env.setGrid(grid);
	}

	/**
	 * Sets the time step counter. Although the timeStep variable is incremented after every step() call, the timeStep variable is only useful in determining when species are inoculated.
	 * Time dependent methods (e.g. timeseries(...), gridTimeSeries(...), finalValues(...) ) use a local time variable to keep track of time.
	 * @param timeStep
	 */
	public void seTimeStep(int timeStep)
	{
		this.timeStep = timeStep;
	}

	/**
	 * Set a new KAAProduced.
	 * @param KAAProduced
	 */
	public void setKAAProduced(double KAAProduced)
	{
		this.KAAProduced = KAAProduced;
	}

	/*
	 * public int[][] quantCheatTimeSeries(int numSteps, int measureHowOften, int stepsUntilInoculateCheater) { int[][] abundanceArray = new int[(numSteps / measureHowOften) + 1][this.numberOfSpecies + 1]; int counter = 0;
	 * 
	 * // get abundance for time 0 int[] currentAbundances = getAbundances(); for (int i = 0; i < currentAbundances.length; i++) { abundanceArray[counter][i] = currentAbundances[i]; } counter++;
	 * 
	 * // get abundances every X time steps for (int s = 1; s <= numSteps; s++) { step();
	 * 
	 * // if it's time to inoculate the cheater, break this loop... if (s == stepsUntilInoculateCheater) { inoculateQuantitativeCheater(false); }
	 * 
	 * if ((s % measureHowOften == 0) && (s / measureHowOften != 0)) { currentAbundances = getAbundances(); for (int i = 0; i < currentAbundances.length; i++) { abundanceArray[counter][i] = currentAbundances[i]; } counter++; } }
	 * 
	 * return abundanceArray; }
	 * 
	 * public double[] quantCheatFinalValue(int numSteps, int stepsUntilInoculateCheater, boolean reportDensity) { int s = 0; for (; s < stepsUntilInoculateCheater; s++) { step(); }
	 * 
	 * inoculateQuantitativeCheater(true);
	 * 
	 * for (; s < numSteps; s++) { step(); }
	 * 
	 * int[] currentAbundances = getAbundances(); double[] cheatSynSyn = new double[3];
	 * 
	 * cheatSynSyn[0] = currentAbundances[1]; cheatSynSyn[1] = currentAbundances[2]; cheatSynSyn[2] = currentAbundances[3];
	 * 
	 * if (reportDensity) { int totalSites = this.gridLength * this.gridLength; cheatSynSyn[0] = cheatSynSyn[0] / (double) totalSites; cheatSynSyn[1] = cheatSynSyn[1] / (double) totalSites; cheatSynSyn[2] = cheatSynSyn[2] / (double) totalSites; }
	 * 
	 * return cheatSynSyn; }
	 */

	/**
	 * Setting the seed allows simulations to be repeatable.
	 * @param setHere
	 */
	public void setSeed(int setHere)
	{
		this.generator.setSeed(setHere);
	}

	/**
	 * Tells the simulation to use the time stepping function where amino acid availibility directly affects recruitment.
	 */
	public void setToStep1()
	{
		this.useStep2 = false;
	}

	/**
	 * Tells the simulations to use the time stepping function where amino acid availibility directly affects fecunditiy, i.e. adult reproductie capability.
	 */
	public void setToStep2()
	{
		this.useStep2 = true;
	}

	/**
	 * Calls either step1 or step2. The useStep2 variable decides which stepping method to use. The useStep2 variable can be set in the constructor or in the methods setToStep1() and setToStep2().
	 * 
	 */
	public void step()
	{
		if (this.useStep2)
		{
			step2();
		}
		else
		{
			step1();
		}
	}

	/**
	 * Calls either step1 or step2. The useStep2 variable decides which stepping method to use. The useStep2 variable can be set in the constructor or in the methods setToStep1() and setToStep2().
	 * @param numSteps
	 */
	public void step(int numSteps)
	{

		if (this.useStep2)
		{
			for (int i = 0; i < numSteps; i++)
			{
				step2();
			}
		}
		else
		{
			for (int i = 0; i < numSteps; i++)
			{
				step1();
			}
		}
	}
	
	public void addAAStep1(int row, int col, Species aSpecies)
	{
		int name = aSpecies.getSpeciesName();
		int gridProxy = aSpecies.getGridProxy();
		switch (name)
		{

		case 0:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 1:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleNeighbors;
					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 2:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleNeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 3:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleNeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 12:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleNeighbors;
					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleNeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 23:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleNeighbors;
					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleNeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 13:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleNeighbors;
					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleNeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		case 123:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleNeighbors;
					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleNeighbors;
					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleNeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]++;

				}
			}
			break;

		}

	}

	public void subtractAAStep1(int row, int col, Species aSpecies)
	{
		int name = aSpecies.getSpeciesName();
		int gridProxy = aSpecies.getGridProxy();
		switch (name)
		{

		case 0:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 1:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);
					/*
					 * System.out.println("real row is " + realRow); System.out.println("real col is " + realCol);
					 */

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleNeighbors;
					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 2:

			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleNeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 3:

			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleNeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 12:

			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleNeighbors;
					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleNeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 23:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleNeighbors;
					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleNeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 13:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleNeighbors;
					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleNeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;

		case 123:
			for (int row2 = row - this.dispersalRadius; row2 < row + 1 + this.dispersalRadius; row2++)
			{
				for (int col2 = col - this.dispersalRadius; col2 < col + 1 + this.dispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleNeighbors;
					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleNeighbors;
					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleNeighbors;

					this.critterCountGrid[realRow][realCol][gridProxy - 1]--;

				}
			}
			break;
		}

	}

	public void addAAStep2(int row, int col, Species aSpecies)
	{
		int name = aSpecies.getSpeciesName();
		switch (name)
		{

		case 0:
			break;

		case 1:
			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 2:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 3:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 12:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 23:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 13:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 123:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][1] += this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] += this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		}

	}

	public void subtractAAStep2(int row, int col, Species aSpecies)
	{
		int name = aSpecies.getSpeciesName();
		switch (name)
		{

		case 0:

			break;

		case 1:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);
					/*
					 * System.out.println("real row is " + realRow); System.out.println("real col is " + realCol);
					 */
					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleAANeighbors;
				}
			}
			break;

		case 2:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 3:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 12:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 23:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleAANeighbors;

				}
			}
			break;

		case 13:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleAANeighbors;
				}
			}
			break;

		case 123:

			for (int row2 = row - this.AADispersalRadius; row2 < row + 1 + this.AADispersalRadius; row2++)
			{
				for (int col2 = col - this.AADispersalRadius; col2 < col + 1 + this.AADispersalRadius; col2++)
				{
					int realRow = WrapAround.wrapAround(row2, this.gridLength);
					int realCol = WrapAround.wrapAround(col2, this.gridLength);

					this.AAGrid[realRow][realCol][0] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][1] -= this.KAAProducedOverPossibleAANeighbors;
					this.AAGrid[realRow][realCol][2] -= this.KAAProducedOverPossibleAANeighbors;
				}
			}
			break;
		}

	}
	
	/**
	 * 
	 * Execute one time step where amino acid availibility affects recruitment. The probability of a birth in an empty site is determined by amount of amino acid that reaches that site.   
	 */
	public void step1a()
	{
		checkForInoculations();
		/*
		 * if(this.timeStep == 1) for (int row = 0; row < this.gridLength; row++) { for (int col = 0; col < this.gridLength; col++) { System.out.print(this.AAGrid[row][col][0] + "  ");
		 * 
		 * } System.out.println(""); }
		 */
		// System.out.println("starting main step loop");
		ArrayList<Location> toRemoveLocation = new ArrayList<Location>();
		ArrayList<Species> toRemoveCritter = new ArrayList<Species>();

		ArrayList<Location> toAddLocation = new ArrayList<Location>();
		ArrayList<Species> toAddCritter = new ArrayList<Species>();

		// go throught the rows and columns
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				// if it's occupied, pull a random number to see if it dies
				if (this.env.isOccupied(row, col))
				{

					double deathProb = this.speciesList.get(this.env.getGridValue(row, col) - 1).getD();
					if (this.generator.nextDouble() < deathProb)
					{
						int gridValue = this.env.getGridValue(row, col);

						Species curSpecies = this.speciesList.get(gridValue - 1);
						// index it to remove at the end of the time step
						toRemoveCritter.add(curSpecies);
						toRemoveLocation.add(new Location(row, col));
					}
					// if it does die, go to the next row,col location
					continue;
				}
				else
				// if it's empty, enter birth process
				{

					double[] birthProbs = new double[this.numberOfSpecies];
					double AA1Avail = this.AAGrid[row][col][0];
					double AA2Avail = this.AAGrid[row][col][1];
					double AA3Avail = this.AAGrid[row][col][2];

					// System.out.println(counter);
					// System.out.println(AACounts[0]);

					// for each critter determine the term of the birth probability that follows leibigs law of the minimum with respect to AA.
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						Species currentSpecies = this.speciesList.get(spp);
						double tempF = 1;
						if (!currentSpecies.makesAA1())
						{
							if (AA1Avail / currentSpecies.getAA1K() < tempF)
							{
								tempF = AA1Avail / currentSpecies.getAA1K();
							}
						}

						if (!currentSpecies.makesAA2())
						{
							if (AA2Avail / currentSpecies.getAA2K() < tempF)
							{
								tempF = AA2Avail / currentSpecies.getAA2K();
							}
						}

						if (!currentSpecies.makesAA3())
						{
							if (AA3Avail / currentSpecies.getAA3K() < tempF)
							{
								tempF = AA3Avail / currentSpecies.getAA3K();
							}
						}

						// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
						// are around to give birth
						birthProbs[spp] = currentSpecies.getCmax() * tempF * (this.critterCountGrid[row][col][spp] / (double) this.possibleNeighbors);

					}

					// figure out which bacterium (if any) is going to give birth
					double theBirthProb = this.generator.nextDouble();
					double compareTo = 0;
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						compareTo += birthProbs[spp];

						if (theBirthProb < compareTo)
						{
							toAddCritter.add(this.speciesList.get(spp));
							toAddLocation.add(new Location(row, col));
							// this.env.add(new Location(row, col), this.speciesList.get(spp).getGridProxy());
							break;
						}

					}
				}
			}

		}

		// Exception thrower if critters and location get unsynchronized
		/*
		 * if (toAddLocation.size() != toAddCritter.size()) { IllegalStateException e = new IllegalStateException("critters and locations are unsynchronized"); throw e; }
		 */
		for (int i = 0; i < toRemoveLocation.size(); i++)
		{
			Location loc = toRemoveLocation.get(i);
			Species tempSpecies = toRemoveCritter.get(i);
			this.env.remove(loc.row(), loc.col());
			subtractAAStep1(loc.row(), loc.col(), tempSpecies);
		}
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location loc = toAddLocation.get(i);
			Species tempSpecies = toAddCritter.get(i);
			this.env.add(loc, tempSpecies.getGridProxy());
			addAAStep1(loc.row(), loc.col(), tempSpecies);
		}
		this.timeStep++;
	}
	/**
	 * 
	 * Execute one time step where amino acid availibility affects recruitment. The probability of a birth in an empty site is determined by amount of amino acid that reaches that site.   
	 */
	public void step1()
	{
		checkForInoculations();

		// System.out.println("starting main step loop");
		ArrayList<Location> toRemove = new ArrayList<Location>();
		ArrayList<Location> toAddLocation = new ArrayList<Location>();
		ArrayList<Integer> toAddCritter = new ArrayList<Integer>();

		// go throught the rows and columns
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				// if it's occupied, pull a random number to see if it dies
				if (this.env.isOccupied(row, col))
				{

					double deathProb = this.speciesList.get(this.env.getGridValue(row, col) - 1).getD();
					if (this.generator.nextDouble() < deathProb)
					{
						// index it to remove at the end of the time step
						toRemove.add(new Location(row, col));
					}
					// if it does die, go to the next row,col location
					continue;
				}
				else
				// if it's empty, enter birth process
				{

					int[] critterCounts = new int[this.numberOfSpecies];
					double[] AACounts = new double[3];
					double[] birthProbs = new double[this.numberOfSpecies];

					// int counter = 0;
					// look in a square of "dispersalRadius" radius around the current row,col location
					for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
					{
						for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
						{
							// counter++;
							int gridValue = this.env.getGridValue(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength));

							if (gridValue != 0)
							{
								// add to an array of conspecific critters
								critterCounts[gridValue - 1]++;

								/*
								 * String nameString = Integer.toString(this.speciesList.get(gridValue-1).getSpeciesName()); int nameLength = nameString.length();
								 * 
								 * // count up amino Acids in the radius for (int l = 0; l < nameLength; l++) { AACounts[Integer.parseInt(nameString.substring(l, l + 1))]++; }
								 */
								// add to an array of amino acid availability
								Species currentSpecies = this.speciesList.get(gridValue - 1);
								if (currentSpecies.makesAA1())
								{
									AACounts[0] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA2())
								{
									AACounts[1] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA3())
								{
									AACounts[2] += this.KAAProduced / (double) this.possibleNeighbors;
								}

							}
						}
					}
					// System.out.println(counter);
					// System.out.println(AACounts[0]);

					// for each critter determine the term of the birth probability that follows leibigs law of the minimum with respect to AA.
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						Species currentSpecies = this.speciesList.get(spp);
						double tempF = 1;
						if (!currentSpecies.makesAA1())
						{
							if (AACounts[0] / currentSpecies.getAA1K() < tempF)
							{
								tempF = AACounts[0] / currentSpecies.getAA1K();
							}
						}

						if (!currentSpecies.makesAA2())
						{
							if (AACounts[1] / currentSpecies.getAA2K() < tempF)
							{
								tempF = AACounts[1] / currentSpecies.getAA2K();
							}
						}

						if (!currentSpecies.makesAA3())
						{
							if (AACounts[2] / currentSpecies.getAA3K() < tempF)
							{
								tempF = AACounts[2] / currentSpecies.getAA3K();
							}
						}

						// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
						// are around to give birth
						birthProbs[spp] = currentSpecies.getCmax() * tempF * (critterCounts[spp] / (double) this.possibleNeighbors);

					}

					// figure out which bacterium (if any) is going to give birth
					double theBirthProb = this.generator.nextDouble();
					double compareTo = 0;
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						compareTo += birthProbs[spp];

						if (theBirthProb < compareTo)
						{
							toAddCritter.add(this.speciesList.get(spp).getGridProxy());
							toAddLocation.add(new Location(row, col));
							// this.env.add(new Location(row, col), this.speciesList.get(spp).getGridProxy());
							break;
						}

					}
				}
			}

		}

		// Exception thrower if critters and location get unsynchronized
		/*
		 * if (toAddLocation.size() != toAddCritter.size()) { IllegalStateException e = new IllegalStateException("critters and locations are unsynchronized"); throw e; }
		 */
		for (int i = 0; i < toRemove.size(); i++)
		{
			Location loc = toRemove.get(i);
			this.env.remove(loc.row(), loc.col());
		}
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location loc = toAddLocation.get(i);
			this.env.add(loc, toAddCritter.get(i));
		}
		this.timeStep++;
	}

	/**
	 * 
	 * Execute one time step where amino acid availibility affects recruitment. The probability of a birth in an empty site is determined by amount of amino acid that reaches that site.   
	 */
	public void step12()
	{ // to return: 2D array of Location specific competition values (possible sites/empty sites) // note that fitness (lambda) is birth rate * 1/C * (1- deathrate) double[][] CArray = new double[this.gridLength][this.gridLength];

		checkForInoculations();

		// System.out.println("starting main step loop");
		ArrayList<Location> toRemove = new ArrayList<Location>();
		ArrayList<Location> toAddLocation = new ArrayList<Location>();
		ArrayList<Integer> toAddCritter = new ArrayList<Integer>();

		int[][] critterCounts = new int[this.numberOfSpecies][3];
		double[][] AACounts = new double[3][3];

		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{

				// if it's occupied, pull a random number to see if it dies
				if (this.env.isOccupied(row, col))
				{

					double deathProb = this.speciesList.get(this.env.getGridValue(row, col) - 1).getD();
					if (this.generator.nextDouble() < deathProb)
					{
						// index it to remove at the end of the time step
						toRemove.add(new Location(row, col));
					}

				}
				else
				{

					if (col == 0)
					{

						critterCounts = new int[this.numberOfSpecies][3];
						AACounts = new double[3][3];
						int col2 = WrapAround.wrapAround(col - this.dispersalRadius, this.gridLength);
						for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
						{
							int gridValue = this.env.getGridValue(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength));

							if (gridValue != 0)
							{
								// add to an array of conspecific critters
								critterCounts[gridValue - 1][0]++;

								/*
								 * String nameString = Integer.toString(this.speciesList.get(gridValue-1).getSpeciesName()); int nameLength = nameString.length();
								 * 
								 * // count up amino Acids in the radius for (int l = 0; l < nameLength; l++) { AACounts[Integer.parseInt(nameString.substring(l, l + 1))]++; }
								 */
								// add to an array of amino acid availability
								Species currentSpecies = this.speciesList.get(gridValue - 1);
								if (currentSpecies.makesAA1())
								{
									AACounts[0][0] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA2())
								{
									AACounts[1][0] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA3())
								{
									AACounts[2][0] += this.KAAProduced / (double) this.possibleNeighbors;
								}

							}
						}

						for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
						{
							for (col2 = col - this.dispersalRadius + 1; col2 <= col + this.dispersalRadius - 1; col2++)
							{
								if (this.env.isEmpty(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength)))

								{
									int gridValue = this.env.getGridValue(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength));

									if (gridValue != 0)
									{
										// add to an array of conspecific critters
										critterCounts[gridValue - 1][1]++;

										/*
										 * String nameString = Integer.toString(this.speciesList.get(gridValue-1).getSpeciesName()); int nameLength = nameString.length();
										 * 
										 * // count up amino Acids in the radius for (int l = 0; l < nameLength; l++) { AACounts[Integer.parseInt(nameString.substring(l, l + 1))]++; }
										 */
										// add to an array of amino acid availability
										Species currentSpecies = this.speciesList.get(gridValue - 1);
										if (currentSpecies.makesAA1())
										{
											AACounts[0][1] += this.KAAProduced / (double) this.possibleNeighbors;
										}
										if (currentSpecies.makesAA2())
										{
											AACounts[1][1] += this.KAAProduced / (double) this.possibleNeighbors;
										}
										if (currentSpecies.makesAA3())
										{
											AACounts[2][1] += this.KAAProduced / (double) this.possibleNeighbors;
										}

									}
								}
							}
						}

						col2 = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);
						for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
						{
							int gridValue = this.env.getGridValue(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength));

							if (gridValue != 0)
							{
								// add to an array of conspecific critters
								critterCounts[gridValue - 1][2]++;

								/*
								 * String nameString = Integer.toString(this.speciesList.get(gridValue-1).getSpeciesName()); int nameLength = nameString.length();
								 * 
								 * // count up amino Acids in the radius for (int l = 0; l < nameLength; l++) { AACounts[Integer.parseInt(nameString.substring(l, l + 1))]++; }
								 */
								// add to an array of amino acid availability
								Species currentSpecies = this.speciesList.get(gridValue - 1);
								if (currentSpecies.makesAA1())
								{
									AACounts[0][2] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA2())
								{
									AACounts[1][2] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA3())
								{
									AACounts[2][2] += this.KAAProduced / (double) this.possibleNeighbors;
								}

							}
						}
					}
					else
					{

						for (int i = 0; i < 3; i++)
						{
							AACounts[i][0] = 0;
						}
						int col2 = WrapAround.wrapAround(col - this.dispersalRadius, this.gridLength);
						for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
						{
							int gridValue = this.env.getGridValue(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength));

							if (gridValue != 0)
							{
								// add to an array of conspecific critters
								critterCounts[gridValue - 1][0]++;

								/*
								 * String nameString = Integer.toString(this.speciesList.get(gridValue-1).getSpeciesName()); int nameLength = nameString.length();
								 * 
								 * // count up amino Acids in the radius for (int l = 0; l < nameLength; l++) { AACounts[Integer.parseInt(nameString.substring(l, l + 1))]++; }
								 */
								// add to an array of amino acid availability
								Species currentSpecies = this.speciesList.get(gridValue - 1);
								if (currentSpecies.makesAA1())
								{
									AACounts[0][0] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA2())
								{
									AACounts[1][0] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA3())
								{
									AACounts[2][0] += this.KAAProduced / (double) this.possibleNeighbors;
								}

							}
						}

						/*for (int i = 0; i < 3; i++)
						{
							AACounts[i][1] += AACounts[i][2] - AACounts[i][0];
						}*/
						for (int i = 0; i < 3; i++)
						{
							AACounts[1][i] += AACounts[2][i] - AACounts[0][i];
						}

						/*for (int i = 0; i < this.numberOfSpecies; i++)
						{
							critterCounts[i][1] += critterCounts[i][2] - critterCounts[i][0];
						}
						*/
						for (int i = 0; i < this.numberOfSpecies; i++)
						{
							critterCounts[1][i] += critterCounts[2][i] - critterCounts[0][i];
						}
						

						for (int i = 0; i < 3; i++)
						{
							AACounts[i][2] = 0;
						}
						col2 = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);
						for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
						{
							int gridValue = this.env.getGridValue(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength));

							if (gridValue != 0)
							{
								// add to an array of conspecific critters
								critterCounts[gridValue - 1][2]++;

								/*
								 * String nameString = Integer.toString(this.speciesList.get(gridValue-1).getSpeciesName()); int nameLength = nameString.length();
								 * 
								 * // count up amino Acids in the radius for (int l = 0; l < nameLength; l++) { AACounts[Integer.parseInt(nameString.substring(l, l + 1))]++; }
								 */
								// add to an array of amino acid availability
								Species currentSpecies = this.speciesList.get(gridValue - 1);
								if (currentSpecies.makesAA1())
								{
									AACounts[0][2] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA2())
								{
									AACounts[1][2] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA3())
								{
									AACounts[2][2] += this.KAAProduced / (double) this.possibleNeighbors;
								}

							}
						}

					}

				}

				double[] birthProbs = getBirthProbabilities(AACounts, critterCounts);

				double theBirthProb = this.generator.nextDouble();
				double compareTo = 0;

				for (int spp = 0; spp < this.numberOfSpecies; spp++)
				{
					compareTo += birthProbs[spp];

					if (theBirthProb < compareTo)
					{
						toAddCritter.add(this.speciesList.get(spp).getGridProxy());
						toAddLocation.add(new Location(row, col));
						// this.env.add(new Location(row, col), this.speciesList.get(spp).getGridProxy());
						break;
					}

				}

			}
		}
		for (int i = 0; i < toRemove.size(); i++)
		{
			Location loc = toRemove.get(i);
			this.env.remove(loc.row(), loc.col());
		}
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location loc = toAddLocation.get(i);
			this.env.add(loc, toAddCritter.get(i));
		}
		this.timeStep++;
	}

	public void step122()
	{
		checkForInoculations();

		// System.out.println("starting main step loop");
		ArrayList<Location> toRemove = new ArrayList<Location>();
		ArrayList<Location> toAddLocation = new ArrayList<Location>();
		ArrayList<Integer> toAddCritter = new ArrayList<Integer>();
		int[][] critterCounts = new int[this.numberOfSpecies][3];
		double[][] AACounts = new double[3][3]; // [aa1, aa2, aa3][first, mid, last]
		double[] birthProbs = new double[this.numberOfSpecies];

		// go throught the rows and columns
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				// if it's occupied, pull a random number to see if it dies
				if (this.env.isOccupied(row, col))
				{

					double deathProb = this.speciesList.get(this.env.getGridValue(row, col) - 1).getD();
					if (this.generator.nextDouble() < deathProb)
					{
						// index it to remove at the end of the time step
						toRemove.add(new Location(row, col));
					}

				}
				else
				// if it's empty, enter birth process
				{

					if (col == 0)
					{

						critterCounts = new int[this.numberOfSpecies][3];
						AACounts = new double[3][3];
						/*
						 * AACounts[0][0] = 0; AACounts[1][0] = 0; AACounts[2][0] = 0; for (int i = 0; i < this.numberOfSpecies; i++) { critterCounts[i][0] = 0; }
						 */
						int col2 = WrapAround.wrapAround(col - this.dispersalRadius, this.gridLength);
						for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
						{
							// counter++;
							int gridValue = this.env.getGridValue(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength));

							if (gridValue != 0)
							{
								// add to an array of conspecific critters
								critterCounts[gridValue - 1][0]++;

								/*
								 * String nameString = Integer.toString(this.speciesList.get(gridValue-1).getSpeciesName()); int nameLength = nameString.length();
								 * 
								 * // count up amino Acids in the radius for (int l = 0; l < nameLength; l++) { AACounts[Integer.parseInt(nameString.substring(l, l + 1))]++; }
								 */
								// add to an array of amino acid availability
								Species currentSpecies = this.speciesList.get(gridValue - 1);
								if (currentSpecies.makesAA1())
								{
									AACounts[0][0] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA2())
								{
									AACounts[1][0] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA3())
								{
									AACounts[2][0] += this.KAAProduced / (double) this.possibleNeighbors;
								}

							}
						}

						/*
						 * AACounts[0][1] = 0; AACounts[1][1] = 0; AACounts[2][1] = 0; for (int i = 0; i < this.numberOfSpecies; i++) { critterCounts[i][1] = 0; }
						 */
						for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
						{
							for (col2 = col - this.dispersalRadius + 1; col2 <= col + this.dispersalRadius - 1; col2++)
							{

								// counter++;
								int gridValue = this.env.getGridValue(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength));

								if (gridValue != 0)
								{
									// add to an array of conspecific critters
									critterCounts[gridValue - 1][1]++;

									/*
									 * String nameString = Integer.toString(this.speciesList.get(gridValue-1).getSpeciesName()); int nameLength = nameString.length();
									 * 
									 * // count up amino Acids in the radius for (int l = 0; l < nameLength; l++) { AACounts[Integer.parseInt(nameString.substring(l, l + 1))]++; }
									 */
									// add to an array of amino acid availability
									Species currentSpecies = this.speciesList.get(gridValue - 1);
									if (currentSpecies.makesAA1())
									{
										AACounts[0][1] += this.KAAProduced / (double) this.possibleNeighbors;
									}
									if (currentSpecies.makesAA2())
									{
										AACounts[1][1] += this.KAAProduced / (double) this.possibleNeighbors;
									}
									if (currentSpecies.makesAA3())
									{
										AACounts[2][1] += this.KAAProduced / (double) this.possibleNeighbors;
									}

								}

							}
						}

						/*
						 * AACounts[0][2] = 0; AACounts[1][2] = 0; AACounts[2][2] = 0; for (int i = 0; i < this.numberOfSpecies; i++) { critterCounts[i][2] = 0; }
						 */
						col2 = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);
						for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
						{

							// counter++;
							int gridValue = this.env.getGridValue(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength));

							if (gridValue != 0)
							{
								// add to an array of conspecific critters
								critterCounts[gridValue - 1][2]++;

								/*
								 * String nameString = Integer.toString(this.speciesList.get(gridValue-1).getSpeciesName()); int nameLength = nameString.length();
								 * 
								 * // count up amino Acids in the radius for (int l = 0; l < nameLength; l++) { AACounts[Integer.parseInt(nameString.substring(l, l + 1))]++; }
								 */
								// add to an array of amino acid availability
								Species currentSpecies = this.speciesList.get(gridValue - 1);
								if (currentSpecies.makesAA1())
								{
									AACounts[0][2] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA2())
								{
									AACounts[1][2] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA3())
								{
									AACounts[2][2] += this.KAAProduced / (double) this.possibleNeighbors;
								}

							}

						}
						// birthProbs = getBirthProbabilities(AACounts, critterCounts);
					}
					else
					{

						AACounts[0][0] = 0;
						AACounts[1][0] = 0;
						AACounts[2][0] = 0;
						for (int i = 0; i < this.numberOfSpecies; i++)
						{
							critterCounts[i][0] = 0;
						}
						int col2 = WrapAround.wrapAround(col - this.dispersalRadius, this.gridLength);
						for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
						{

							// counter++;
							int gridValue = this.env.getGridValue(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength));

							if (gridValue != 0)
							{
								// add to an array of conspecific critters
								critterCounts[gridValue - 1][0]++;

								/*
								 * String nameString = Integer.toString(this.speciesList.get(gridValue-1).getSpeciesName()); int nameLength = nameString.length();
								 * 
								 * // count up amino Acids in the radius for (int l = 0; l < nameLength; l++) { AACounts[Integer.parseInt(nameString.substring(l, l + 1))]++; }
								 */
								// add to an array of amino acid availability
								Species currentSpecies = this.speciesList.get(gridValue - 1);
								if (currentSpecies.makesAA1())
								{
									AACounts[0][0] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA2())
								{
									AACounts[1][0] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA3())
								{
									AACounts[2][0] += this.KAAProduced / (double) this.possibleNeighbors;
								}

							}

						}

						// middle = middle + last - first;
						AACounts[0][1] += AACounts[0][2] - AACounts[0][0];
						AACounts[1][1] += AACounts[1][2] - AACounts[1][0];
						AACounts[2][1] += AACounts[2][2] - AACounts[2][0];
						for (int i = 0; i < this.numberOfSpecies; i++)
						{
							critterCounts[i][1] += critterCounts[i][2] - critterCounts[i][0];
						}

						AACounts[0][2] = 0;
						AACounts[1][2] = 0;
						AACounts[2][2] = 0;
						for (int i = 0; i < this.numberOfSpecies; i++)
						{
							critterCounts[i][2] = 0;
						}
						col2 = WrapAround.wrapAround(col + this.dispersalRadius, this.gridLength);
						for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
						{

							// counter++;
							int gridValue = this.env.getGridValue(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength));

							if (gridValue != 0)
							{
								// add to an array of conspecific critters
								critterCounts[gridValue - 1][2]++;

								/*
								 * String nameString = Integer.toString(this.speciesList.get(gridValue-1).getSpeciesName()); int nameLength = nameString.length();
								 * 
								 * // count up amino Acids in the radius for (int l = 0; l < nameLength; l++) { AACounts[Integer.parseInt(nameString.substring(l, l + 1))]++; }
								 */
								// add to an array of amino acid availability
								Species currentSpecies = this.speciesList.get(gridValue - 1);
								if (currentSpecies.makesAA1())
								{
									AACounts[0][2] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA2())
								{
									AACounts[1][2] += this.KAAProduced / (double) this.possibleNeighbors;
								}
								if (currentSpecies.makesAA3())
								{
									AACounts[2][2] += this.KAAProduced / (double) this.possibleNeighbors;
								}

							}

						}
						// birthProbs = getBirthProbabilities(AACounts, critterCounts);
					}

					// System.out.println(counter);
					// System.out.println(AACounts[0]);

					// for each critter determine the term of the birth probability that follows leibigs law of the minimum with respect to AA.
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						Species currentSpecies = this.speciesList.get(spp);
						double tempF = 1;
						if (!currentSpecies.makesAA1())
						{
							double aA1 = AACounts[0][0] + AACounts[0][1] + AACounts[0][2];
							if (aA1 / currentSpecies.getAA1K() < tempF)
							{
								tempF = aA1 / currentSpecies.getAA1K();
							}
						}

						if (!currentSpecies.makesAA2())
						{
							double aA2 = AACounts[1][0] + AACounts[1][1] + AACounts[1][2];
							if (aA2 / currentSpecies.getAA2K() < tempF)
							{
								tempF = aA2 / currentSpecies.getAA2K();
							}
						}

						if (!currentSpecies.makesAA3())
						{
							double aA3 = AACounts[2][0] + AACounts[2][1] + AACounts[2][2];

							if (aA3 / currentSpecies.getAA3K() < tempF)
							{
								tempF = aA3 / currentSpecies.getAA3K();
							}
						}

						int realCritterCount = 0;

						for (int i = 0; i < 3; i++)
						{
							realCritterCount += critterCounts[spp][i];
						}
						// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
						// are around to give birth
						birthProbs[spp] = currentSpecies.getCmax() * tempF * (realCritterCount / (double) this.possibleNeighbors);
					}

					// figure out which bacterium (if any) is going to give birth
					double theBirthProb = this.generator.nextDouble();
					double compareTo = 0;

					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						compareTo += birthProbs[spp];

						if (theBirthProb < compareTo)
						{
							toAddCritter.add(this.speciesList.get(spp).getGridProxy());
							toAddLocation.add(new Location(row, col));
							// this.env.add(new Location(row, col), this.speciesList.get(spp).getGridProxy());
							break;
						}

					}
				}
			}

		}

		// Exception thrower if critters and location get unsynchronized
		/*
		 * if (toAddLocation.size() != toAddCritter.size()) { IllegalStateException e = new IllegalStateException("critters and locations are unsynchronized"); throw e; }
		 */
		for (int i = 0; i < toRemove.size(); i++)
		{
			Location loc = toRemove.get(i);
			this.env.remove(loc.row(), loc.col());
		}
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location loc = toAddLocation.get(i);
			this.env.add(loc, toAddCritter.get(i));
		}
		this.timeStep++;
	}

	public double[] getBirthProbabilities(double[][] AACounts, int[][] critterCounts)
	{
		double[] birthProbs = new double[this.numberOfSpecies];
		for (int spp = 0; spp < this.numberOfSpecies; spp++)
		{
			Species currentSpecies = this.speciesList.get(spp);
			double tempF = 1;
			if (!currentSpecies.makesAA1())
			{
				double aA1 = AACounts[0][0] + AACounts[0][1] + AACounts[0][2];
				if (aA1 / currentSpecies.getAA1K() < tempF)
				{
					tempF = aA1 / currentSpecies.getAA1K();
				}
			}

			if (!currentSpecies.makesAA2())
			{
				double aA2 = AACounts[1][0] + AACounts[1][1] + AACounts[1][2];
				if (aA2 / currentSpecies.getAA2K() < tempF)
				{
					tempF = aA2 / currentSpecies.getAA2K();
				}
			}

			if (!currentSpecies.makesAA3())
			{
				double aA3 = AACounts[2][0] + AACounts[2][1] + AACounts[2][2];

				if (aA3 / currentSpecies.getAA3K() < tempF)
				{
					tempF = aA3 / currentSpecies.getAA3K();
				}
			}

			int realCritterCount = 0;
			for (int i = 0; i < 3; i++)
			{
				realCritterCount += critterCounts[spp][i];
			}
			// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
			// are around to give birth
			birthProbs[spp] = currentSpecies.getCmax() * tempF * (realCritterCount / (double) this.possibleNeighbors);

		}
		return birthProbs;
	}

	/*
	 * execute one time step where amino acid availibity directly affects adult fecundity. In turn, adult fecundity directly affects recruitment. The step function distinguishes between the distance at which species can ultilize/"suck up" amino acids, and the the distance at which propagules can be dispersed.
	 */
	public void step2()
	{
		checkForInoculations();

		// instantiate a stack of grids that gives the competitive values in each location of each species, respectively
		double[][][] compValuesMat = new double[this.gridLength][this.gridLength][this.numberOfSpecies];
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				double[] AACounts = new double[3];

				int critterValue = this.env.getGridValue(row, col);
				if (critterValue != 0)
				{
					// int counter = 0;
					// look in a square of "AAdispersalRadius" radius around the current row,col location
					for (int row2 = row - this.AADispersalRadius; row2 <= row + this.AADispersalRadius; row2++)
					{
						for (int col2 = col - this.AADispersalRadius; col2 <= col + this.AADispersalRadius; col2++)
						{

							int gridValue = this.env.getGridValue(WrapAround.wrapAround(row2, this.gridLength), WrapAround.wrapAround(col2, this.gridLength));

							if (gridValue != 0)
							{

								// add to an array of amino acid availability
								Species currentSpecies = this.speciesList.get(gridValue - 1);
								if (currentSpecies.makesAA1())
								{
									AACounts[0] += this.KAAProduced / (double) this.possibleAANeighbors;
								}
								if (currentSpecies.makesAA2())
								{
									AACounts[1] += this.KAAProduced / (double) this.possibleAANeighbors;
								}
								if (currentSpecies.makesAA3())
								{
									AACounts[2] += this.KAAProduced / (double) this.possibleAANeighbors;
								}

							}
						}
					}

					// for each critter determine the term of the birth probability that follows leibigs law of the minimum with respect to AA.

					Species currentSpecies = this.speciesList.get(critterValue - 1);
					double tempF = 1;
					if (!currentSpecies.makesAA1())
					{
						if (AACounts[0] / currentSpecies.getAA1K() < tempF)
						{
							tempF = AACounts[0] / currentSpecies.getAA1K();
						}
					}

					if (!currentSpecies.makesAA2())
					{
						if (AACounts[1] / currentSpecies.getAA2K() < tempF)
						{
							tempF = AACounts[1] / currentSpecies.getAA2K();
						}
					}

					if (!currentSpecies.makesAA3())
					{
						if (AACounts[2] / currentSpecies.getAA3K() < tempF)
						{
							tempF = AACounts[2] / currentSpecies.getAA3K();
						}
					}

					// this the realized birth probability based on maximum growth rate, amino acid availability, and how many neighbors
					//
					compValuesMat[row][col][critterValue - 1] = currentSpecies.getCmax() * tempF;

				}
			}
		}

		ArrayList<Location> toRemove = new ArrayList<Location>();
		ArrayList<Location> toAddLocation = new ArrayList<Location>();
		ArrayList<Integer> toAddCritter = new ArrayList<Integer>();

		// this second main determines who gives birth into empty site, depending on the cumulative realized birth rates within the dispersalRadius
		for (int row = 0; row < this.gridLength; row++)
		{
			for (int col = 0; col < this.gridLength; col++)
			{
				// if it's occupied, pull a random number to see if it dies
				if (this.env.isOccupied(row, col))
				{
					double deathProb = this.speciesList.get(this.env.getGridValue(row, col) - 1).getD();
					if (this.generator.nextDouble() < deathProb)
					{
						// index it to remove at the end of the time step
						toRemove.add(new Location(row, col));
					}
					// if it does die, go to the next row,col location
					continue;
				}
				else
				// if it's empty, enter birth process
				{
					double[] speciesCompValuesSum = new double[this.numberOfSpecies];
					for (int row2 = row - this.dispersalRadius; row2 <= row + this.dispersalRadius; row2++)
					{
						for (int col2 = col - this.dispersalRadius; col2 <= col + this.dispersalRadius; col2++)
						{
							int realRow = WrapAround.wrapAround(row2, this.gridLength);
							int realCol = WrapAround.wrapAround(col2, this.gridLength);

							for (int s = 0; s < this.numberOfSpecies; s++)
							{
								speciesCompValuesSum[s] += compValuesMat[realRow][realCol][s];
							}
						}
					}

					for (int s = 0; s < this.numberOfSpecies; s++)
					{
						speciesCompValuesSum[s] /= this.possibleNeighbors;
					}
					double theBirthProb = this.generator.nextDouble();
					double compareTo = 0;
					for (int spp = 0; spp < this.numberOfSpecies; spp++)
					{
						compareTo += speciesCompValuesSum[spp];

						if (theBirthProb < compareTo)
						{
							toAddCritter.add(this.speciesList.get(spp).getGridProxy());
							toAddLocation.add(new Location(row, col));
							break;
						}

					}

				}
			}
		}

		// Exception thrower if critters and location get unsynchronized
		/*
		 * if (toAddLocation.size() != toAddCritter.size()) { IllegalStateException e = new IllegalStateException("critters and locations are unsynchronized"); throw e; }
		 */

		// deaths
		for (int i = 0; i < toRemove.size(); i++)
		{
			Location loc = toRemove.get(i);
			this.env.remove(loc.row(), loc.col());
		}
		// births
		for (int i = 0; i < toAddLocation.size(); i++)
		{
			Location loc = toAddLocation.get(i);
			this.env.add(loc, toAddCritter.get(i));
		}
		this.timeStep++;
	}

	/**
	 * Generates time series data over a specified number of time steps, at a specified resolution.
	 * 
	 * @param numSteps the time series is recorded over this many time steps
	 * @param measureHowOften abundances are recorded once every this time steps
	 * @return an two dimensional [species][time] array of abundances
	 */
	public double[][] timeSeries(int numSteps, int measureHowOften, boolean reportDensity)
	{

		double[][] abundanceArray = new double[(numSteps / measureHowOften) + 1][this.numberOfSpecies];
		int counter = 0;

		// get abudances at time zero
		double[] currentAbundances = getAbundances(reportDensity);
		for (int i = 0; i < currentAbundances.length; i++)
		{
			abundanceArray[counter][i] = currentAbundances[i];
		}
		counter++;

		for (int s = 1; s < numSteps + 1; s++)
		{

			step();
			// scatter();

			// get abundances every so often
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = getAbundances(reportDensity);
				// System.out.println("the time step is:" + s);

				for (int i = 0; i < currentAbundances.length; i++)
				{
					abundanceArray[counter][i] = currentAbundances[i];
				}
				counter++;
			}
		}
		return abundanceArray;
	}

	/**
	 * Generates time series data over a specified number of time steps, at a specified resolution.
	 * 
	 * @param numSteps the time series is recorded over this many time steps
	 * @param measureHowOften abundances are recorded once every this time steps
	 * @return an two dimensional [species][time] array of abundances
	 */
	public double[][] timeSeries(int start, int end, int measureHowOften, boolean reportDensity)
	{
		int numSteps = end - start;
		double[][] abundanceArray = new double[(numSteps / measureHowOften) + 1][this.numberOfSpecies];
		int counter = 0;
		int s = 1;
		for (; s <= start; s++)
		{
			step();
		}

		double[] currentAbundances = getAbundances(reportDensity);

		for (int i = 0; i < currentAbundances.length; i++)
		{
			abundanceArray[counter][i] = currentAbundances[i];
		}
		counter++;

		for (; s <= end; s++)
		{
			step();
			// scatter();
			if ((s % measureHowOften == 0) && (s / measureHowOften != 0))
			{
				currentAbundances = getAbundances(reportDensity);
				for (int i = 0; i < currentAbundances.length; i++)
				{
					abundanceArray[counter][i] = currentAbundances[i];
				}
				counter++;
			}
		}
		return abundanceArray;
	}

}
