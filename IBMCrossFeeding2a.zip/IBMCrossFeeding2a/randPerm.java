import java.util.Random;


public class randPerm
{
	private static int len = 10;
	private static Random generator = new Random();
	public static void main(String[] args)
	{
		int[] ar = new int[len];
		for(int i = 0; i < len; i++)
		{
			ar[i] = i;
		}
		
		for(int i = 0; i < 5; i++)
		{
			int num = generator.nextInt(len-i);
			int temp = ar[num]; 
			ar[num] = ar[len-1-i];
			ar[len-1-i] = temp;
		}
		
		for(int i = 0; i < len; i++)
		{
			System.out.println(ar[i]);
		}
		
		
		/*int newAr = new int[len]	
		for(int i = 0; i < len-1; i++)
		{
			int num = generator.nextInt(len-i);

		}*/
		
		

	}

}
