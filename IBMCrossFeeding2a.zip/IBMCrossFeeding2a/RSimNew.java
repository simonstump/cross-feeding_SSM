import java.util.ArrayList;

public class RSimNew
{
	public static double[] measureStuff(int numMeasurements, int timeBetweenMeasurements, double tooLow, double tooHigh, int inoculateWhen, int stepsAfterInoculation, double dt, int gridLength,
			int AADispersalRadius, int dispersalRadius, double KAAProduced, double death, double initCMaxCheat, double deltaB0, double cMaxSyn1, double cMaxSyn2, boolean useStep2, double initProp0,
			double AA1Kx0, double AA2Kx0, double AA1Kx1, double AA2Kx1, double AA1Kx2, double AA2Kx2)
	{
		double[] toReturn = new double[57];
		double cmax0 = initCMaxCheat;

		double L0 = 0;
		double L1 = 0;
		double L2 = 0;
		double covfCE0 = 0;
		double covfCE1 = 0;
		double covfCE2 = 0;
		double deltaOverB1 = 0;
		double deltaOverB2 = 0;
		double covFitnessDensity1 = 0;
		double covFitnessDensity2 = 0;
		double covEmptySiteDensity1 = 0;
		double covEmptySiteDensity2 = 0;
		double covFCDensity1 = 0;
		double covFCDensity2 = 0;
		double covKN1LocalBarDensity2 = 0;
		double covKN2LocalBarDensity1 = 0;

		double L0After = 0;
		double L1After = 0;
		double L2After = 0;
		double covfCE0After = 0;
		double covfCE1After = 0;
		double covfCE2After = 0;
		double covFitnessDensity0After = 0;
		double covFitnessDensity1After = 0;
		double covFitnessDensity2After = 0;
		double covEmptySiteDensity0After = 0;
		double covEmptySiteDensity1After = 0;
		double covEmptySiteDensity2After = 0;
		double covFCDensity0After = 0;
		double covFCDensity1After = 0;
		double covFCDensity2After = 0;
		double covKN1LocalBarDensity2After = 0;
		double covKN2LocalBarDensity1After = 0;
		double covKN1LocalBarDensity0After = 0;
		double covKN2LocalBarDensity0After = 0;
		double b0After = 0;
		double N0After = 0;

		double L0AfterInvasion = 0;
		double L1AfterInvasion = 0;
		double L2AfterInvasion = 0;
		double covfCE0AfterInvasion = 0;
		double covfCE1AfterInvasion = 0;
		double covfCE2AfterInvasion = 0;
		double covFitnessDensity0AfterInvasion = 0;
		double covFitnessDensity1AfterInvasion = 0;
		double covFitnessDensity2AfterInvasion = 0;
		double covEmptySiteDensity0AfterInvasion = 0;
		double covEmptySiteDensity1AfterInvasion = 0;
		double covEmptySiteDensity2AfterInvasion = 0;
		double covFCDensity0AfterInvasion = 0;
		double covFCDensity1AfterInvasion = 0;
		double covFCDensity2AfterInvasion = 0;
		double covKN1LocalBarDensity2AfterInvasion = 0;
		double covKN2LocalBarDensity1AfterInvasion = 0;
		double covKN1LocalBarDensity0AfterInvasion = 0;
		double covKN2LocalBarDensity0AfterInvasion = 0;
		double N0AfterInvasion = 0;

		while (true)
		{

			System.out.println("b0 is " + cmax0);
			ArrayList<Species> speciesList = new ArrayList<Species>();

			speciesList.add(new Species(0, abundFromProp(initProp0, gridLength), cmax0, death, inoculateWhen, false, false, false, AA1Kx0, AA2Kx0, 0));

			speciesList.add(new Species(1, abundFromProp(0.45, gridLength), cMaxSyn1, death, 0, true, false, false, AA1Kx1, AA2Kx1, 0));

			speciesList.add(new Species(2, abundFromProp(0.45, gridLength), cMaxSyn2, death, 0, false, true, false, AA1Kx2, AA2Kx2, 0));

			Community refCom = new Community(gridLength, dt, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
			refCom.step(inoculateWhen);
			Community tempCom = new Community(refCom);
			refCom.neverInoculate();

			boolean done = false;

			double[] tempabunds = refCom.getAbundances(true);
			System.out.println("Syntrophs abundance is" + tempabunds[1]);
			if (tempabunds[1] < .001)
			{
				done = false;
				System.out.println("Syntrophs are dead, long live the syntrophs!");
				
				for(int ii = 0; ii < 57; ii ++)
				{
					toReturn[ii]=-42;
				}

				return toReturn;
				
				//break;
			
			}
			
			for (int t = 0; t < 3; t++)
			{
				boolean cheaterDied = false;
				tempCom = new Community(refCom);

				while (tempCom.getTimeStep() != stepsAfterInoculation)
				{

					// take one step to inoculate
					tempCom.step();

					if (tempCom.getAbundances(false)[0] == 0)
					{
						cheaterDied = true;
						break;
					}
				}
				if (cheaterDied)
				{
					continue;
				}
				else if (tempCom.getAbundances(true)[0] > initProp0)
				{

					done = true;
					break;

				}

			}

			if (done)
			{
				// make a carbon copy of the temporary community (the community with the cheater).
				Community invasionCom = new Community(tempCom);
				// step once to inoculate the cheater
				/*
				 * tempCom.step(); invasionCom.step();
				 */

				// take the sum (over time) of metrics in the reference community (no cheater), the tempCom (the community with the unabated cheater), and the invasion community (where the cehater is kept at low density).
				for (int m = 0; m < numMeasurements; m++)
				{
					refCom.step(timeBetweenMeasurements);
					L0 += refCom.getL(speciesList.get(0));
					L1 += refCom.getL(speciesList.get(1));
					L2 += refCom.getL(speciesList.get(2));
					covfCE0 += refCom.getfCEmptySiteCov(speciesList.get(0));
					covfCE1 += refCom.getfCEmptySiteCov(speciesList.get(1));
					covfCE2 += refCom.getfCEmptySiteCov(speciesList.get(2));
					deltaOverB1 += death / cMaxSyn1;
					deltaOverB2 += death / cMaxSyn2;
					covFitnessDensity1 += refCom.getFitnessDensityCovariance(speciesList.get(1));
					covFitnessDensity2 += refCom.getFitnessDensityCovariance(speciesList.get(2));
					covEmptySiteDensity1 += refCom.getEmptySiteDensityCovariance(speciesList.get(1));
					covEmptySiteDensity2 += refCom.getEmptySiteDensityCovariance(speciesList.get(2));
					covFCDensity1 += refCom.getFCDensityCovariance(speciesList.get(1));
					covFCDensity2 += refCom.getFCDensityCovariance(speciesList.get(2));
					covKN1LocalBarDensity2 += refCom.getKNBar1DensityCovariance(speciesList.get(2));
					covKN2LocalBarDensity1 += refCom.getKNBar2DensityCovariance(speciesList.get(1));

					tempCom.step(timeBetweenMeasurements);

					L0After += tempCom.getL(speciesList.get(0));
					L1After += tempCom.getL(speciesList.get(1));
					L2After += tempCom.getL(speciesList.get(2));
					covfCE0After += tempCom.getfCEmptySiteCov(speciesList.get(0));
					covfCE1After += tempCom.getfCEmptySiteCov(speciesList.get(1));
					covfCE2After += tempCom.getfCEmptySiteCov(speciesList.get(2));
					covFitnessDensity0After += tempCom.getFitnessDensityCovariance(speciesList.get(0));
					covFitnessDensity1After += tempCom.getFitnessDensityCovariance(speciesList.get(1));
					covFitnessDensity2After += tempCom.getFitnessDensityCovariance(speciesList.get(2));
					covEmptySiteDensity0After += tempCom.getEmptySiteDensityCovariance(speciesList.get(0));
					covEmptySiteDensity1After += tempCom.getEmptySiteDensityCovariance(speciesList.get(1));
					covEmptySiteDensity2After += tempCom.getEmptySiteDensityCovariance(speciesList.get(2));
					covFCDensity0After += tempCom.getFCDensityCovariance(speciesList.get(0));
					covFCDensity1After += tempCom.getFCDensityCovariance(speciesList.get(1));
					covFCDensity2After += tempCom.getFCDensityCovariance(speciesList.get(2));
					covKN1LocalBarDensity0After += tempCom.getKNBar1DensityCovariance(speciesList.get(0));
					covKN2LocalBarDensity0After += tempCom.getKNBar2DensityCovariance(speciesList.get(0));
					covKN1LocalBarDensity2After += tempCom.getKNBar1DensityCovariance(speciesList.get(2));
					covKN2LocalBarDensity1After += tempCom.getKNBar2DensityCovariance(speciesList.get(1));
					b0After += cmax0;
					N0After += tempCom.getAbundances(true)[0];

					for (int step = 0; step < timeBetweenMeasurements; step++)
					{
						invasionCom.step();
						invasionCom.invaderCheck(speciesList.get(0), tooLow, tooHigh);
					}

					L0AfterInvasion += invasionCom.getL(speciesList.get(0));
					L1AfterInvasion += invasionCom.getL(speciesList.get(1));
					L2AfterInvasion += invasionCom.getL(speciesList.get(2));
					covfCE0AfterInvasion += invasionCom.getfCEmptySiteCov(speciesList.get(0));
					covfCE1AfterInvasion += invasionCom.getfCEmptySiteCov(speciesList.get(1));
					covfCE2AfterInvasion += invasionCom.getfCEmptySiteCov(speciesList.get(2));
					covFitnessDensity0AfterInvasion += invasionCom.getFitnessDensityCovariance(speciesList.get(0));
					covFitnessDensity1AfterInvasion += invasionCom.getFitnessDensityCovariance(speciesList.get(1));
					covFitnessDensity2AfterInvasion += invasionCom.getFitnessDensityCovariance(speciesList.get(2));
					covEmptySiteDensity0AfterInvasion += invasionCom.getEmptySiteDensityCovariance(speciesList.get(0));
					covEmptySiteDensity1AfterInvasion += invasionCom.getEmptySiteDensityCovariance(speciesList.get(1));
					covEmptySiteDensity2AfterInvasion += invasionCom.getEmptySiteDensityCovariance(speciesList.get(2));
					covFCDensity0AfterInvasion += invasionCom.getFCDensityCovariance(speciesList.get(0));
					covFCDensity1AfterInvasion += invasionCom.getFCDensityCovariance(speciesList.get(1));
					covFCDensity2AfterInvasion += invasionCom.getFCDensityCovariance(speciesList.get(2));
					covKN1LocalBarDensity0AfterInvasion += invasionCom.getKNBar1DensityCovariance(speciesList.get(0));
					covKN2LocalBarDensity0AfterInvasion += invasionCom.getKNBar2DensityCovariance(speciesList.get(0));
					covKN1LocalBarDensity2AfterInvasion += invasionCom.getKNBar1DensityCovariance(speciesList.get(2));
					covKN2LocalBarDensity1AfterInvasion += invasionCom.getKNBar2DensityCovariance(speciesList.get(1));
					N0AfterInvasion += invasionCom.getAbundances(true)[0];

				}

				// / get the average.
				toReturn[0] = L0 / (double) numMeasurements;
				toReturn[1] = L1 / (double) numMeasurements;
				toReturn[2] = L2 / (double) numMeasurements;
				toReturn[3] = covfCE0 / (double) numMeasurements;
				toReturn[4] = covfCE1 / (double) numMeasurements;
				toReturn[5] = covfCE2 / (double) numMeasurements;
				toReturn[6] = deltaOverB1 / (double) numMeasurements;
				toReturn[7] = deltaOverB2 / (double) numMeasurements;
				toReturn[8] = covFitnessDensity1 / (double) numMeasurements;
				toReturn[9] = covFitnessDensity2 / (double) numMeasurements;
				toReturn[10] = covEmptySiteDensity1 / (double) numMeasurements;
				toReturn[11] = covEmptySiteDensity2 / (double) numMeasurements;
				toReturn[12] = covFCDensity1 / (double) numMeasurements;
				toReturn[13] = covFCDensity2 / (double) numMeasurements;
				toReturn[14] = covKN1LocalBarDensity2 / (double) numMeasurements;
				toReturn[15] = covKN2LocalBarDensity1 / (double) numMeasurements;

				toReturn[16] = L0After / (double) numMeasurements;
				toReturn[17] = L1After / (double) numMeasurements;
				toReturn[18] = L2After / (double) numMeasurements;
				toReturn[19] = covfCE0After / (double) numMeasurements;
				toReturn[20] = covfCE1After / (double) numMeasurements;
				toReturn[21] = covfCE2After / (double) numMeasurements;
				toReturn[22] = covFitnessDensity0After / (double) numMeasurements;
				toReturn[23] = covFitnessDensity1After / (double) numMeasurements;
				toReturn[24] = covFitnessDensity2After / (double) numMeasurements;
				toReturn[25] = covEmptySiteDensity0After / (double) numMeasurements;
				toReturn[26] = covEmptySiteDensity1After / (double) numMeasurements;
				toReturn[27] = covEmptySiteDensity2After / (double) numMeasurements;
				toReturn[28] = covFCDensity0After / (double) numMeasurements;
				toReturn[29] = covFCDensity1After / (double) numMeasurements;
				toReturn[30] = covFCDensity2After / (double) numMeasurements;
				toReturn[31] = covKN1LocalBarDensity2After / (double) numMeasurements;
				toReturn[32] = covKN2LocalBarDensity1After / (double) numMeasurements;
				toReturn[33] = covKN1LocalBarDensity0After / (double) numMeasurements;
				toReturn[34] = covKN2LocalBarDensity0After / (double) numMeasurements;
				toReturn[35] = b0After / (double) numMeasurements;
				toReturn[36] = N0After / (double) numMeasurements;

				toReturn[37] = L0AfterInvasion / (double) numMeasurements;
				toReturn[38] = L1AfterInvasion / (double) numMeasurements;
				toReturn[39] = L2AfterInvasion / (double) numMeasurements;
				toReturn[40] = covfCE0AfterInvasion / (double) numMeasurements;
				toReturn[41] = covfCE1AfterInvasion / (double) numMeasurements;
				toReturn[42] = covfCE2AfterInvasion / (double) numMeasurements;
				toReturn[43] = covFitnessDensity0AfterInvasion / (double) numMeasurements;
				toReturn[44] = covFitnessDensity1AfterInvasion / (double) numMeasurements;
				toReturn[45] = covFitnessDensity2AfterInvasion / (double) numMeasurements;
				toReturn[46] = covEmptySiteDensity0AfterInvasion / (double) numMeasurements;
				toReturn[47] = covEmptySiteDensity1AfterInvasion / (double) numMeasurements;
				toReturn[48] = covEmptySiteDensity2AfterInvasion / (double) numMeasurements;
				toReturn[49] = covFCDensity0AfterInvasion / (double) numMeasurements;
				toReturn[50] = covFCDensity1AfterInvasion / (double) numMeasurements;
				toReturn[51] = covFCDensity2AfterInvasion / (double) numMeasurements;
				toReturn[52] = covKN1LocalBarDensity2AfterInvasion / (double) numMeasurements;
				toReturn[53] = covKN2LocalBarDensity1AfterInvasion / (double) numMeasurements;
				toReturn[54] = covKN1LocalBarDensity0AfterInvasion / (double) numMeasurements;
				toReturn[55] = covKN2LocalBarDensity0AfterInvasion / (double) numMeasurements;
				toReturn[56] = N0AfterInvasion / (double) numMeasurements;

				// / tempCom.measure stuff
				break;
			}
			else
			{
				// if the cheater hasn't been able to invade yet and the program tries to give it a better-than-perfect birth rate, then throw an exception
				cmax0 += deltaB0;
				if (cmax0 > 1)
				{
					throw new IllegalStateException("can't have a birth rate over 1");
				}

			}

		}

		return toReturn;

	}

	public static double[] measureStuffTuring(int numMeasurements, int timeBetweenMeasurements, double tooLow, double tooHigh, int inoculateWhen, int stepsAfterInoculation, double dt, int gridLength,
			int AADispersalRadius, int dispersalRadius, double KAAProduced, double death, double initCMaxCheat, double deltaB0, double cMaxSyn1, double cMaxSyn2, boolean useStep2, double initProp0,
			double AA1Kx0, double AA2Kx0, double AA1Kx1, double AA2Kx1, double AA1Kx2, double AA2Kx2)
	{
		double[] toReturn = new double[57];
		double cmax0 = initCMaxCheat;

		double L0 = 0;
		double L1 = 0;
		double L2 = 0;
		double covfCE0 = 0;
		double covfCE1 = 0;
		double covfCE2 = 0;
		double deltaOverB1 = 0;
		double deltaOverB2 = 0;
		double covFitnessDensity1 = 0;
		double covFitnessDensity2 = 0;
		double covEmptySiteDensity1 = 0;
		double covEmptySiteDensity2 = 0;
		double covFCDensity1 = 0;
		double covFCDensity2 = 0;
		double covKN1LocalBarDensity2 = 0;
		double covKN2LocalBarDensity1 = 0;

		double L0After = 0;
		double L1After = 0;
		double L2After = 0;
		double covfCE0After = 0;
		double covfCE1After = 0;
		double covfCE2After = 0;
		double covFitnessDensity0After = 0;
		double covFitnessDensity1After = 0;
		double covFitnessDensity2After = 0;
		double covEmptySiteDensity0After = 0;
		double covEmptySiteDensity1After = 0;
		double covEmptySiteDensity2After = 0;
		double covFCDensity0After = 0;
		double covFCDensity1After = 0;
		double covFCDensity2After = 0;
		double covKN1LocalBarDensity2After = 0;
		double covKN2LocalBarDensity1After = 0;
		double covKN1LocalBarDensity0After = 0;
		double covKN2LocalBarDensity0After = 0;
		double b0After = 0;
		double N0After = 0;

		double L0AfterInvasion = 0;
		double L1AfterInvasion = 0;
		double L2AfterInvasion = 0;
		double covfCE0AfterInvasion = 0;
		double covfCE1AfterInvasion = 0;
		double covfCE2AfterInvasion = 0;
		double covFitnessDensity0AfterInvasion = 0;
		double covFitnessDensity1AfterInvasion = 0;
		double covFitnessDensity2AfterInvasion = 0;
		double covEmptySiteDensity0AfterInvasion = 0;
		double covEmptySiteDensity1AfterInvasion = 0;
		double covEmptySiteDensity2AfterInvasion = 0;
		double covFCDensity0AfterInvasion = 0;
		double covFCDensity1AfterInvasion = 0;
		double covFCDensity2AfterInvasion = 0;
		double covKN1LocalBarDensity2AfterInvasion = 0;
		double covKN2LocalBarDensity1AfterInvasion = 0;
		double covKN1LocalBarDensity0AfterInvasion = 0;
		double covKN2LocalBarDensity0AfterInvasion = 0;
		double N0AfterInvasion = 0;

		
			System.out.println("b0 is " + cmax0);
			ArrayList<Species> speciesList = new ArrayList<Species>();

			speciesList.add(new Species(0, abundFromProp(initProp0, gridLength), cmax0, death, inoculateWhen, false, false, false, AA1Kx0, AA2Kx0, 0));

			speciesList.add(new Species(1, abundFromProp(0.30, gridLength), cMaxSyn1, death, 0, true, false, false, AA1Kx1, AA2Kx1, 0));

			speciesList.add(new Species(2, abundFromProp(0.30, gridLength), cMaxSyn2, death, 0, false, true, false, AA1Kx2, AA2Kx2, 0));

			Community refCom = new Community(gridLength, dt, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
			Community tempCom = new Community(refCom);
			System.out.println("got past community construction...");
			refCom.step();
			refCom.neverInoculate();
			System.out.println("got past never inoculate");
			refCom.step(stepsAfterInoculation);
			// take one step to inoculate
			tempCom.step(inoculateWhen + stepsAfterInoculation);

			// make a carbon copy of the temporary community (the community with the cheater).
			Community invasionCom = new Community(tempCom);
			// step once to inoculate the cheater
			/*
			 * tempCom.step(); invasionCom.step();
			 */
			
			System.out.println("got to measurements...");

			// take the sum (over time) of metrics in the reference community (no cheater), the tempCom (the community with the unabated cheater), and the invasion community (where the cehater is kept at low density).
			for (int m = 0; m < numMeasurements; m++)
			{
				refCom.step(timeBetweenMeasurements);
				L0 += refCom.getL(speciesList.get(0));
				L1 += refCom.getL(speciesList.get(1));
				L2 += refCom.getL(speciesList.get(2));
				covfCE0 += refCom.getfCEmptySiteCov(speciesList.get(0));
				covfCE1 += refCom.getfCEmptySiteCov(speciesList.get(1));
				covfCE2 += refCom.getfCEmptySiteCov(speciesList.get(2));
				deltaOverB1 += death / cMaxSyn1;
				deltaOverB2 += death / cMaxSyn2;
				covFitnessDensity1 += refCom.getFitnessDensityCovariance(speciesList.get(1));
				covFitnessDensity2 += refCom.getFitnessDensityCovariance(speciesList.get(2));
				covEmptySiteDensity1 += refCom.getEmptySiteDensityCovariance(speciesList.get(1));
				covEmptySiteDensity2 += refCom.getEmptySiteDensityCovariance(speciesList.get(2));
				covFCDensity1 += refCom.getFCDensityCovariance(speciesList.get(1));
				covFCDensity2 += refCom.getFCDensityCovariance(speciesList.get(2));
				covKN1LocalBarDensity2 += refCom.getKNBar1DensityCovariance(speciesList.get(2));
				covKN2LocalBarDensity1 += refCom.getKNBar2DensityCovariance(speciesList.get(1));
				System.out.println("got past refcom measurements. rep " + (m+1));
				
				tempCom.step(timeBetweenMeasurements);

				L0After += tempCom.getL(speciesList.get(0));
				L1After += tempCom.getL(speciesList.get(1));
				L2After += tempCom.getL(speciesList.get(2));
				covfCE0After += tempCom.getfCEmptySiteCov(speciesList.get(0));
				covfCE1After += tempCom.getfCEmptySiteCov(speciesList.get(1));
				covfCE2After += tempCom.getfCEmptySiteCov(speciesList.get(2));
				covFitnessDensity0After += tempCom.getFitnessDensityCovariance(speciesList.get(0));
				covFitnessDensity1After += tempCom.getFitnessDensityCovariance(speciesList.get(1));
				covFitnessDensity2After += tempCom.getFitnessDensityCovariance(speciesList.get(2));
				covEmptySiteDensity0After += tempCom.getEmptySiteDensityCovariance(speciesList.get(0));
				covEmptySiteDensity1After += tempCom.getEmptySiteDensityCovariance(speciesList.get(1));
				covEmptySiteDensity2After += tempCom.getEmptySiteDensityCovariance(speciesList.get(2));
				covFCDensity0After += tempCom.getFCDensityCovariance(speciesList.get(0));
				covFCDensity1After += tempCom.getFCDensityCovariance(speciesList.get(1));
				covFCDensity2After += tempCom.getFCDensityCovariance(speciesList.get(2));
				covKN1LocalBarDensity0After += tempCom.getKNBar1DensityCovariance(speciesList.get(0));
				covKN2LocalBarDensity0After += tempCom.getKNBar2DensityCovariance(speciesList.get(0));
				covKN1LocalBarDensity2After += tempCom.getKNBar1DensityCovariance(speciesList.get(2));
				covKN2LocalBarDensity1After += tempCom.getKNBar2DensityCovariance(speciesList.get(1));
				b0After += cmax0;
				N0After += tempCom.getAbundances(true)[0];
				System.out.println("got past tempcom measurements. rep " + (m+1));

				for (int step = 0; step < timeBetweenMeasurements; step++)
				{
					invasionCom.step();
					invasionCom.invaderCheck(speciesList.get(0), tooLow, tooHigh);
					System.out.println("invasionCom step "+ (step + 1));
				}
				System.out.println("got past invasionCom step");

				L0AfterInvasion += invasionCom.getL(speciesList.get(0));
				L1AfterInvasion += invasionCom.getL(speciesList.get(1));
				L2AfterInvasion += invasionCom.getL(speciesList.get(2));
				covfCE0AfterInvasion += invasionCom.getfCEmptySiteCov(speciesList.get(0));
				covfCE1AfterInvasion += invasionCom.getfCEmptySiteCov(speciesList.get(1));
				covfCE2AfterInvasion += invasionCom.getfCEmptySiteCov(speciesList.get(2));
				covFitnessDensity0AfterInvasion += invasionCom.getFitnessDensityCovariance(speciesList.get(0));
				covFitnessDensity1AfterInvasion += invasionCom.getFitnessDensityCovariance(speciesList.get(1));
				covFitnessDensity2AfterInvasion += invasionCom.getFitnessDensityCovariance(speciesList.get(2));
				covEmptySiteDensity0AfterInvasion += invasionCom.getEmptySiteDensityCovariance(speciesList.get(0));
				covEmptySiteDensity1AfterInvasion += invasionCom.getEmptySiteDensityCovariance(speciesList.get(1));
				covEmptySiteDensity2AfterInvasion += invasionCom.getEmptySiteDensityCovariance(speciesList.get(2));
				covFCDensity0AfterInvasion += invasionCom.getFCDensityCovariance(speciesList.get(0));
				covFCDensity1AfterInvasion += invasionCom.getFCDensityCovariance(speciesList.get(1));
				covFCDensity2AfterInvasion += invasionCom.getFCDensityCovariance(speciesList.get(2));
				covKN1LocalBarDensity0AfterInvasion += invasionCom.getKNBar1DensityCovariance(speciesList.get(0));
				covKN2LocalBarDensity0AfterInvasion += invasionCom.getKNBar2DensityCovariance(speciesList.get(0));
				covKN1LocalBarDensity2AfterInvasion += invasionCom.getKNBar1DensityCovariance(speciesList.get(2));
				covKN2LocalBarDensity1AfterInvasion += invasionCom.getKNBar2DensityCovariance(speciesList.get(1));
				N0AfterInvasion += invasionCom.getAbundances(true)[0];
				System.out.println("got past invasioncom measurements. rep " + (m+1));


			}

			// / get the average.
			toReturn[0] = L0 / (double) numMeasurements;
			toReturn[1] = L1 / (double) numMeasurements;
			toReturn[2] = L2 / (double) numMeasurements;
			toReturn[3] = covfCE0 / (double) numMeasurements;
			toReturn[4] = covfCE1 / (double) numMeasurements;
			toReturn[5] = covfCE2 / (double) numMeasurements;
			toReturn[6] = deltaOverB1 / (double) numMeasurements;
			toReturn[7] = deltaOverB2 / (double) numMeasurements;
			toReturn[8] = covFitnessDensity1 / (double) numMeasurements;
			toReturn[9] = covFitnessDensity2 / (double) numMeasurements;
			toReturn[10] = covEmptySiteDensity1 / (double) numMeasurements;
			toReturn[11] = covEmptySiteDensity2 / (double) numMeasurements;
			toReturn[12] = covFCDensity1 / (double) numMeasurements;
			toReturn[13] = covFCDensity2 / (double) numMeasurements;
			toReturn[14] = covKN1LocalBarDensity2 / (double) numMeasurements;
			toReturn[15] = covKN2LocalBarDensity1 / (double) numMeasurements;

			toReturn[16] = L0After / (double) numMeasurements;
			toReturn[17] = L1After / (double) numMeasurements;
			toReturn[18] = L2After / (double) numMeasurements;
			toReturn[19] = covfCE0After / (double) numMeasurements;
			toReturn[20] = covfCE1After / (double) numMeasurements;
			toReturn[21] = covfCE2After / (double) numMeasurements;
			toReturn[22] = covFitnessDensity0After / (double) numMeasurements;
			toReturn[23] = covFitnessDensity1After / (double) numMeasurements;
			toReturn[24] = covFitnessDensity2After / (double) numMeasurements;
			toReturn[25] = covEmptySiteDensity0After / (double) numMeasurements;
			toReturn[26] = covEmptySiteDensity1After / (double) numMeasurements;
			toReturn[27] = covEmptySiteDensity2After / (double) numMeasurements;
			toReturn[28] = covFCDensity0After / (double) numMeasurements;
			toReturn[29] = covFCDensity1After / (double) numMeasurements;
			toReturn[30] = covFCDensity2After / (double) numMeasurements;
			toReturn[31] = covKN1LocalBarDensity2After / (double) numMeasurements;
			toReturn[32] = covKN2LocalBarDensity1After / (double) numMeasurements;
			toReturn[33] = covKN1LocalBarDensity0After / (double) numMeasurements;
			toReturn[34] = covKN2LocalBarDensity0After / (double) numMeasurements;
			toReturn[35] = b0After / (double) numMeasurements;
			toReturn[36] = N0After / (double) numMeasurements;

			toReturn[37] = L0AfterInvasion / (double) numMeasurements;
			toReturn[38] = L1AfterInvasion / (double) numMeasurements;
			toReturn[39] = L2AfterInvasion / (double) numMeasurements;
			toReturn[40] = covfCE0AfterInvasion / (double) numMeasurements;
			toReturn[41] = covfCE1AfterInvasion / (double) numMeasurements;
			toReturn[42] = covfCE2AfterInvasion / (double) numMeasurements;
			toReturn[43] = covFitnessDensity0AfterInvasion / (double) numMeasurements;
			toReturn[44] = covFitnessDensity1AfterInvasion / (double) numMeasurements;
			toReturn[45] = covFitnessDensity2AfterInvasion / (double) numMeasurements;
			toReturn[46] = covEmptySiteDensity0AfterInvasion / (double) numMeasurements;
			toReturn[47] = covEmptySiteDensity1AfterInvasion / (double) numMeasurements;
			toReturn[48] = covEmptySiteDensity2AfterInvasion / (double) numMeasurements;
			toReturn[49] = covFCDensity0AfterInvasion / (double) numMeasurements;
			toReturn[50] = covFCDensity1AfterInvasion / (double) numMeasurements;
			toReturn[51] = covFCDensity2AfterInvasion / (double) numMeasurements;
			toReturn[52] = covKN1LocalBarDensity2AfterInvasion / (double) numMeasurements;
			toReturn[53] = covKN2LocalBarDensity1AfterInvasion / (double) numMeasurements;
			toReturn[54] = covKN1LocalBarDensity0AfterInvasion / (double) numMeasurements;
			toReturn[55] = covKN2LocalBarDensity0AfterInvasion / (double) numMeasurements;
			toReturn[56] = N0AfterInvasion / (double) numMeasurements;

		return toReturn;
	}

	/**
	 * A helper method that takes a proportion of microsite (specified in measureStuff declaration), and turns it into an integer number of microsites. 
	 * @param prop
	 * @param gridLength
	 * @return
	 */
	public static int abundFromProp(double prop, int gridLength)
	{
		return (int) Math.round(prop * (double) Math.pow(gridLength, 2));
	}

	public static Community measureStuffCommunity(int numMeasurements, int timeBetweenMeasurements, double tooLow, double tooHigh, int inoculateWhen, int stepsAfterInoculation, double dt,
			int gridLength, int AADispersalRadius, int dispersalRadius, double KAAProduced, double death, double initCMaxCheat, double deltaB0, double cMaxSyn1, double cMaxSyn2, boolean useStep2,
			double initProp0, double AA1Kx0, double AA2Kx0, double AA1Kx1, double AA2Kx1, double AA1Kx2, double AA2Kx2)
	{
		double cmax0 = initCMaxCheat;
		ArrayList<Species> speciesList = new ArrayList<Species>();

		speciesList.add(new Species(0, abundFromProp(initProp0, gridLength), cmax0, death, inoculateWhen, false, false, false, AA1Kx0, AA2Kx0, 0));

		speciesList.add(new Species(1, abundFromProp(0.30, gridLength), cMaxSyn1, death, 0, true, false, false, AA1Kx1, AA2Kx1, 0));

		speciesList.add(new Species(2, abundFromProp(0.30, gridLength), cMaxSyn2, death, 0, false, true, false, AA1Kx2, AA2Kx2, 0));

		Community refCom = new Community(gridLength, dt, dispersalRadius, AADispersalRadius, KAAProduced, useStep2, speciesList);
		return refCom;
	}

}
