
/**
 * @author Evan
 *
 */
public class Species
{
	
	/**
	 * 
	 */
	private int speciesName;
	private  int initialAbundance;
	private  double cmax;
	private  double d;
	//private  int dispersalRadius;
	private  boolean makesAA1;
	private  boolean makesAA2;
	private  boolean makesAA3;
	private  double AA1K;
	private  double AA2K;
	private  double AA3K; 
	private  int gridProxy;
	private int inoculateWhen;
	private boolean inoculateOverwrite;
	

	/**
	 * A species object ontains information that lets the simulation methods know how to treat individuals.
	 * Importantly, a species object knows nothing about the location or number of individuals.
	 * 
	 * @param speciesName1 an identifier that is included for our convenience. My convention is to name the species in terms of the amino acids they make, so the cheater is 0 and the generalist is 123.
	 * This convention makes it easy to identify a species without having to dig through its amino acid requirement / amino acid production parameters
	 * @param initialAbundance this is the number of microsites that a species will take up when it is inoculated (i.e. placed on the environment grid
	 * @param cmax the maximum birth probability
	 * @param d the death probability
	 * @param inoculateWhen this gives the time step where the species is inoculated
	 * @param inoculateOverwrite if true, this species can overwrite heterospecific individuals when it's inoculated
	 * @param makesAA1 if true, then the species produces amino acid type 1. It will produce the amino acid at the rate KAAProduced, which is defined in the community class
	 * @param makesAA2 if true, then the species produces amino acid type 1. It will produce the amino acid at the rate KAAProduced, which is defined in the community class.
	 * @param makesAA3 if true, then the species produces amino acid type 1. It will produce the amino acid at the rate KAAProduced, which is defined in the community class.
	 * @param AA1K this is the amino acid 1 requirement to avoid resource limitation. Amino acid limitation subscribest to leibig's law of the minimum, where only the most limiting amino acid affects the growth rate. For more information, read the comments within the step1() and step2() methods of the Community class.  
	 * @param AA2K this is the amino acid 1 requirement to avoid resource limitation. Amino acid limitation subscribest to leibig's law of the minimum, where only the most limiting amino acid affects the growth rate. For more information, read the comments within the step1() and step2() methods of the Community class.  
	 * @param AA3K this is the amino acid 1 requirement to avoid resource limitation. Amino acid limitation subscribest to leibig's law of the minimum, where only the most limiting amino acid affects the growth rate. For more information, read the comments within the step1() and step2() methods of the Community class.  
	 */
	public Species(int speciesName1, int initialAbundance, double cmax, double d, int inoculateWhen, boolean inoculateOverwrite, /*int dispersalRadius,*/
			boolean makesAA1, boolean makesAA2, boolean makesAA3,
			double AA1K, double AA2K, double AA3K)
	{
		
		this.speciesName = speciesName1;
		this.cmax = cmax;
		this.d = d;
		//this.dispersalRadius = dispersalRadius;
		this.makesAA1 = makesAA1;
		this.makesAA2 = makesAA2;
		this.makesAA3 = makesAA3;
		this.AA1K = AA1K; 
		this.AA2K = AA2K;
		this.AA3K = AA3K;
		this.initialAbundance = initialAbundance;
		this.gridProxy = 0;
		this.inoculateWhen = inoculateWhen;
		this.inoculateOverwrite = inoculateOverwrite;
		
	}
	
	/**
	 * A species object ontains information that lets the simulation methods know how to treat individuals.
	 * Importantly, a species object knows nothing about the location or number of individuals.
	 * 
	 * @param speciesName1 an identifier that is included for our convenience. My convention is to name the species in terms of the amino acids they make, so the cheater is 0 and the generalist is 123.
	 * This convention makes it easy to identify a species without having to dig through its amino acid requirement / amino acid production parameters
	 * @param initialAbundance this is the number of microsites that a species will take up when it is inoculated (i.e. placed on the environment grid
	 * @param cmax the maximum birth probability
	 * @param d the death probability
	 * @param inoculateWhen this gives the time step where the species is inoculated
	 * @param makesAA1 if true, then the species produces amino acid type 1. It will produce the amino acid at the rate KAAProduced, which is defined in the community class
	 * @param makesAA2 if true, then the species produces amino acid type 1. It will produce the amino acid at the rate KAAProduced, which is defined in the community class.
	 * @param makesAA3 if true, then the species produces amino acid type 1. It will produce the amino acid at the rate KAAProduced, which is defined in the community class.
	 * @param AA1K this is the amino acid 1 requirement to avoid resource limitation. Amino acid limitation subscribest to leibig's law of the minimum, where only the most limiting amino acid affects the growth rate. For more information, read the comments within the step1() and step2() methods of the Community class.  
	 * @param AA2K this is the amino acid 1 requirement to avoid resource limitation. Amino acid limitation subscribest to leibig's law of the minimum, where only the most limiting amino acid affects the growth rate. For more information, read the comments within the step1() and step2() methods of the Community class.  
	 * @param AA3K this is the amino acid 1 requirement to avoid resource limitation. Amino acid limitation subscribest to leibig's law of the minimum, where only the most limiting amino acid affects the growth rate. For more information, read the comments within the step1() and step2() methods of the Community class.  
	 */
	public Species(int speciesName1, int initialAbundance, double cmax, double d, int inoculateWhen, /*int dispersalRadius,*/
			boolean makesAA1, boolean makesAA2, boolean makesAA3,
			double AA1K, double AA2K, double AA3K)
	{
		
		this.speciesName = speciesName1;
		this.cmax = cmax;
		this.d = d;
		//this.dispersalRadius = dispersalRadius;
		this.makesAA1 = makesAA1;
		this.makesAA2 = makesAA2;
		this.makesAA3 = makesAA3;
		this.AA1K = AA1K; 
		this.AA2K = AA2K;
		this.AA3K = AA3K;
		this.initialAbundance = initialAbundance;
		this.gridProxy = 0;
		this.inoculateWhen = inoculateWhen;
		this.inoculateOverwrite = false;
		
	}
	

	/**
	 * If true, then heterospecific individuals can be overwritten during the inoculation period.
	 */
	public boolean getInoculateOverwrite()
	{
		return this.inoculateOverwrite;
	}
	
	/**
	 * Sets whether heterospecific individuals can be overwritten during the inoculation period. 
	 */
	public void setInoculateOverwrite(boolean inoculateOverwrite)
	{
		this.inoculateOverwrite = inoculateOverwrite;
	}
	
	/**
	 * Gets the time at which the species is inoculated.
	 */
	public int getInoculateWhen()
	{
		return this.inoculateWhen;
	}
	
	/**
	 * Sets the time at which the species is inoculated.
	 */
	public void setInoculateWhen(int inoculateWhen)
	{
		this.inoculateWhen = inoculateWhen;
	}
	
	/**
	 * Sets the integer proxy that will denote the species' locations on the environment grid. In the community constructor, this is set up so the gridProxy is the index of the species in the specieslist, plus one (because one is empty space).
	 */
	public void setGridProxy(int gridProxy)
	{
		this.gridProxy = gridProxy;
	}
	
	/**
	 * Gets the integer proxy that will denote the species' locations on the environment grid. In the community constructor, this is set up so the gridProxy is the index of the species in the specieslist, plus one (because one is empty space).
	 */
	public int getGridProxy()
	{
		return this.gridProxy;
	}
	
	
	/**
	 * Gets the name of the species. If the user did not construct the species list from scratch, but instead used the MakeSpeciesList class or the Community constructor, then the species name will indicate what amino acids the species produces (e.g. 0 is the cheater; 123 is the generalist).
	 */
	public int getSpeciesName()
	{
		return this.speciesName;
	}
	
	/**
	 * Gets the name of the species. If the user did not construct the species list from scratch, but instead used the MakeSpeciesList class or the Community constructor, then the species name will indicate what amino acids the species produces (e.g. 0 is the cheater; 123 is the generalist).
	 */
	public void setSpeciesName(int speciesName)
	{
		this.speciesName = speciesName;
	}
	
	/**
	 * Gets the species abundance when it is inoculated.
	 */
	public int getInitialAbundance()
	{
		return this.initialAbundance;
	}
	/**
	 * Sets the species abundance when it is inoculated.
	 */
	public int setInitialAbundance(int initialAbundance)
	{
		return this.initialAbundance = initialAbundance;
	}
	
	
	/**
	 * Gets the maximum birth probability. If the species is limited by amino acids, the realized birth probability will be lower.
	 */
	public double getCmax()
	{
		return this.cmax;
	}
	
	/**
	 * sets the maximum birth probability. If the species is limited by amino acids, the realized birth probability will be lower.
	 */
	public double setCmax(double cmax)
	{
		return this.cmax = cmax;
	}
	
	/**
	 * gets the death probability
	 */
	public double getD()
	{
		return this.d;
	}
	
	
	/**
	 * sets the death probability
	 */
	public double setD(double d)
	{
		return this.d = d;
	}
	
	
	/**
	 * gets whether the species produces amino acid 1
	 */
	public boolean makesAA1()
	{
		return this.makesAA1;
	}
	
	/**
	 * sets whether the species produces amino acid 1
	 */
	public void setMakesAA1(boolean makesAA1)
	{
		this.makesAA1 = makesAA1;
	}
	
	/**
	 * gets whether the species produces amino acid 2
	 */
	public boolean makesAA2()
	{
		return this.makesAA2;
	}
	
	/**
	 * sets whether the species produces amino acid 2
	 */
	public void setMakesAA2(boolean makesAA2)
	{
		this.makesAA2 = makesAA2;
	}
	
	/**
	 * gets whether the species produces amino acid 3
	 */
	public boolean makesAA3()
	{
		return this.makesAA3;
	}
	
	/**
	 * sets whether the species produces amino acid 3
	 */
	public void setMakesAA3(boolean makesAA3)
	{
		this.makesAA3 = makesAA3;
	}
	
	/**
	 * gets the amino acid 1 requirement for non-limitation. The amino acids available to an indvidual is determined by the amount each neighbor produces, the number of neighbors, and the size of the neighborhood. For more details, see the comments within the step1() or step2() method in the Community class.
	 */
	public double getAA1K()
	{
		return this.AA1K;
	}
	
	/**
	 * sets the amino acid 1 requirement for non-limitation. The amino acids available to an indvidual is determined by the amount each neighbor produces, the number of neighbors, and the size of the neighborhood. For more details, see the comments within the step1() or step2() method in the Community class.
	 */
	public void setAA1K(double AA1K)
	{
		this.AA1K = AA1K;
	}
	
	/**
	 * gets the amino acid 2 requirement for non-limitation. The amino acids available to an indvidual is determined by the amount each neighbor produces, the number of neighbors, and the size of the neighborhood. For more details, see the comments within the step1() or step2() method in the Community class.
	 */
	public double getAA2K()
	{
		return this.AA2K;
	}
	
	/**
	 * sets the amino acid 2 requirement for non-limitation. The amino acids available to an indvidual is determined by the amount each neighbor produces, the number of neighbors, and the size of the neighborhood. For more details, see the comments within the step1() or step2() method in the Community class.
	 */
	public void setAA2K(double AA2K)
	{
		this.AA2K = AA2K;
	}

	/**
	 * gets the amino acid 3 requirement for non-limitation. The amino acids available to an indvidual is determined by the amount each neighbor produces, the number of neighbors, and the size of the neighborhood. For more details, see the comments within the step1() or step2() method in the Community class.
	 */
	public double getAA3K()
	{
		return this.AA3K;
	}
	
	/**
	 * sets the amino acid 3 requirement for non-limitation. The amino acids available to an indvidual is determined by the amount each neighbor produces, the number of neighbors, and the size of the neighborhood. For more details, see the comments within the step1() or step2() method in the Community class.
	 */
	public void setAA3K(double AA3K)
	{
		this.AA3K = AA3K;
	}
	
	/**
	 *  sets the amino acid 3 requirement to 0; in other words, it makes amino acid 3 non-limiting. This called automatically in the community constructor if no species produce AA 3, which ensure that not everything dies when we're looking at the set (or subsets) of species 0, 1, 2, 12
	 */
	public void dontUseAA3()
	{
		this.AA3K = 0;
	}
}