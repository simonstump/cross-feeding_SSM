################################################
#First, go to the the java class, Rsim. In the fields initialization block (right after "class RSim"), specify the
#grid length, dispersal radius, and species parameters. 

###############################################
###############################################
# Start by running all these commands

## Just in Case...
# install.packages("rJava") 

#rm(list = ls()) # remove variables 

#detach(package:rJava) # unload rJava 


library(rJava)
library(doSNOW)
library(tcltk)

# starts the java virtual machine
.jinit()

# sets us up to work with the package contents. This is taking us to my eclipse working directory.
javaClassPath <- "/C:/Users/Evan/workspace/IBMCrossFeeding/"

#######################################################s
#######################################################

# obj<-.jnew("RSimNew")
.jaddClassPath(javaClassPath)
obj<-.jnew("RSimNew")
jMeasureStuffTuring <-function(numReps, numMeasurements,  timeBetweenMeasurements,  tooLow,  tooHigh,
                          inoculateWhen,  stepsAfterInoculation,  dt,  gridLength,  AADispersalRadius,
                          dispersalRadius,  KAAProduced,  death,  initCMaxCheat, cMaxSyn1,  cMaxSyn2,  useStep2,
                          initProp0,  AA1Kx0,  AA2Kx0,  AA1Kx1,  AA2Kx1,
                          AA1Kx2,  AA2Kx2)
{
  result <- .jcall(obj,"[D","measureStuffTuring", as.integer(numReps), as.integer(numMeasurements), as.integer(timeBetweenMeasurements), as.double(tooLow), as.double(tooHigh),
                   as.integer(inoculateWhen), as.integer(stepsAfterInoculation), as.double(dt), as.integer(gridLength), as.integer(AADispersalRadius),
                   as.integer(dispersalRadius), as.double(KAAProduced), as.double(death), as.double(initCMaxCheat), as.double(cMaxSyn1), as.double(cMaxSyn2), as.logical(useStep2),
                   as.double(initProp0), as.double(AA1Kx0), as.double(AA2Kx0), as.double(AA1Kx1), as.double(AA2Kx1),
                   as.double(AA1Kx2), as.double(AA2Kx2))
  # mat <- t(sapply(result, .jevalArray))
  # mat
}

#####################################################
#####################################################

AADispersalRadius.vec <- seq(1,20)


#####################################################
#####################################################


# start the timer
ptm <- proc.time()
# number of iterations
theLength <- length(AADispersalRadius.vec)


cl <- makeSOCKcluster(4)
registerDoSNOW(cl)


pb <- tkProgressBar(title = "progress bar", label = "I'm not getting any younger", max=theLength)
progress <- function(n) setTkProgressBar(pb, n)
opts <- list(progress=progress)


df <- foreach(i = 1:theLength, .combine = rbind, .packages = "rJava", .options.snow = opts)  %dopar%  
{
  .jinit()
  .jaddClassPath(javaClassPath)
  obj<-.jnew("RSimNew")
  
tryCatch(

c(jMeasureStuffTuring(
numReps = 3,
numMeasurements = 50,
timeBetweenMeasurements = 10,
tooLow = 0.005,
tooHigh = 0.05,
inoculateWhen = 200,
stepsAfterInoculation = 3000,
dt = 1,
gridLength = 100,
AADispersalRadius = AADispersalRadius.vec[i],
dispersalRadius = 2,
KAAProduced = 8,
death = 0.10, 
initCMaxCheat = 0.70,
cMaxSyn1 = 0.55,
cMaxSyn2 = 0.55, 
useStep2 = TRUE,
initProp0 = 0.01,
AA1Kx0 = 1,  AA2Kx0 = 1,
AA1Kx1 = 0,  AA2Kx1 = 1,
AA1Kx2 = 1,  AA2Kx2 = 0
) , AADispersalRadius.vec[i])
,error = function(e){"iteration " + i + "has failed"})

}  

stopCluster(cl)

colnames(df) <-
c(

  "L0", "",
  "L1", "",
  "L2", "",
  "covfCE0", "",
  "covfCE1", "",
  "covfCE2", "",
  "deltaOverB1", "",
  "deltaOverB2", "",
  "covFitnessDensity1", "",
  "covFitnessDensity2", "",
  "covEmptySiteDensity1", "",
  "covEmptySiteDensity2", "",
  "covFCDensity1", "",
  "covFCDensity2", "",
  "covKN1LocalBarDensity2", "",
  "covKN2LocalBarDensity1", "",
  
  
  
  
  
  "L0After", "",
  "L1After", "",
  "L2After", "",
  "covfCE0After", "",
  "covfCE1After", "",
  "covfCE2After", "",
  "covFitnessDensity0After", "",
  "covFitnessDensity1After", "",
  "covFitnessDensity2After", "",
  "covEmptySiteDensity0After", "",
  "covEmptySiteDensity1After", "",
  "covEmptySiteDensity2After", "",
  "covFCDensity0After", "",
  "covFCDensity1After", "",
  "covFCDensity2After", "",	
  "covKN1LocalBarDensity2After", "",
  "covKN2LocalBarDensity1After", "",
  "covKN1LocalBarDensity0After", "",
  "covKN2LocalBarDensity0After", "",
  "b0After", "",
  "N0After", "",
  
  "L0AfterInvasion", "",
  "L1AfterInvasion", "",
  "L2AfterInvasion", "",
  "covfCE0AfterInvasion", "",
  "covfCE1AfterInvasion", "",
  "covfCE2AfterInvasion", "",
  "covFitnessDensity0AfterInvasion", "",
  "covFitnessDensity1AfterInvasion", "",
  "covFitnessDensity2AfterInvasion", "",
  "covEmptySiteDensity0AfterInvasion", "",
  "covEmptySiteDensity1AfterInvasion", "",
  "covEmptySiteDensity2AfterInvasion", "",
  "covFCDensity0AfterInvasion", "",
  "covFCDensity1AfterInvasion", "",
  "covFCDensity2AfterInvasion", "",	
  "covKN1LocalBarDensity2AfterInvasion", "",
  "covKN2LocalBarDensity1AfterInvasion", "",
  "covKN1LocalBarDensity0AfterInvasion", "",
  "covKN2LocalBarDensity0AfterInvasion", "",
  "N0AfterInvasion", "", 
  
  
  "AADispersalRadius"
  
  )


write.csv(df, "IBMCrossFeeding/turing_data.csv", row.names = FALSE)
############################################
############################################
df <- read.csv("IBMCrossFeeding/turing_data.csv")
library(plotrix)
  # make sure the graphics device is clear
  graphics.off()
  # set up pdf and in landscape form
  pdf("turing pattern data.pdf", width = 28, height = 18)
  
  # make title page
  par(mar = c(0,0,0,0))
 
  # set up the grid - like plotting parameter
  par(mar = c(2,4,10,4), mfrow=c(3,3))
  
  # get vector of predictors to explore

AADispersalVec <- df[,ncol(df)]
for(i in seq(1,(ncol(df)-1),2))
{
  curName <- colnames(df)[i]
  plotCI(x = AADispersalVec, y = df[,i], uiw = df[,(i+1)], xlab = "AADispersalRadius",  ylab = curName, main = curName, pch = 16, cex.main = 4)
}

dev.off()
