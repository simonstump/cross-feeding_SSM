
public class MathematicaTest
{
	private static int a = 68;
	private int b = 69;
	private int c;
	
	public MathematicaTest(int i)
	{
		this.c = i*3;
	}
	
	public static int addAB(int a, int b)
	{
		return a+b;
	}
	
	public int returnC()
	{
		return this.c;
	}
}
