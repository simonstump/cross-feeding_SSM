// this class allows the critters to navigate the environmental grid as if it were a donut (like pacman)
// since the two methods have the exact same behavior is a square grid envrironment, these two methods could and should (eventually) be refactored into one method.
////// However, this would take time and -  in the meantime - the two methods add clarifaction conceptual clarification when used in conjuction with actual grid locations
// while loops in the methods allow for dispersal which is greater than the length of the grid
public class WrapAround
{
	
	// finds the row (on the other side... if there is one)
	/*public static int wrapAround(int rowOrCol, int gridLength)
	{
		if (rowOrCol > gridLength - 1)
		{
			while (rowOrCol > gridLength - 1)
			{
				rowOrCol = rowOrCol - gridLength;
			}
		}
		else if (rowOrCol < 0)
		{
			while (rowOrCol < 0)
			{
				rowOrCol = gridLength + rowOrCol;
			}
		}
		return rowOrCol;
	}
*/
	
	public static int wrapAround(int rowOrCol, int gridLength)
	{
		if (rowOrCol > gridLength - 1 || rowOrCol < 0)
		{
			
				return (rowOrCol + gridLength)% gridLength;
		}
		return rowOrCol;
	}

	

	// unused but potentially useful methods
	/*
	public static boolean doesRowWrapAround(int Row, int gridLength)
	{
		if (Row > gridLength - 1)
		{
			return true;
		}
		else if (Row < 0)
		{
			return true;
		}
		return false;

	}

	
	public static boolean doesColWrapAround(int Col, int gridLength)
	{
		if (Col > gridLength - 1)
		{
			return true;
		}
		else if (Col < 0)
		{
			return true;
		}
		return false;

	}

	public static boolean doesRowWrapNorth(int Row, int gridLength)
	{
		if (Row < 0)
		{
			return true;
		}
		return false;
	}

	public static boolean doesColWrapWest(int Col, int gridLength)
	{
		if (Col < 0)
		{
			return true;
		}
		return false;
	}

	public static boolean doesRowWrapSouth(int Row, int gridLength)
	{
		if (Row > gridLength - 1)
		{
			return true;
		}
		return false;
	}

	public static boolean doesColWrapEast(int Col, int gridLength)
	{
		if (Col > gridLength - 1)
		{
			return true;
		}
		return false;
	}*/

}
