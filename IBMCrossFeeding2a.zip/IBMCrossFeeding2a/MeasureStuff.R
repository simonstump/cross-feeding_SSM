################################################
#First, go to the the java class, Rsim. In the fields initialization block (right after "class RSim"), specify the
#grid length, dispersal radius, and species parameters. 

###############################################
###############################################
# Start by running all these commands

## Just in Case...
# install.packages("rJava") 

#rm(list = ls()) # remove variables 

#detach(package:rJava) # unload rJava 


library(rJava)

# starts the java virtual machine
.jinit()

# sets us up to work with the package contents. This is taking us to my eclipse working directory.
.jaddClassPath("/C:/Users/Evan/workspace/IBMCrossFeeding/")

#######################################################s
#######################################################

obj1<-.jnew("RSimNew")
jMeasureStuff <-function( numMeasurements,  timeBetweenMeasurements,  tooLow,  tooHigh,
                          inoculateWhen,  stepsAfterInoculation,  dt,  gridLength,  AADispersalRadius,
                          dispersalRadius,  KAAProduced,  death,  initCMaxCheat,  deltaB0,  cMaxSyn1,  cMaxSyn2,  useStep2,
                          initProp0,  AA1Kx0,  AA2Kx0,  AA1Kx1,  AA2Kx1,
                          AA1Kx2,  AA2Kx2)
{
  result <- .jcall(obj1,"[D","measureStuff", as.integer(numMeasurements), as.integer(timeBetweenMeasurements), as.double(tooLow), as.double(tooHigh),
                   as.integer(inoculateWhen), as.integer(stepsAfterInoculation), as.double(dt), as.integer(gridLength), as.integer(AADispersalRadius),
                   as.integer(dispersalRadius), as.double(KAAProduced), as.double(death), as.double(initCMaxCheat), as.double(deltaB0), as.double(cMaxSyn1), as.double(cMaxSyn2), as.logical(useStep2),
                   as.double(initProp0), as.double(AA1Kx0), as.double(AA2Kx0), as.double(AA1Kx1), as.double(AA2Kx1),
                   as.double(AA1Kx2), as.double(AA2Kx2))
  # mat <- t(sapply(result, .jevalArray))
  # mat
}

#####################################################
#####################################################


stuff <- jMeasureStuff(
numMeasurements = 10,
timeBetweenMeasurements = 50,
tooLow = 0.005,
tooHigh = 0.05,
inoculateWhen = 100,
stepsAfterInoculation = 3000,
dt = 1,
gridLength = 100,
AADispersalRadius = 2,
dispersalRadius = 2,
KAAProduced = 3.5,
death = 0.15, 
initCMaxCheat = 0.60,
deltaB0 = 0.05,
cMaxSyn1 = 0.55,
cMaxSyn2 = 0.5, 
useStep2 = TRUE,
initProp0 = 0.001,
AA1Kx0 = 1,  AA2Kx0 = 1,
AA1Kx1 = 0,  AA2Kx1 = 1,
AA1Kx2 = 1,  AA2Kx2 = 0
)


names(stuff) <-
c(

  "L0",
  "L1",
  "L2",
  "covfCE0",
  "covfCE1",
  "covfCE2",
  "deltaOverB1",
  "deltaOverB2",
  "covFitnessDensity1",
  "covFitnessDensity2",
  "covEmptySiteDensity1",
  "covEmptySiteDensity2",
  "covFCDensity1",
  "covFCDensity2",
  "covKN1LocalBarDensity2",
  "covKN2LocalBarDensity1",
  
  
  
  
  
  "L0After",
  "L1After",
  "L2After",
  "covfCE0After",
  "covfCE1After",
  "covfCE2After",
  "covFitnessDensity0After",
  "covFitnessDensity1After",
  "covFitnessDensity2After",
  "covEmptySiteDensity0After",
  "covEmptySiteDensity1After",
  "covEmptySiteDensity2After",
  "covFCDensity0After",
  "covFCDensity1After",
  "covFCDensity2After",	
  "covKN1LocalBarDensity2After",
  "covKN2LocalBarDensity1After",
  "covKN1LocalBarDensity0After",
  "covKN2LocalBarDensity0After",
  "b0After",
  "N0After",
  
  "L0AfterInvasion",
  "L1AfterInvasion",
  "L2AfterInvasion",
  "covfCE0AfterInvasion",
  "covfCE1AfterInvasion",
  "covfCE2AfterInvasion",
  "covFitnessDensity0AfterInvasion",
  "covFitnessDensity1AfterInvasion",
  "covFitnessDensity2AfterInvasion",
  "covEmptySiteDensity0AfterInvasion",
  "covEmptySiteDensity1AfterInvasion",
  "covEmptySiteDensity2AfterInvasion",
  "covFCDensity0AfterInvasion",
  "covFCDensity1AfterInvasion",
  "covFCDensity2AfterInvasion",	
  "covKN1LocalBarDensity2AfterInvasion",
  "covKN2LocalBarDensity1AfterInvasion",
  "covKN1LocalBarDensity0AfterInvasion",
  "covKN2LocalBarDensity0AfterInvasion",
  "N0AfterInvasion"
  
  )

stuff

