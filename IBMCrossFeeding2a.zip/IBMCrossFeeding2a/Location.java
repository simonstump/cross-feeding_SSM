
/**
 * This class encapsulates the information for row and col. It is used exclusively in the step methods in the community class.
 * 
 * @author Evan 
 * @version 2/27/16
 */
public class Location
{
    
    private int row;
    private int col;
    /**
     * Constructor for objects of class Location
     * @param row the row position
     * @param col the column position
     */
    public Location(int row, int col)
    {
        this.row = row;
        this.col = col;
    }

    /*
     * gets the Location's row position
     */
    public int row()
    {
        return this.row;
    }

    /*
     * gets the Location's column position
     */
    public int col()
    {
        return this.col;
    }
    
}
