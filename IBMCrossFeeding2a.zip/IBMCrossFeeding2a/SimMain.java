import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.util.ArrayList;

import com.jogamp.opengl.GLEventListener;

public class SimMain
{
/*	// how long should the donut be?
	//private static int gridLength = 400;

	// construct species and put them in an array list. The format for species is given below:

	// Species(int speciesName, int initialAbundance,  cmax,  d, int dispersalRadius,
	//  makesAA1,  makesAA2,  makesAA3,
	// int AA1K, int AA2K, int AA3K)
	//private static  useQuantCheat = false;
	private static int stepsUntilQuantCheat = 30;

	private static  quantCheatInitProp = 0.10;
private static int initAbund = 50;
	//private static  death = 0.10;

	private static  propToStart = 0.40;
	private static  cmaxQuantCheat = 0.55;
	private static  cmaxSyn1 = 0.60;
	private static  cmaxSyn2 = 0.90;
	private static int stepsUntilInoculateCheater = 200;

	// how far can species dispersal in any direction
	//private static int dispersalRadius = 1;

	// how many amino acids does each critter produce?
	//private static int KAAProduced = 8;

	private static int numSteps = 500;
	private static int numReps = 5;
	//private static  reportDensity = true;

	private static int measureHowOften = 5;*/
	
	private static int numMeasurements = 100;
	private static int timeBetweenMeasurements = 50;
	private static double tooLow = 0.005; 
	private static double tooHigh = 0.05;
	private static int inoculateWhen = 500;
	private static int stepsAfterInoculation = 1500;
	private static double dt = 1;
	private static int gridLength = 100;
	private static int AADispersalRadius = 6;
	private static int dispersalRadius = 6;
	private static int KAAProduced = 8;
	private static double  death = 0.20; 
	private static double initCMaxCheat = 0.55;
	private static double deltaB0 = 0.02; 
	private static double cMaxSyn1 = 0.50;
	private static double cMaxSyn2 = 0.50;
	private static boolean useStep2 = true;
	private static double  initProp0 = 0.40;
	private static double  AA1Kx0 = 1;  private static double  AA2Kx0 = 1;
	private static double  AA1Kx1 = 0;  private static double  AA2Kx1 = 1;
	private static double  AA1Kx2 = 1;  private static double  AA2Kx2 = 0;

	public static void main(String[] args)
	{
		//System.out.println("starting");
		/*
		 * int[][] data = RSim.quantCheatTimeSeries(numSteps, measureHowOften, gridLength, propToStart, dispersalRadius, death, KAAProduced, cmaxQuantCheat, cmaxSyn, useQuantCheat, stepsUntilQuantCheat, quantCheatInitProp); for(int i = 0; i < data.length; i++) { System.out.println(data[i][0]); }
		 */
/*		int[][] data = RSim.timeSeries( numSteps,  measureHowOften,  gridLength,  propToStart,  dispersalRadius,  death,  KAAProduced,  0.5,  0.1,
		 0.1,  0.1,  false,false,false,false,false,false,false,false);*/
		//int[][] data = RSim.timeSeriesSimple( numSteps,  measureHowOften);

		double[] data = RSimNew.measureStuff(numMeasurements, timeBetweenMeasurements,  tooLow,  tooHigh, inoculateWhen,  stepsAfterInoculation,  dt,  gridLength,   AADispersalRadius,
				 dispersalRadius,  KAAProduced,  death, initCMaxCheat, deltaB0,  cMaxSyn1, cMaxSyn2,  useStep2,
				 initProp0,   AA1Kx0,  AA2Kx0,   AA1Kx1,
				 AA2Kx1,  AA1Kx2,  AA2Kx2);
		
		
		for(int i = 0; i < data.length; i++)
		{
			System.out.println(i + ": "+ data[i]);
		}
		
		////////////////////////////////////////////////////////////////////////////////////
		// test to makes sure community.quantCheatfinalValueWorks
		/*ArrayList<Species> speciesList = new ArrayList<Species>();

		if (useQuantCheat)
		{
			speciesList.add(new Species(0, 10, cmaxQuantCheat, death, false, false, false, 0, 1, 0));
		}

		speciesList.add(new Species(1, 1000, cmaxSynmakesAA1, death, true, false, false, 0, 1, 0));

		speciesList.add(new Species(2, 1000, cmaxSynmakesAA2, death, false, true, false, 1, 0, 0));

		Community community = new Community(gridLength, speciesList);

		[] res = community.quantCheatFinalValue(dispersalRadius, KAAProduced, numSteps, stepsUntilInoculateCheater, true);
		for (int i = 0; i < res.length; i++)
		{
			System.out.println(res[i]);
		}*/
		
		
		/////////////////////////////////////////////
		//test for the final (equilbrium?) abundances method
		/*[] res = RSim.quantCheatFinalAbundances(numSteps, numReps,  gridLength,  propToStart,  dispersalRadius,  death,  KAAProduced,  cmaxQuantCheat,  cmaxSyn1, cmaxSyn2, useQuantCheat,  stepsUntilQuantCheat,  quantCheatInitProp, reportDensity); 
		for (int i = 0; i < res.length; i++)
		{
			System.out.println(res[i]);
		}*/
		
//		[] res = RSim.quadraticGrowthTest( numSteps,  numReps,  gridLength,  initAbund,  dispersalRadius,  death,  KAAProduced,  cmaxSyn1,  cmaxSyn2);
//		for (int i = 0; i < res.length; i++)
//		{
//			System.out.println(res[i]);
//		}
	}

}
