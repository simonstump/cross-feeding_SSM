import java.util.ArrayList;
import java.util.List;
import java.util.Random;

// TODO: Auto-generated Javadoc
/**
 * The Class Environment.
 */
public class Environment
{

	/** The generator of random numbers */
	protected static Random generator = new Random();

	/** The grid on which critters and spatial information of patches */
	protected int[][] grid;

	/** The grid length. */
	protected int gridLength;

	//protected double[][][] AAGrid;

	/**
	 * Instantiates a new environment, which is composed of the gridlength and a two dimensional array.  
	 *
	 * @param gridLength the grid length
	 */
	public Environment(int gridLength)
	{
		this.grid = new int[gridLength][gridLength];
		this.gridLength = gridLength;
		//this.AAGrid = new double[gridLength][gridLength][3];
	}

	/*
	 * public Environment(int[][] grid) { this.grid = grid; this.gridLength = grid.length; }
	 */

	/*
	 * public int getSpeciesProxy(int row, int col) { return this.grid[row][col]; }
	 */

	/**
	 * Replaces the current grid configuration with a new grid.
	 * @param grid a environment grid
	 */
	public void setGrid(int[][] grid)
	{
		this.grid = grid;
	}

	/**
	 * Gets the grid.
	 *
	 * @return the grid
	 */
	public int[][] getGrid()
	{
		return this.grid;
	}

	/**
	 * Replaces the current amino acid grid configuration with a new grid.
	 * @param grid a environment grid
	 */
	/*public void setAAGrid(double[][][] AAGrid)
	{
		this.AAGrid = AAGrid;
	}

	*//**
	 * Gets the grid.
	 *
	 * @return the grid
	 *//*
	public double[][][] getAAGrid()
	{
		return this.AAGrid;
	}
*/
	/**
	 * Gets the value of a site. 0 denotes empty space; anything else is a critter. 
	 * 
	 * @param row the row of the location
	 * @param col the col of the locaton
	 * 
	 * @return theGridValue
	 */
	public int getGridValue(int row, int col)
	{
		return this.grid[row][col];
	}

	/**
	 * Gets the grid length.
	 *
	 * @return the grid length
	 */
	public int getGridLength()
	{
		return this.gridLength;
	}

	/**
	 * Checks if a particular location is occupied by a critter.
	 *
	 * @param location the location
	 * @return true, if the location is occupied
	 */
	public boolean isOccupied(Location location)
	{
		return this.grid[location.row()][location.col()] != 0;
	}

	/**
	 * Checks if a particular location is occupied by a critter.
	 *
	 * @param row the row of the location
	 * @param col the col of the locaton
	 * @return true, if the location is occupied
	 */
	public boolean isOccupied(int row, int col)
	{
		return this.grid[row][col] != 0;
	}

	/**
	 * Checks if a location on a grid does NOT have a critter
	 *
	 * @param location the location
	 * @return true, if it is empty
	 */
	public boolean isEmpty(Location location)
	{
		return this.grid[location.row()][location.col()] == 0;
	}

	/**
	 *  Checks if a location on a grid does NOT have a critter.
	 *
	 * @param row the row of the location
	 * @param col the col of the locaton
	 * @return true, if it is empty
	 */
	public boolean isEmpty(int row, int col)
	{
		return this.grid[row][col] == 0;
	}

	/**
	 * Adds a unique species identifier on a grid location.
	 *
	 * @param location the location
	 * @param speciesValue the critter value
	 */
	public void add(Location location, int speciesValue)
	{
		this.grid[location.row()][location.col()] = speciesValue;
	}

	/**
	 * Adds a unique species identifier on a grid location.
	 *
	 * @param row the row of the location
	 * @param col the col of the locaton
	 * @param speciesValue the critter value
	 */
	public void add(int row, int col, int speciesValue)
	{
		this.grid[row][col] = speciesValue;
	}

	/*public void addAA(int row, int col, Species aSpecies, int AADispersal, double KAAProduced)
	{
		for (int row2 = row - AADispersal; row2 <  row + 1+ AADispersal; row2++)
		{
			for (int col2 = col - AADispersal; col2 <  col + 1+ AADispersal; col2++)
			{
				int realRow = WrapAround.wrapAround(row2, this.gridLength);
				int realCol = WrapAround.wrapAround(row2, this.gridLength);
				
				this.AAGrid[realRow][realCol][0] += KAAProduced / this.possibleNeighbor

			}
		}

	}
*/
	/**
	 * Removes any species identifier from a particular grid location.
	 *
	 * @param location the location
	 */
	public void remove(Location location)
	{
		this.grid[location.row()][location.col()] = 0;
	}

	/**
	 * Removes any species identifier from a particular grid location.
	 * 
	 * @param row the row of the location
	 * @param col the col of the locaton
	 */
	public void remove(int row, int col)
	{
		this.grid[row][col] = 0;
	}

	/**
	 * Clears the environment grid of all critters.
	 */
	public void clearEnvOfCritters()
	{
		for (int j = 0; j <= this.gridLength - 1; j++)
		{
			for (int i = 0; i <= this.gridLength - 1; i++)
			{
				this.grid[i][j] = 0;
			}
		}
	}

}
